import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,saveGame,loadGame,recruit,collect,construct,tick,upgrade} from '../src/sim.js';
import {visitFounder,claimSupplies,supplyParcels,ensurePatronage,createFounderEstate,PATRON_RULES} from '../src/realm.js';
import {BUILDINGS} from '../src/sim.js';
const advance=(s,t)=>{for(let i=0;i<t*20;i++)tick(s,.05);};
test('a welcome parcel requires a visit and cannot be farmed by visiting repeatedly',()=>{
 const s=createGame(),wood=s.resources.wood,food=s.resources.food;
 assert.equal(claimSupplies(s).ok,false);visitFounder(s);assert.equal(supplyParcels(s),1);assert.equal(claimSupplies(s).ok,true);
 assert.equal(s.resources.wood,wood+PATRON_RULES.supplies.wood);assert.equal(s.resources.food,food+PATRON_RULES.supplies.food);assert.equal(s.stats.wood,0);
 for(let i=0;i<20;i++){visitFounder(s);assert.equal(claimSupplies(s).ok,false);}assert.equal(supplyParcels(s),0);
});
test('actual recruitment and construction each replenish one limited parcel',()=>{
 const s=createGame();visitFounder(s);claimSupplies(s);recruit(s,s.buildings[0].id,'worker');advance(s,3.2);assert.equal(supplyParcels(s),1);claimSupplies(s);assert.equal(supplyParcels(s),0);
 recruit(s,s.buildings[0].id,'worker');advance(s,3.2);assert.equal(supplyParcels(s),0);
 construct(s,'house',13,21);advance(s,5.2);assert.equal(supplyParcels(s),1);claimSupplies(s);assert.equal(s.patronage.suppliesClaimed,3);
});
test('gifted wood does not count as player-earned gathering',()=>{
 const s=createGame();visitFounder(s);claimSupplies(s);assert.equal(s.stats.wood,0);
 s.drops.push({id:'test-wood',x:10,y:10,resource:'wood',amount:36});collect(s,'test-wood');assert.equal(supplyParcels(s),1);claimSupplies(s);assert.equal(supplyParcels(s),0);
});
test('upgrades earn only one parcel across repeated levels and supplies survive saving',()=>{
 const s=createGame();visitFounder(s);claimSupplies(s);upgrade(s,s.buildings[1].id);advance(s,8);assert.equal(supplyParcels(s),1);claimSupplies(s);
 const restored=loadGame(saveGame(s));ensurePatronage(restored);assert.equal(restored.patronage.visited,true);assert.equal(supplyParcels(restored),0);assert.equal(claimSupplies(restored).ok,false);
 restored.resources.wood=1000;restored.resources.gold=1000;restored.resources.stone=1000;upgrade(restored,restored.buildings[1].id);advance(restored,10);assert.equal(supplyParcels(restored),0);
});
test('old villages acquire neighbor metadata without losing resources, buildings, or queues',()=>{
 const s=createGame();recruit(s,s.buildings[0].id,'worker');delete s.patronage;const saved=saveGame(s),before=JSON.parse(saved),restored=loadGame(saved);ensurePatronage(restored);
 assert.deepEqual(restored.resources,before.resources);assert.deepEqual(restored.buildings,before.buildings);assert.deepEqual(restored.units,before.units);assert.deepEqual(restored.patronage,{visited:false,suppliesClaimed:0});
});
test('the showcase realm has strong buildings, no enemies, and no shared objects with home',()=>{
 const s=createGame(),original=saveGame(s),estate=createFounderEstate(BUILDINGS);assert.equal(estate.scene,'founder');assert.ok(estate.buildings.some(b=>b.level===10));assert.ok(estate.units.some(u=>u.ruler));assert.ok(estate.units.every(u=>u.faction==='ally'));estate.buildings[0].level=1;estate.units[0].hp=0;assert.equal(saveGame(s),original);
});
