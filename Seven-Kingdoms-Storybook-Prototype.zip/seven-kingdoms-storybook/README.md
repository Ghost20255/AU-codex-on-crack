# Seven Kingdoms — The Frontier

An original, local, browser-based isometric strategy **vertical slice**. Seven Kingdoms is a working title. No Social Empires code, artwork, sounds, saved games, or network services are included.

## Play

Install Node.js 22 or newer, extract the project, and run `npm start` from this folder. Open `http://localhost:4173` in your browser. On Windows, you can also double-click `start-game.cmd`. Runtime has no third-party dependencies and does not need `npm install`.

Start at the Town Hall. Recruit a villager, select them on the map, then click a tree. Villagers walk to the tree, work, and leave collectible bundles. Build a cottage, train shieldbearers at the Barracks, then select your army and attack the three raiders on the eastern road.

- Click a person or building to select it; actions appear at the bottom.
- Shift-click or drag a box to select multiple people. Click ground to move or an enemy to attack.
- Use the Build tool, choose a building, then click clear ground. Escape cancels placement.
- Upgrade and move buildings using their action menu. Work in progress must finish before moving.
- Scroll or use +/− to zoom. Space + drag, middle-drag, or right-drag pans. H returns home; B opens Build.
- The Controls menu pauses gameplay, enables optional hover collection, and exports a village save.

Progress saves automatically to this browser every five seconds and on page hide. Reload to resume. No offline production is simulated. Starting over requires confirmation and retains a browser-local backup; export before clearing browser data. This version exports saves but does not have a save-import UI. The original uploaded files were not run or changed.

## Brighter village and familiar controls (0.3.0)

The village now uses original illustrated buildings and animated character poses, a brighter landscape, a persistent bottom unit roster and horizontal neighbor cards. Click a portrait to select a villager or soldier; Shift-click portraits to select a group. Movement, gathering and combat still use direct map commands.

Click a village goal for instructions and a shortcut to the relevant building or workers. The construction shop has All, Village, Military and Legends categories, illustrated building cards, normal resource costs, and clearly labeled future previews. Existing playable buildings are not gated behind the new level display.

Work earns small configurable XP rewards: gathering, completed recruitment/training, completed construction/upgrades and defeated raiders. The top level bar tracks village growth; there are no cash/paid XP purchases. Receiving an ally gift or collecting the same bundle does not grant extra XP. Old village saves begin with zero XP while preserving existing buildings, resources and queues.

## Areweyn Kingdom: creator-ally visit

Use the neighbor card at the lower left to visit **Sahir Ibn Raydan** in **Areweyn Kingdom**. Your own village pauses during visits. Inspect the developed keep, towers and guards, collect a welcome supply parcel, and browse Village, Military and Legends blueprints. Only the buildings marked Playable now can be built; future chapters are clearly labeled previews. Choosing a playable blueprint returns you home to normal placement and costs.

Supply parcels contain 25 wood and 20 food. There is one welcome parcel and one additional parcel for each of five distinct village milestones: recruitment, gathering 36 wood yourself, completing a new cottage, training a shieldbearer, and finishing an upgrade. Revisits and repeat completions do not create extra rewards. Gifts do not count as gathered wood. Claims and progress survive reloading, and older village saves are retained. These limits are prototype values in `src/realm.js`.

This is an authored single-player ally, not a real online player. Earned rolls, generated reinforcements/enemies and actual aid requests are not implemented yet: the user is clarifying which type of roll they want. No paid AI service, cash roll purchase or extra runtime dependency is included.

## Implemented

Town Hall recruitment; selectable villagers; wood, stone, gold and farm-food gathering; visible work progress and collection; population capacity; cottages, Barracks, farms and watchtowers; construction; building movement; ten configurable upgrade levels; basic infantry movement, guarding and combat; selection indicators, damage and death feedback; camera controls; local saving. Premium cash is displayed but unused, with no shop or payments. Major building ornament changes occur at levels 5 and 10; the artwork remains a first iteration.

New mechanics and balancing live in `src/sim.js`; rendering is in `src/render.js`; player interaction and UI are in `src/main.js`; the ally visit, milestones and showcase catalog live in `src/realm.js` and `src/realm-ui.js`. The simulation does not depend on the DOM. Current simulation authority is browser JavaScript, suitable for a single-player slice. An authoritative backend would be a later architectural step.

## Verification

`npm ci` installs only the pinned browser-testing dependency. `npm test` runs deterministic gameplay tests. Start the server, then run `npm run test:browser` for the original village regression `npm run test:ally` for visits, and `npm run test:storybook` for the refreshed interface, with Chromium installed. Set `CHROMIUM_PATH` if Chromium is not at `/usr/bin/chromium`; set `GAME_TEST_URL` to change the test origin. Browser tests create a separate automation profile and do not use your personal saves.

See `artifacts/browser-results.json` for the latest executed checks and `docs/REFERENCE-ASSESSMENT.md` for the supplied implementation assessment and staged roadmap. A compressed user recording has now been reviewed separately to identify interaction patterns. The original uploaded executable has not been run; its client and game-data folders remain missing.

## License and assets

New game code and original project assets are distributed under MIT; see `LICENSE`. The two sprite atlases in `assets/` were generated specifically for this project; see `assets/README.md`. Terrain, effects and fallback illustrations are drawn with Canvas. System fonts are used; no external image service or audio is loaded at runtime. `playwright-core` is a development-only dependency licensed Apache-2.0; its license is retained by npm inside its package. No old-game binaries are redistributed in this project or its download archive.
