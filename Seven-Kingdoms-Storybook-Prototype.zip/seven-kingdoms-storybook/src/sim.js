import {awardXP,progressionInfo} from './progression.js';
// Original, deterministic game rules. No reference-game code or assets.
export const SIZE=30;
export const RULES={gatherTime:4,gatherAmount:18,workerTime:3,soldierTime:5,upgradeTime:6,workerCost:{food:25,gold:15},soldierCost:{food:30,gold:35},workerSpeed:1.8,soldierSpeed:2.25};
export const BUILDINGS={
 townhall:{name:'Town Hall',size:3,cost:{wood:180,stone:100,gold:100},time:10,health:600,description:'The heart of your frontier kingdom. Recruit villagers and guide its growth.'},
 house:{name:'Cottage',size:2,cost:{wood:50,stone:15},time:5,health:180,description:'A warm hearth and room for four more people.'},
 barracks:{name:'Barracks',size:3,cost:{wood:90,stone:40,gold:40},time:8,health:320,description:'Train shieldbearers to defend your people and push back the Ashen raiders.'},
 farm:{name:'Farm',size:2,cost:{wood:40,gold:15},time:5,health:160,description:'Assign villagers to harvest food. Ready crops replenish over time.'},
 tower:{name:'Watchtower',size:2,cost:{wood:70,stone:60,gold:30},time:7,health:280,description:'A vigilant archer defends the village from nearby raiders.'}
};
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export function terrain(x,y){return x<2||y<2||x>=28||y>=28||(x<5&&y>19)||(x<7&&y>24)?'water':'grass';}
export function capacity(s){return 5+s.buildings.filter(b=>b.kind==='house'&&!b.remaining).reduce((n,b)=>n+4+(b.level-1)*2,0);}
export function population(s){return s.units.filter(u=>u.faction==='player'&&u.hp>0).length;}
export function reservedPopulation(s){return population(s)+s.buildings.reduce((n,b)=>n+b.queue.length,0);}
export function canPay(s,cost){return Object.entries(cost).every(([k,v])=>s.resources[k]>=v);}
function pay(s,cost){for(const[k,v]of Object.entries(cost))s.resources[k]-=v;}
export function makeUnit(s,kind,x,y,faction='player'){
 const u={id:'u'+s.nextId++,kind,x,y,faction,hp:kind==='worker'?70:kind==='raider'?110:140,maxHp:kind==='worker'?70:kind==='raider'?110:140,path:[],task:null,progress:0,attackTimer:0,home:{x,y},dead:0};s.units.push(u);return u;
}
function makeBuilding(s,kind,x,y){const b={id:'b'+s.nextId++,kind,x,y,size:BUILDINGS[kind].size,level:1,hp:BUILDINGS[kind].health,maxHp:BUILDINGS[kind].health,remaining:0,total:0,queue:[],cooldown:0};s.buildings.push(b);return b;}
export function createGame(){
 const s={version:1,nextId:1,time:0,progression:{xp:0},resources:{gold:220,wood:160,food:150,stone:100,cash:0},buildings:[],units:[],nodes:[],drops:[],effects:[],stats:{recruited:0,wood:0,built:0,trained:0,kills:0,upgrades:0},notice:'A new home, beyond the old borders.',victory:false};
 makeBuilding(s,'townhall',12,11);makeBuilding(s,'house',9,14);makeBuilding(s,'barracks',17,13);makeBuilding(s,'farm',11,18);
 for(const[x,y]of[[11,14],[13,15],[15,15]])makeUnit(s,'worker',x,y);
 for(const[x,y]of[[18,17],[19,17]])makeUnit(s,'soldier',x,y);
 for(const[x,y]of[[24,14],[25,15],[25,13]])makeUnit(s,'raider',x,y,'enemy');
 for(const[x,y]of[[7,10],[8,9],[6,12],[8,7],[10,6],[17,7],[20,8],[21,10],[6,17],[7,20],[16,22],[19,23],[23,22],[25,20],[24,7],[12,24],[10,23],[5,8],[15,5],[21,5]])s.nodes.push({id:'n'+s.nextId++,kind:'tree',x,y,amount:108});
 for(const[x,y]of[[20,20],[21,21],[7,15]])s.nodes.push({id:'n'+s.nextId++,kind:'stone',x,y,amount:180});
 s.nodes.push({id:'n'+s.nextId++,kind:'gold',x:22,y:9,amount:180});return s;
}
export function entity(s,id){return [...s.units,...s.buildings,...s.nodes,...s.drops].find(x=>x.id===id);}
export function blocked(s,x,y,ignore=null){
 if(terrain(x,y)==='water')return true;
 return s.buildings.some(b=>b.id!==ignore&&x>=b.x&&x<b.x+b.size&&y>=b.y&&y<b.y+b.size)||s.nodes.some(n=>n.amount>0&&Math.round(n.x)===x&&Math.round(n.y)===y);
}
export function canPlace(s,kind,x,y,ignore=null){
 const size=BUILDINGS[kind]?.size;if(!size||!Number.isInteger(x)||!Number.isInteger(y))return false;
 for(let dx=0;dx<size;dx++)for(let dy=0;dy<size;dy++)if(blocked(s,x+dx,y+dy,ignore)||s.units.some(u=>u.hp>0&&Math.round(u.x)===x+dx&&Math.round(u.y)===y+dy))return false;
 return true;
}
// Grid A*: units may share a tile, avoiding congestion deadlocks.
export function pathfind(s,from,to){
 const start={x:Math.round(from.x),y:Math.round(from.y)},end={x:Math.round(to.x),y:Math.round(to.y)};
 if(blocked(s,end.x,end.y))return null;
 const key=p=>p.x+','+p.y,open=[start],came=new Map(),g=new Map([[key(start),0]]),closed=new Set();
 while(open.length){
  open.sort((a,b)=>(g.get(key(a))+dist(a,end))-(g.get(key(b))+dist(b,end)));
  const p=open.shift(),k=key(p);if(k===key(end)){const route=[];let q=p;while(key(q)!==key(start)){route.unshift(q);q=came.get(key(q));}return route;}
  if(closed.has(k))continue;closed.add(k);
  for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
   const n={x:p.x+dx,y:p.y+dy},nk=key(n);
   if(closed.has(nk)||blocked(s,n.x,n.y)||(dx&&dy&&(blocked(s,p.x+dx,p.y)||blocked(s,p.x,p.y+dy))))continue;
   const score=g.get(k)+Math.hypot(dx,dy);if(score<(g.get(nk)??Infinity)){came.set(nk,p);g.set(nk,score);open.push(n);}
  }
 }return null;
}
function accessPoints(s,target){
 const size=target.size||1,candidates=[];
 for(let x=Math.floor(target.x)-1;x<=Math.floor(target.x)+size;x++)for(let y=Math.floor(target.y)-1;y<=Math.floor(target.y)+size;y++)if(!blocked(s,x,y))candidates.push({x,y});
 return candidates;
}
function approach(s,u,target){
 const candidates=accessPoints(s,target);
 candidates.sort((a,b)=>dist(u,a)-dist(u,b));
 for(const p of candidates){const route=pathfind(s,u,p);if(route)return route;}return null;
}
export function command(s,ids,action,target){
 let count=0;
 for(const id of ids){const u=s.units.find(u=>u.id===id&&u.hp>0&&u.faction==='player');if(!u)continue;
  if(action==='move'){
   const offset=count?{x:Math.round(target.x)+((count-1)%3)-1,y:Math.round(target.y)+Math.floor((count-1)/3)+1}:target;
   const route=pathfind(s,u,offset)||pathfind(s,u,target);if(!route)continue;
   u.path=route;u.task={kind:'move'};u.progress=0;count++;
  }else if(action==='gather'&&u.kind==='worker'){
   const node=entity(s,target);if(!node||(!node.amount&&node.kind!=='farm')||node.remaining)continue;
   const route=approach(s,u,node);if(!route)continue;
   u.path=route;u.task={kind:'gather',target:node.id};u.progress=0;count++;
  }else if(action==='attack'&&u.kind==='soldier'){
   const enemy=s.units.find(e=>e.id===target&&e.faction==='enemy'&&e.hp>0);if(!enemy)continue;
   u.task={kind:'attack',target};u.path=[];count++;
  }else if(action==='stop'){u.path=[];u.task=null;u.progress=0;count++;}
 }return count;
}
export function recruit(s,id,kind){
 const b=s.buildings.find(b=>b.id===id),expected=kind==='worker'?'townhall':'barracks';
 if(!b||b.kind!==expected||b.remaining)return {ok:false,message:'This building is not ready.'};
 if(b.queue.length>=3)return {ok:false,message:'Training queue is full.'};
 if(reservedPopulation(s)>=capacity(s))return {ok:false,message:'More homes needed. Build or upgrade a cottage.'};
 const cost=kind==='worker'?RULES.workerCost:RULES.soldierCost;
 if(!canPay(s,cost))return {ok:false,message:'Not enough resources.'};pay(s,cost);
 b.queue.push({kind,remaining:kind==='worker'?RULES.workerTime:RULES.soldierTime,total:kind==='worker'?RULES.workerTime:RULES.soldierTime});return {ok:true,message:kind==='worker'?'A villager is preparing to join you.':'A shieldbearer is training.'};
}
export function construct(s,kind,x,y){
 const def=BUILDINGS[kind];if(!def||kind==='townhall')return {ok:false,message:'Choose a building from the build menu.'};
 if(!canPlace(s,kind,x,y))return {ok:false,message:'Choose clear, dry ground away from people and trees.'};
 if(!canPay(s,def.cost))return {ok:false,message:'Not enough resources.'};pay(s,def.cost);
 const b=makeBuilding(s,kind,x,y);b.remaining=def.time;b.total=def.time;b.constructing=true;return {ok:true,message:def.name+' construction started.',id:b.id};
}
export function upgradeCost(b){return {wood:35*b.level,stone:20*b.level,gold:20*b.level};}
export function upgrade(s,id){
 const b=s.buildings.find(b=>b.id===id);if(!b||b.remaining||b.queue.length||b.level>=10)return {ok:false,message:'Finish current work first. Maximum level is 10.'};
 const cost=upgradeCost(b);if(!canPay(s,cost))return {ok:false,message:'Not enough resources to upgrade.'};pay(s,cost);b.remaining=RULES.upgradeTime+b.level;b.total=b.remaining;b.upgrading=true;return {ok:true,message:'Upgrade underway. Housing capacity updates when finished.'};
}
export function moveBuilding(s,id,x,y){const b=s.buildings.find(b=>b.id===id);if(!b||b.remaining||b.queue.length)return {ok:false,message:'Finish this building’s work before moving it.'};if(!canPlace(s,b.kind,x,y,b.id))return {ok:false,message:'This space is occupied.'};b.x=x;b.y=y;for(const u of s.units){if(u.path.some(p=>blocked(s,p.x,p.y)))u.path=[];}return {ok:true,message:'Building moved.'};}
export function repair(s,id){const b=s.buildings.find(b=>b.id===id);if(!b||b.hp>=b.maxHp)return {ok:false,message:'This building is already sound.'};const cost={wood:15,stone:10};if(!canPay(s,cost))return {ok:false,message:'Repair needs 15 wood and 10 stone.'};pay(s,cost);b.hp=b.maxHp;return {ok:true,message:'Repairs complete.'};}
export function collect(s,id){const i=s.drops.findIndex(d=>d.id===id);if(i<0)return false;const d=s.drops[i];s.resources[d.resource]+=d.amount;if(d.resource==='wood')s.stats.wood+=d.amount;s.effects.push({kind:'resource',x:d.x,y:d.y,text:'+'+d.amount+' '+d.resource,life:1.8});s.drops.splice(i,1);return true;}
function effect(s,kind,x,y,text=''){s.effects.push({kind,x,y,text,life:kind==='death'?1.2:0.7});}
function hit(s,attacker,target,damage){target.hp=Math.max(0,target.hp-damage);effect(s,'hit',target.x,target.y,'−'+damage);if(target.hp===0){target.task=null;target.path=[];target.dead=1.2;effect(s,'death',target.x,target.y);if(target.faction==='enemy'){s.stats.kills++;awardXP(s,'enemy',target.x,target.y);s.resources.gold+=20;effect(s,'resource',target.x,target.y,'+20 gold');}}}
function stepUnit(s,u,dt){
 if(u.hp<=0){u.dead=Math.max(0,u.dead-dt);return;}
 u.attackTimer=Math.max(0,u.attackTimer-dt);
 if(u.kind!=='worker'){
  let target=u.task?.kind==='attack'?s.units.find(e=>e.id===u.task.target&&e.hp>0&&e.faction!==u.faction):null;
  if(u.task?.kind==='attack'&&!target){u.task=null;u.path=[];}
  if(!target&&u.task?.kind!=='move')target=s.units.filter(e=>e.faction!==u.faction&&e.hp>0&&dist(u,e)<(u.faction==='enemy'?4:3.3)&&dist(u.home,e)<(u.faction==='enemy'?6:8)).sort((a,b)=>dist(u,a)-dist(u,b))[0];
  if(target){
   const facing=target.x-target.y-u.x+u.y;if(Math.abs(facing)>.01)u.facing=facing;
   if(dist(u,target)<1.35){u.path=[];if(u.attackTimer===0){u.attackTimer=0.9;hit(s,u,target,u.kind==='raider'?12:23);}}
   else if(!u.path.length||dist(u.path.at(-1),target)>2){u.path=approach(s,u,target)||[];}
  }
 }
 if(u.path.length){
  const p=u.path[0];if(blocked(s,p.x,p.y)){u.path=[];return;}
  const d=dist(u,p),speed=(u.kind==='worker'?RULES.workerSpeed:RULES.soldierSpeed)*dt;
  if(d<=speed){u.x=p.x;u.y=p.y;u.path.shift();}else{u.x+=(p.x-u.x)/d*speed;u.y+=(p.y-u.y)/d*speed;}
  const facing=p.x-p.y-u.x+u.y;if(Math.abs(facing)>.01)u.facing=facing;
  if(!u.path.length&&u.task?.kind==='move'){u.task=null;u.home={x:u.x,y:u.y};}
 }else if(u.task?.kind==='gather'){
  const n=entity(s,u.task.target);if(!n||n.amount===0||n.remaining){u.task=null;u.progress=0;return;}
  if(dist(u,{x:n.x+(n.size||1)/2-.5,y:n.y+(n.size||1)/2-.5})>(n.size?2.7:1.6)){u.path=approach(s,u,n)||[];return;}
  u.progress+=dt;if(u.progress>=RULES.gatherTime){u.progress=0;const amount=Math.min(RULES.gatherAmount,n.amount??Infinity);if(n.amount!==undefined)n.amount-=amount;
   const resource=n.kind==='tree'?'wood':n.kind==='farm'?'food':n.kind;
   const pile=s.drops.find(d=>d.source===n.id&&d.resource===resource);if(pile)pile.amount+=amount;else s.drops.push({id:'d'+s.nextId++,source:n.id,x:u.x+.15,y:u.y+.15,resource,amount});
   awardXP(s,'gather',u.x,u.y);effect(s,'spark',u.x,u.y);if(n.amount===0)u.task=null;
  }
 }
}
export function tick(s,dt){
 if(!Number.isFinite(dt)||dt<=0)return;dt=Math.min(dt,0.1);s.time+=dt;
 for(const b of s.buildings){
  if(b.remaining>0){b.remaining=Math.max(0,b.remaining-dt);if(!b.remaining){if(b.upgrading){b.level++;b.maxHp=Math.round(BUILDINGS[b.kind].health*(1+(b.level-1)*.2));b.hp=b.maxHp;b.upgrading=false;s.stats.upgrades++;awardXP(s,'upgrade',b.x+b.size/2,b.y+b.size/2);}if(b.constructing){b.constructing=false;s.stats.built++;awardXP(s,'construct',b.x+b.size/2,b.y+b.size/2);}effect(s,'complete',b.x+b.size/2,b.y+b.size/2);}}
  if(!b.remaining&&b.queue.length){const q=b.queue[0];q.remaining=Math.max(0,q.remaining-dt);if(!q.remaining){const spawn=accessPoints(s,b).sort((a,c)=>(c.x+c.y)-(a.x+a.y))[0];if(spawn){makeUnit(s,q.kind,spawn.x,spawn.y);s.stats[q.kind==='worker'?'recruited':'trained']++;awardXP(s,q.kind==='worker'?'recruit':'train',spawn.x,spawn.y);b.queue.shift();}else q.remaining=.25;}}
  if(b.kind==='tower'&&!b.remaining){b.cooldown-=dt;if(b.cooldown<=0){const center={x:b.x+1,y:b.y+1},target=s.units.find(u=>u.faction==='enemy'&&u.hp>0&&dist(center,u)<7);if(target){hit(s,b,target,28);effect(s,'arrow',target.x,target.y);b.cooldown=1.2;}}}
 }
 for(const u of s.units)stepUnit(s,u,dt);
 for(const e of s.effects)e.life-=dt;s.effects=s.effects.filter(e=>e.life>0);
 if(s.units.filter(u=>u.faction==='enemy').every(u=>u.hp===0)&&!s.victory){s.victory=true;s.notice='The frontier is safe. Your people have a future here.';}
}
export function saveGame(s){return JSON.stringify({...s,effects:[]});}
export function loadGame(text){
 try{const s=JSON.parse(text);if(s.version!==1||!Array.isArray(s.buildings)||!Array.isArray(s.units)||!Array.isArray(s.nodes)||!Array.isArray(s.drops)||!s.resources||!s.stats||!Number.isFinite(s.nextId)||!Number.isFinite(s.time))return null;
  if(!['gold','wood','food','stone','cash'].every(k=>Number.isFinite(s.resources[k])&&s.resources[k]>=0))return null;
  if(s.units.some(u=>!Number.isFinite(u.x)||!Number.isFinite(u.y)||!Array.isArray(u.path))||s.buildings.some(b=>!BUILDINGS[b.kind]||!Array.isArray(b.queue)))return null;
  s.effects=[];progressionInfo(s);return s;
 }catch{return null;}
}
