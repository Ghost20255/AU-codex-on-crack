// Small configurable rewards for actual village work, never for receiving gifts.
export const XP_RULES={gather:3,recruit:5,construct:8,upgrade:12,train:6,enemy:12,levelBase:30};
export function progressionInfo(s){
 if(!s.progression||!Number.isFinite(s.progression.xp)||s.progression.xp<0)s.progression={xp:0};
 const xp=Math.floor(s.progression.xp),base=XP_RULES.levelBase;
 const level=Math.floor((1+Math.sqrt(1+8*xp/base))/2);
 const start=base*level*(level-1)/2,next=base*level*(level+1)/2;
 return {xp,level,current:xp-start,required:next-start,fraction:(xp-start)/(next-start)};
}
export function awardXP(s,action,x,y){
 const amount=XP_RULES[action];if(!amount||s.scene==='founder')return;
 const before=progressionInfo(s);s.progression.xp+=amount;const after=progressionInfo(s);
 if(s.effects){s.effects.push({kind:'xp',x,y,text:'+'+amount+' XP',life:1.7});if(after.level>before.level)s.effects.push({kind:'levelup',x,y,text:'Level '+after.level+'!',life:2.5});}
}
