// The creator's authored showcase kingdom. All visits and rewards run locally.
export const FOUNDER={ruler:'Sahir Ibn Raydan',kingdom:'Areweyn Kingdom',motto:'Build a home worth standing beside.',banner:'The first ally',description:'An old kingdom that remembers what it means to start with nothing.'};
export const PATRON_RULES={supplies:{wood:25,food:20},maxSupplies:6};
export const VILLAGE_MILESTONES=[
 {id:'recruit',label:'Welcome a villager',done:s=>s.stats.recruited>0},
 {id:'gather',label:'Gather 36 wood yourself',done:s=>s.stats.wood>=36},
 {id:'home',label:'Complete a new cottage',done:s=>s.stats.built>0&&s.buildings.filter(b=>b.kind==='house'&&!b.remaining).length>1},
 {id:'army',label:'Train a shieldbearer',done:s=>s.stats.trained>0},
 {id:'upgrade',label:'Finish an upgrade',done:s=>s.stats.upgrades>0}
];
export function ensurePatronage(s){
 if(!s.patronage||typeof s.patronage!=='object')s.patronage={visited:false,suppliesClaimed:0};
 if(typeof s.patronage.visited!=='boolean')s.patronage.visited=false;
 if(!Number.isInteger(s.patronage.suppliesClaimed)||s.patronage.suppliesClaimed<0||s.patronage.suppliesClaimed>PATRON_RULES.maxSupplies)s.patronage.suppliesClaimed=0;
 return s.patronage;
}
export function supplyAllowance(s){return Math.min(PATRON_RULES.maxSupplies,1+VILLAGE_MILESTONES.filter(m=>m.done(s)).length);}
export function supplyParcels(s){return Math.max(0,supplyAllowance(s)-ensurePatronage(s).suppliesClaimed);}
export function visitFounder(s){ensurePatronage(s).visited=true;return {ok:true,message:'Welcome to '+FOUNDER.kingdom+'.'};}
export function claimSupplies(s){
 const p=ensurePatronage(s);
 if(!p.visited)return {ok:false,message:'Visit your ally to collect a supply parcel.'};
 if(supplyParcels(s)<1)return {ok:false,message:'Complete another village goal to earn a new supply parcel.'};
 for(const[k,n]of Object.entries(PATRON_RULES.supplies))s.resources[k]+=n;
 p.suppliesClaimed++;return {ok:true,message:'Supply parcel collected: 25 wood and 20 food. Your own villagers keep the kingdom growing.'};
}
export function createFounderEstate(definitions){
 const buildings=[],units=[];let id=1;
 function add(kind,x,y,level=10,label=null){const d=definitions[kind];buildings.push({id:'estate-b'+id++,kind,x,y,size:d.size,level,hp:d.health*(1+(level-1)*.2),maxHp:d.health*(1+(level-1)*.2),remaining:0,total:0,queue:[],cooldown:0,label});}
 add('townhall',12,10,10,'Sahir’s Keep');
 add('tower',8,10,10);add('tower',17,10,10);add('tower',8,17,8);add('tower',19,16,8);
 add('house',10,15,5);add('house',13,17,5);add('house',7,14,10);add('house',17,18,5);
 add('barracks',17,13,10,'Royal Barracks');add('farm',10,20,5);add('farm',13,21,5);
 const points=[[13,14],[14,14],[15,14],[17,17],[18,17],[19,18],[11,17],[12,18]];
 for(const[x,y]of points)units.push({id:'estate-u'+id++,kind:'soldier',x,y,faction:'ally',hp:240,maxHp:240,path:[],task:null,progress:0,attackTimer:0,home:{x,y},dead:0,royal:true});
 units.push({id:'founder-ruler',kind:'soldier',x:14,y:15,faction:'ally',hp:1000,maxHp:1000,path:[],task:null,progress:0,attackTimer:0,home:{x:14,y:15},dead:0,royal:true,ruler:true});
 const trees=[[5,7],[6,8],[9,5],[13,5],[18,5],[22,8],[23,12],[23,19],[20,23],[17,25],[8,23],[5,18],[6,13]];
 return {scene:'founder',time:0,buildings,units,nodes:trees.map(([x,y],i)=>({id:'estate-tree'+i,kind:'tree',x,y,amount:108})),drops:[],effects:[]};
}
export const BLUEPRINTS=[
 {id:'house',name:'Cottage',category:'village',visual:'house',description:'More room for your people. Each level strengthens your village.',available:true},
 {id:'farm',name:'Farm',category:'village',visual:'farm',description:'Put villagers to work harvesting food for the growing settlement.',available:true},
 {id:'barracks',name:'Barracks',category:'military',visual:'barracks',description:'Train the shieldbearers who will defend your own kingdom.',available:true},
 {id:'tower',name:'Watchtower',category:'military',visual:'tower',description:'An archer watches over the approaches to your village.',available:true},
 {id:'archery',name:'Archery Range',category:'military',visual:'barracks',description:'A planned home for ranged soldiers. This is a preview, not yet trainable.',chapter:'A Watch on the Border'},
 {id:'stables',name:'Stables',category:'military',visual:'house',description:'Future cavalry will bring speed and flanking opportunities.',chapter:'The Open Road'},
 {id:'market',name:'Market Hall',category:'village',visual:'barracks',description:'A future meeting place for trade and neighboring kingdoms.',chapter:'Roads Between Us'},
 {id:'warehouse',name:'Great Warehouse',category:'village',visual:'house',description:'Planned storage and supply logistics for a larger kingdom.',chapter:'A Growing Kingdom'},
 {id:'nest',name:'Dragon Sanctuary',category:'legend',visual:'townhall',description:'A future story discovery. Dragons must be earned through exploration and progress.',chapter:'Ash Beneath the Mountain'},
 {id:'siege',name:'Siege Workshop',category:'military',visual:'barracks',description:'Planned siege engines for a later conquest chapter.',chapter:'Beyond the Gates'}
];
