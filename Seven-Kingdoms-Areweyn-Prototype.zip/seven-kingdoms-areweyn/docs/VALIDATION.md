# Current milestone: Areweyn creator ally (0.2.0)

The updated game passed 16 simulation tests, the 11 original browser scenarios, and 10 new ally browser scenarios. See `AREWEYN-PROTOTYPE.md` for the new scope, supply limits, save compatibility, and the pending roll clarification. The results below describe the original village milestone and remain useful baseline evidence.

# Executed validation

The current slice was run with Node 24.19.0 and headless Chromium on Linux.

- **10 simulation tests passed:** recruitment and resource spending, concurrent population reservations, worker travel/gathering/collection, construction footprints and capacity, all ten upgrade levels, obstacle-aware pathfinding, building movement restrictions, combat ownership/victory, all four earned resource types, and in-progress save roundtrips with malformed-input rejection.
- **11 browser scenarios passed:** initial rendering, recruitment, tree work and collection, construction, upgrade and relocation, Barracks training and drag selection, troop movement and defeating all three raiders, camera controls, paused settings/export, saved-village restoration, and narrow viewport controls.
- Browser monitoring found **no page errors or failed HTTP responses** in the completed run.
- Screenshots were reviewed. A narrow-screen build-palette overlap was fixed, then the simulation and complete browser checks were rerun successfully.
- A stuck recruitment spawn was found by simulation testing and corrected before the completed run.
- `npm ci` succeeded with the frozen lockfile. Runtime uses only Node built-ins and browser APIs.
- The uploaded reference executable's SHA-256 was checked again after development and was unchanged. Neither existing repository acquired tracked changes.

Machine-readable browser results are in `artifacts/browser-results.json`; simulation output is in `artifacts/simulation-results.txt`. Screenshots show the actual running game, not design mockups. Test profiles are separate from personal browser profiles.

## Limits

The Windows convenience launcher has not been run on Windows. Firefox, Safari, actual touchscreen devices, and long-term balance have not been validated. The browser saves locally; there is no cloud account, multiplayer, server-authoritative economy or offline production. Original-game client playback and missing game-data files remain unverified. Conquest, dragons, cavalry, ranged armies and the wider seven-kingdom map are future work, as detailed in the roadmap.
