import {createGame,entity,capacity,population,reservedPopulation,command,recruit,construct,upgrade,upgradeCost,repair,moveBuilding,collect,tick,saveGame,loadGame,BUILDINGS,RULES,canPay} from './sim.js';
import {Renderer} from './render.js';
const $=id=>document.getElementById(id),canvas=$('world'),ctx=$('context'),dialog=$('dialog');
const SAVE='seven-kingdoms-frontier-v1',BACKUP=SAVE+'-unreadable-backup';
let storageAvailable=true,restored=false;
function readSave(){try{const raw=localStorage.getItem(SAVE);if(!raw)return null;const game=loadGame(raw);if(!game)localStorage.setItem(BACKUP,raw);return game;}catch{storageAvailable=false;return null;}}
export let state=readSave()||createGame();restored=state.time>0;
export const renderer=new Renderer(canvas);
export const ui={selected:new Set(),placement:null,hover:null,hoverName:'',mouse:null,box:null,marker:null,hoverCollect:false,paused:false};
let last=performance.now(),updateTimer=0,saveTimer=0,toastTimer=0,drag=null,space=false,contextKey='',lastVictory=state.victory,lastMissionCount=-1;
const icons={gold:'◈',wood:'▰',food:'❧',stone:'⬟',cash:'✦',townhall:'♜',house:'⌂',barracks:'⚔',farm:'❧',tower:'♖',worker:'♟',soldier:'⚔',raider:'⚔',tree:'♠'};
const resourceNames={gold:'GOLD',wood:'WOOD',food:'FOOD',stone:'STONE',cash:'CASH'};
const costText=cost=>Object.entries(cost).map(([k,v])=>v+' '+k).join(' · ');
const titleCase=t=>t[0].toUpperCase()+t.slice(1);
export function notify(message){$('toast').textContent=message;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),3600);}
function result(r){notify(r.message);if(r.ok)contextKey='';updateUI();return r;}
function persist(){try{localStorage.setItem(SAVE,saveGame(state));$('save-status').textContent='Local kingdom · Progress saved';storageAvailable=true;}catch{storageAvailable=false;$('save-status').textContent='Storage unavailable · Export to keep progress';}}
function selected(){return [...ui.selected].map(id=>entity(state,id)).filter(Boolean);}
function select(ids){ui.selected=new Set(ids);contextKey='';updateUI();}
function taskName(u){return u.path?.length?'Travelling':u.task?.kind==='gather'?'Gathering':u.task?.kind==='attack'?'In battle':'Ready';}
function progressHTML(b){if(b.remaining)return `<div class="queue"><span style="width:${(1-b.remaining/b.total)*100}%"></span></div><p>${b.upgrading?'Upgrading':'Constructing'} · ${Math.ceil(b.remaining)}s remaining</p>`;if(b.queue.length)return `<div class="queue"><span style="width:${(1-b.queue[0].remaining/b.queue[0].total)*100}%"></span></div><p>${b.queue[0].kind==='worker'?'Recruiting villager':'Training shieldbearer'} · ${Math.ceil(b.queue[0].remaining)}s · ${b.queue.length} queued</p>`;return '';}
function action(id,title,sub='',primary=false,disabled=false){return `<button class="action${primary?' primary':''}" data-action="${id}" ${disabled?'disabled':''}><strong>${title}</strong>${sub?`<small>${sub}</small>`:''}</button>`;}
function showContext(){
 const items=selected();const k=JSON.stringify({ids:[...ui.selected],placement:ui.placement,queues:state.buildings.map(b=>[b.level,b.queue.length,Math.ceil(b.remaining),b.queue[0]&&Math.ceil(b.queue[0].remaining)]),res:state.resources,pop:reservedPopulation(state),units:items.map(u=>[u.hp,taskName(u)]),drops:state.drops.map(d=>[d.id,d.amount])});if(k===contextKey)return;contextKey=k;
 let portrait='♜',eyebrow='YOUR STORY STARTS HERE',title='A kingdom of your own',desc='Recruit a villager, gather wood, and give your people a place to call home.',actions=action('townhall','Visit Town Hall','Recruit & develop',true)+action('build','Build a home','Grow the village');
 if(ui.placement){portrait=icons[ui.placement.kind];eyebrow=ui.placement.id?'VILLAGE EDITING':'PLAN YOUR VILLAGE';title=(ui.placement.id?'Move ':'Place ')+BUILDINGS[ui.placement.kind].name;desc='Click clear ground to place. Green means available; red means occupied.';actions=action('cancel','Cancel','Esc');}
 else if(items.length){
  const first=items[0];portrait=icons[first.kind]||'◈';
  if(first.size){
   eyebrow='WILLOWMERE · LEVEL '+first.level;title=BUILDINGS[first.kind].name;desc=BUILDINGS[first.kind].description+progressHTML(first);actions='';
   const busy=!!first.remaining;
   if(first.kind==='townhall')actions+=action('recruit','Recruit villager',costText(RULES.workerCost),true,busy||!canPay(state,RULES.workerCost)||reservedPopulation(state)>=capacity(state));
   if(first.kind==='barracks')actions+=action('train','Train shieldbearer',costText(RULES.soldierCost),true,busy||!canPay(state,RULES.soldierCost)||reservedPopulation(state)>=capacity(state));
   if(first.kind==='farm')actions+=action('workers','Select villagers','Then click this farm',true);
   actions+=action('upgrade','Upgrade'+(first.level<10?' → '+(first.level+1):' complete'),first.level<10?costText(upgradeCost(first)):'Maximum level',false,busy||first.level>=10||first.queue.length>0||!canPay(state,upgradeCost(first)));
   actions+=action('move-building','Move','Choose new location',false,busy||first.queue.length>0);
   if(first.hp<first.maxHp)actions+=action('repair','Repair','15 wood · 10 stone');
  }else if(first.faction){
   const workers=items.filter(x=>x.kind==='worker').length,soldiers=items.filter(x=>x.kind==='soldier').length;
   if(first.faction==='enemy'){eyebrow='ASHEN RAIDERS';title='Frontier raider';desc='These raiders guard the eastern road. Select shieldbearers and click a raider to attack.';actions=action('army','Select your army','March together',true);}
   else{eyebrow=items.length>1?'SELECTED COMPANY':taskName(first).toUpperCase();title=items.length>1?`${items.length} ${workers===items.length?'villagers':soldiers===items.length?'shieldbearers':'units'}`:workers?'Villager':'Shieldbearer';desc=workers?'Click a tree, quarry, gold vein, or farm to gather. Click the glowing bundles to collect.':'Click clear ground to move. Click a raider to attack. Soldiers defend against nearby enemies.';actions=action('stop','Stop','Hold position')+action(workers?'workers':'army','Select all',workers?'All villagers':'All shieldbearers');}
  }else if(first.resource){eyebrow='READY TO COLLECT';title=titleCase(first.resource)+' bundle';desc='Your villagers have gathered '+first.amount+' '+first.resource+'.';actions=action('collect','Collect','+'+first.amount+' '+first.resource,true);}
  else{eyebrow='NATURAL RESOURCE';title=first.kind==='tree'?'Oldwood grove':first.kind==='gold'?'Gold vein':'Stone outcrop';desc=(first.amount?first.amount+' remaining. ':'Depleted. ')+(first.kind==='tree'?'Select villagers, then click this tree to chop wood.':'Select villagers, then click here to gather.');actions=action('workers','Select villagers','Then assign a job',true);}
 }
 ctx.innerHTML=`<div class="portrait" aria-hidden="true">${portrait}</div><div class="context-copy"><span class="eyebrow">${eyebrow}</span><h2>${title}</h2><div class="context-description"><p>${desc}</p></div></div><div class="actions">${actions}</div>${items.length||ui.placement?'<button class="close" data-action="deselect" aria-label="Clear selection">×</button>':''}`;
}
function updateUI(){
 $('resources').innerHTML=Object.entries(state.resources).map(([k,v])=>`<div class="resource${k==='cash'?' premium':''}" title="${k==='cash'?'Optional premium cash. Not used or purchasable in this slice.':titleCase(k)}"><span class="icon" style="color:${{gold:'#e6bd65',wood:'#c6a27a',food:'#b8cf85',stone:'#c2c7b3',cash:'#c5b3df'}[k]}">${icons[k]}</span><div><strong>${Math.floor(v).toLocaleString()}</strong><small>${resourceNames[k]}</small></div></div>`).join('');
 const cap=capacity(state),pop=population(state),reserved=reservedPopulation(state);$('population').textContent=pop+' / '+cap+(reserved>pop?' +'+(reserved-pop)+' queued':'');$('popfill').style.width=Math.min(100,reserved/cap*100)+'%';
 const missions=[['Welcome a new villager',state.stats.recruited>0],['Collect 36 wood',state.stats.wood>=36],['Build a cottage',state.stats.built>0&&state.buildings.some(b=>b.kind==='house'&&!b.remaining&&b.id!=='b2')],['Train a shieldbearer',state.stats.trained>0]];
 const done=missions.filter(m=>m[1]).length;$('mission-count').textContent=done+' / 4';$('missions').innerHTML=missions.map(([text,done])=>`<div class="mission${done?' done':''}"><i>${done?'✓':''}</i>${text}</div>`).join('');
 if(done===4){$('quest-note').innerHTML='<span class="milestone">A village worth defending.</span><br>Rally your army and clear the eastern road.';if(lastMissionCount!==4&&lastMissionCount>=0)notify('Chapter complete! Rally your soldiers and drive out the three raiders.');}
 lastMissionCount=done;
 if(state.victory){$('quest-note').innerHTML='<span class="milestone">The eastern road is safe.</span><br>Keep building. This is only the beginning.';if(!lastVictory){notify('Victory! The raiders are defeated. Your village endures.');persist();}lastVictory=true;}
 showContext();
}
function toggleBuild(open=$('build-menu').hidden){document.body.classList.toggle('building-open',open);$('build-menu').hidden=!open;$('build-toggle').classList.toggle('active',open);if(open){$('building-cards').innerHTML=['house','barracks','farm','tower'].map(kind=>{const d=BUILDINGS[kind];return `<button class="building-card" data-build="${kind}" ${!canPay(state,d.cost)?'disabled':''}><span class="building-icon">${icons[kind]}</span><strong>${d.name}</strong><small>${costText(d.cost)}</small><div class="time">◷ ${d.time} seconds</div></button>`;}).join('');}}
function handleAction(type){
 const e=selected()[0];
 if(type==='build')toggleBuild();
 if(type==='townhall'){const b=state.buildings.find(b=>b.kind==='townhall');select([b.id]);const p=renderer.screen(b.x+1,b.y+1);renderer.camera.x+=renderer.w*.55-p.x;renderer.camera.y+=renderer.h*.48-p.y;}
 if(type==='recruit'&&e)result(recruit(state,e.id,'worker'));
 if(type==='train'&&e)result(recruit(state,e.id,'soldier'));
 if(type==='upgrade'&&e)result(upgrade(state,e.id));
 if(type==='repair'&&e)result(repair(state,e.id));
 if(type==='move-building'&&e){ui.placement={kind:e.kind,id:e.id};toggleBuild(false);contextKey='';updateUI();notify('Click a clear location for your '+BUILDINGS[e.kind].name+'.');}
 if(type==='army'||type==='workers'){const kind=type==='army'?'soldier':'worker';select(state.units.filter(u=>u.kind===kind&&u.hp>0&&u.faction==='player').map(u=>u.id));}
 if(type==='stop'){command(state,[...ui.selected],'stop');notify('Orders cancelled. Soldiers will still defend nearby allies.');}
 if(type==='collect'&&e){collect(state,e.id);select([]);}
 if(type==='cancel'||type==='deselect'){ui.placement=null;select([]);}
}
ctx.addEventListener('click',e=>{const button=e.target.closest('[data-action]');if(button)handleAction(button.dataset.action);});
$('build-menu').addEventListener('click',e=>{const b=e.target.closest('[data-build]');if(b){ui.placement={kind:b.dataset.build};toggleBuild(false);contextKey='';updateUI();notify('Choose a clear site for your '+BUILDINGS[ui.placement.kind].name+'.');}});
$('build-toggle').onclick=()=>toggleBuild();$('build-close').onclick=()=>toggleBuild(false);$('army').onclick=()=>handleAction('army');$('home').onclick=()=>renderer.home();$('zoom-in').onclick=()=>renderer.zoomAt(1.15);$('zoom-out').onclick=()=>renderer.zoomAt(1/1.15);
function hitTest(x,y){
 const screen=(e,offset=0)=>{const p=renderer.screen(e.x,e.y);return {x:p.x,y:p.y-offset*renderer.camera.zoom};};
 for(const d of [...state.drops].reverse()){const p=screen(d,8);if(Math.hypot(x-p.x,y-p.y)<20*renderer.camera.zoom)return d;}
 for(const u of [...state.units].reverse()){if(u.hp<=0)continue;const p=screen(u,16);if(Math.abs(x-p.x)<14*renderer.camera.zoom&&Math.abs(y-p.y)<22*renderer.camera.zoom)return u;}
 const w=renderer.world(x,y);
 // Full artwork hit targets allow clicking a roof or canopy, as well as the footprint.
 const candidates=[...state.buildings,...state.nodes.filter(n=>n.amount>0)].sort((a,b)=>(b.x+b.y+(b.size||0))-(a.x+a.y+(a.size||0)));
 for(const e of candidates){const p=renderer.screen(e.x+((e.size||1)-1)/2,e.y+((e.size||1)-1)/2),width=(e.size?e.size*23:22)*renderer.camera.zoom,height=(e.size?100:e.kind==='tree'?87:35)*renderer.camera.zoom;if(Math.abs(x-p.x)<width&&y<p.y+15*renderer.camera.zoom&&y>p.y-height)return e;if(e.size&&w.x>=e.x-.45&&w.x<e.x+e.size-.45&&w.y>=e.y-.45&&w.y<e.y+e.size-.45)return e;}
 return null;
}
function clickWorld(e,x,y){
 const w=renderer.world(x,y),hit=hitTest(x,y),ids=[...ui.selected];
 if(ui.placement){const placement=ui.placement,px=Math.round(w.x),py=Math.round(w.y);const r=placement.id?moveBuilding(state,placement.id,px,py):construct(state,placement.kind,px,py);result(r);if(r.ok){ui.placement=null;select([r.id||placement.id]);persist();}return;}
 if(hit?.resource){collect(state,hit.id);updateUI();return;}
 if(hit&&hit.faction==='player'){
  if(e.shiftKey){const next=new Set(ui.selected);if(next.has(hit.id))next.delete(hit.id);else next.add(hit.id);select([...next]);}else select([hit.id]);return;
 }
 if(hit&&hit.faction==='enemy'&&ids.some(id=>entity(state,id)?.kind==='soldier')){const n=command(state,ids,'attack',hit.id);if(n)notify(n+' shieldbearer'+(n>1?'s':'')+' advancing.');return;}
 if(hit&&(hit.amount>0||hit.kind==='farm')&&ids.some(id=>entity(state,id)?.kind==='worker')){const n=command(state,ids,'gather',hit.id);notify(n?n+' villager'+(n>1?'s':'')+' assigned. Collect the glowing bundles when ready.':'No path to this resource.');contextKey='';updateUI();return;}
 if(hit){select([hit.id]);return;}
 if(ids.some(id=>entity(state,id)?.faction==='player')){const n=command(state,ids,'move',{x:Math.round(w.x),y:Math.round(w.y)});if(n){ui.marker={x:Math.round(w.x),y:Math.round(w.y),life:1};contextKey='';}else notify('That ground is not reachable.');}else select([]);
}
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('pointerdown',e=>{if(e.button>2)return;canvas.focus({preventScroll:true});canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,pan:space||e.button===1||e.button===2,moved:false,pointer:e.pointerId,button:e.button};});
canvas.addEventListener('pointermove',e=>{
 ui.mouse={x:e.clientX,y:e.clientY};ui.hover=renderer.world(e.clientX,e.clientY);
 if(drag){const dx=e.clientX-drag.lastX,dy=e.clientY-drag.lastY;if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>5)drag.moved=true;if(drag.pan){renderer.camera.x+=dx;renderer.camera.y+=dy;canvas.style.cursor='grabbing';}else if(drag.moved){ui.box={x:Math.min(drag.x,e.clientX),y:Math.min(drag.y,e.clientY),w:Math.abs(e.clientX-drag.x),h:Math.abs(e.clientY-drag.y)};}drag.lastX=e.clientX;drag.lastY=e.clientY;return;}
 const hit=hitTest(e.clientX,e.clientY);ui.hoverName=hit?(hit.resource?'Collect '+hit.amount+' '+hit.resource:hit.faction?hit.faction==='enemy'?'Ashen raider':hit.kind==='worker'?'Villager · '+taskName(hit):'Shieldbearer · '+taskName(hit):hit.size?BUILDINGS[hit.kind].name+' · Level '+hit.level:hit.kind==='tree'?'Oldwood tree':hit.kind==='gold'?'Gold vein':'Stone outcrop'):'';
 if(hit?.resource&&ui.hoverCollect){collect(state,hit.id);updateUI();}
 canvas.style.cursor=ui.placement?'crosshair':hit?.faction==='enemy'&&selected().some(u=>u.kind==='soldier')?'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'32\' height=\'32\'%3E%3Ctext x=\'1\' y=\'24\' font-size=\'25\'%3E⚔%3C/text%3E%3C/svg%3E") 16 16, crosshair':hit?'pointer':space?'grab':'default';
});
canvas.addEventListener('pointerup',e=>{if(!drag)return;const d=drag;drag=null;if(ui.box){const b=ui.box;ui.box=null;const ids=e.shiftKey?[...ui.selected]:[];for(const u of state.units){if(u.hp<=0||u.faction!=='player')continue;const p=renderer.screen(u.x,u.y);if(p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h+22)ids.push(u.id);}select([...new Set(ids)]);}else if(!d.moved)clickWorld(e,e.clientX,e.clientY);canvas.style.cursor=space?'grab':'default';});
canvas.addEventListener('pointercancel',()=>{drag=null;ui.box=null;});
canvas.addEventListener('wheel',e=>{e.preventDefault();renderer.zoomAt(e.deltaY>0?1/1.1:1.1,e.clientX,e.clientY);},{passive:false});
window.addEventListener('keydown',e=>{if(dialog.open||['INPUT','TEXTAREA'].includes(e.target.tagName))return;if(e.code==='Space'){e.preventDefault();space=true;canvas.style.cursor='grab';}if(e.code==='Escape'){ui.placement=null;toggleBuild(false);select([]);}if(e.code==='KeyB')toggleBuild();if(e.code==='KeyH')renderer.home();if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD'].includes(e.code)){e.preventDefault();renderer.camera.x+=({ArrowLeft:35,KeyA:35,ArrowRight:-35,KeyD:-35}[e.code]||0);renderer.camera.y+=({ArrowUp:35,KeyW:35,ArrowDown:-35,KeyS:-35}[e.code]||0);}});
window.addEventListener('keyup',e=>{if(e.code==='Space'){space=false;canvas.style.cursor='default';}});window.addEventListener('blur',()=>{space=false;drag=null;ui.box=null;persist();});window.addEventListener('resize',()=>{renderer.resize();});
function openSettings(){
 ui.paused=true;dialog.querySelector('.modal-content').innerHTML=`<button class="close" id="modal-close" aria-label="Close controls">×</button><span class="eyebrow">THE FRONTIER · PLAYABLE FIRST SLICE</span><h2>Your kingdom, your pace.</h2><p>Start at the Town Hall. Recruit villagers, put them to work, and build another cottage. Train shieldbearers at the Barracks, then clear the three raiders on the eastern road.</p><div class="controls"><span><kbd>Click</kbd> Select / give orders</span><span><kbd>Drag</kbd> Select a group</span><span><kbd>Shift + click</kbd> Add to selection</span><span><kbd>Space + drag</kbd> Pan the camera</span><span><kbd>Wheel / + −</kbd> Zoom in or out</span><span><kbd>H</kbd> Home · <kbd>B</kbd> Build</span></div><label><input type="checkbox" id="hover-collect" ${ui.hoverCollect?'checked':''}> Collect resource bundles on hover</label><p>Your village is saved in this browser. No login, payment, or connection to the old game is used. The game pauses while this menu is open.</p><button class="action" id="export-save">Export village save</button><button class="action danger" id="reset-save">Start a new village…</button><p style="font-size:10px">Original procedural Canvas illustrations. This slice includes villagers, infantry, five buildings, resource gathering and upgrades. Territory, ranged armies, cavalry and dragons are later milestones.</p>`;
 dialog.showModal();$('modal-close').onclick=()=>dialog.close();$('hover-collect').onchange=e=>ui.hoverCollect=e.target.checked;
 $('export-save').onclick=()=>{persist();const url=URL.createObjectURL(new Blob([saveGame(state)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='willowmere-village.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('Village exported. Keep this file as a backup.');};
 $('reset-save').onclick=()=>{dialog.querySelector('.modal-content').innerHTML=`<h2>Begin again?</h2><p>Your current village will be kept as a backup in this browser. Export it first if you want a portable copy.</p><button class="action" id="keep-village">Keep my village</button> <button class="action danger" id="confirm-reset">Start new village</button>`;$('keep-village').onclick=()=>{dialog.close();};$('confirm-reset').onclick=()=>{try{localStorage.setItem(SAVE+'-previous-village',saveGame(state));}catch{notify('Backup could not be saved. Export your village before resetting.');return;}state=createGame();lastVictory=false;lastMissionCount=-1;select([]);ui.placement=null;renderer.home();persist();dialog.close();};};
}
dialog.addEventListener('close',()=>{ui.paused=false;last=performance.now();});$('settings').onclick=openSettings;$('help').onclick=openSettings;
document.addEventListener('visibilitychange',()=>{last=performance.now();if(document.hidden)persist();});window.addEventListener('pagehide',persist);
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(!ui.paused&&!document.hidden){tick(state,dt);if(ui.marker){ui.marker.life-=dt;if(ui.marker.life<=0)ui.marker=null;}updateTimer+=dt;saveTimer+=dt;if(updateTimer>.2){updateTimer=0;for(const id of ui.selected){const e=entity(state,id);if(!e||(e.hp!==undefined&&e.hp<=0))ui.selected.delete(id);}updateUI();}if(saveTimer>5){saveTimer=0;persist();}}renderer.draw(state,ui);requestAnimationFrame(frame);}
updateUI();requestAnimationFrame(frame);if(!storageAvailable)$('save-status').textContent='Storage unavailable · Export to keep progress';
if(restored)notify('Welcome back to Willowmere. Your village has been restored.');
