@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Please install Node.js 22 or newer, then run this file again.
 pause
 exit /b 1
)
echo Starting Seven Kingdoms. Keep this window open while playing.
start "Seven Kingdoms" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:4173"
node server.mjs
pause
