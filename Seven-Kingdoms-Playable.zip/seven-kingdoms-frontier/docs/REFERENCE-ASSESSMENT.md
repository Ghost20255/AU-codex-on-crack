# Reference assessment and roadmap

## Supplied implementation: observed facts

The uploaded `social-emperors_0.04a.exe` is a 5,513,943-byte Windows PE containing a PyInstaller archive for Python 3.13. Its SHA-256 is `2c16a6b268a848e3914adcd709d6a0cc1c4c75a54a306a5a3c0043f202e338ea`. REA's `inspect-artifact` identified it as `pyinstaller` and retained Evidence ID `ev_e50dfdcdeed1a0de01265db25c09e9ba457d9f99db6c88169b225b76cc015039`. The archive contains a `server` entry and a PYZ with 585 module entries. Inspection parsed archive tables and Python code objects without executing their code or launching the executable.

Static bytecode inspection establishes these implementation pieces:

- `server`: Flask routes for login/play, Ruffle, game configuration, player information, commands and rankings. Asset routes explicitly reference `SocialEmpires0926bsec.swf` and other original SWFs.
- `engine`: cost and collection helpers map gold/coins, wood, cash, stone and food, including configurable multipliers and XP.
- `sessions`: JSON village loading/saving, initialization, save backup, neighbor lookup and version migration.
- `command`: dispatch branches for add/move/collect/remove, missions, expansion, leveling, gifts and dragon-nest development counters. These branches exist; their gameplay correctness has **not** been runtime-tested.
- `get_game_config`: JSON configuration loading, duplicate-item removal, patches/mods, and item/level/mission lookup helpers.
- `bundle`: directory references to `assets`, `stub`, `templates`, `villages`, `quests`, `config`, `patch`, `mods`, and `saves`.

The supplied `base_library.zip` contains 154 Python runtime-library entries. Uploaded DLLs and PYDs are runtime dependencies; they do not establish that the Flash client or game content is present.

## Missing, inferred and unverified

The game's SWFs, client art, templates, initial village/configuration JSON, quests and saves were not supplied. The package refers to `game_config_20120826.json` and `initial.json`; these are not in the uploaded reference material inspected. The executable cannot establish a playable client by itself. No original gameplay, combat simulation, animations, balance, client/server command compatibility or save compatibility has been verified. A Ruffle route suggests a Flash-emulation route but does not demonstrate its success.

To investigate the old game further, supply its complete adjacent game-data folders and any saves. Preserve their directory structure, ideally as one ZIP. None of this blocks a separate original prototype.

## Reuse and redesign

Reuse **ideas** such as data-driven costs, queued production, resource categories, versioned saves and distinct client/simulation responsibilities. Do not treat the packaged Python custom code as freely reusable: no license for that implementation was supplied. Third-party runtime dependencies have their own licenses; those do not license the custom game implementation or original game media. This project does not redistribute them.

Build the browser interaction, renderer, economy, combat, progression, story, artwork and saved-state format independently. Existing Social Empires save data cannot be claimed compatible with the new game. The seven-kingdom world and new artwork are design work, not verified behavior extracted from this executable.

## Prioritized roadmap

1. **Playable village and combat slice (this milestone):** Town Hall recruitment, villagers, resource jobs and bundles, housing, Barracks, infantry selection/movement/combat, small raider encounter, construction/moving/upgrading, camera, contextual controls, local save. Original procedural illustrations establish a coherent first art pass. Test mechanics and real browser interactions before delivery.
2. **Make the core loop worth returning to:** user feedback on pacing, custom requested changes, stronger animation and illustrated assets, expanded objectives, defensive raids with building damage and repair, additional infantry behavior, archers and cavalry, richer level 1/5/10 building silhouettes, importable versioned saves. Add ranged/flying target rules before dragons.
3. **Conquest slice:** a neighboring settlement, contested ground-capture area, Town Hall capture without destruction, ownership banners and preserved building levels; test army defeat and capture as separate victory conditions. Add deliberate destruction and territory surrender only after this works.
4. **World and progression:** seven unequal kingdoms, a compact regional map, exploration, neutral villages, missions, markets and neighboring land purchases, simple AI responses. Avoid a giant world and deep dynasty/diplomacy systems.
5. **Dragon milestone:** original sanctuary legend and discovery quest, progression-locked nest, flying movement/shadows/wing motion, aerial attacks and anti-air counters, upkeep and recovery. Ground forces alone secure captures. No breeding system yet.
6. **Separate future project:** multiplayer authority, authentication, competitive fairness, cooperation and clans. Current local saves and client authority do not provide those guarantees.

No prices or timers were copied from the supplied implementation. Current small numbers are configurable test values. The working title and new kingdom names are provisional; no final branding decision is implied.
