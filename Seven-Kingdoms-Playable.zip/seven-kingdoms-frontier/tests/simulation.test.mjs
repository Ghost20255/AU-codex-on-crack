import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,capacity,population,reservedPopulation,command,recruit,construct,upgrade,moveBuilding,canPlace,collect,tick,saveGame,loadGame,entity,pathfind,blocked} from '../src/sim.js';
function advance(s,seconds){for(let i=0;i<seconds*20;i++)tick(s,.05);}
test('recruitment reserves capacity, costs resources, and produces a controllable villager',()=>{
 const s=createGame(),hall=s.buildings[0],before=population(s),food=s.resources.food;
 assert.equal(recruit(s,hall.id,'worker').ok,true);assert.equal(population(s),before);assert.equal(reservedPopulation(s),before+1);assert.equal(s.resources.food,food-25);
 advance(s,3.1);assert.equal(population(s),before+1);assert.equal(s.stats.recruited,1);assert.equal(hall.queue.length,0);
});
test('housing capacity is reserved across concurrent training queues',()=>{
 const s=createGame(),hall=s.buildings[0],barracks=s.buildings[2];s.resources.food=999;s.resources.gold=999;
 for(let i=0;i<3;i++)assert.equal(recruit(s,hall.id,'worker').ok,true);
 assert.equal(recruit(s,barracks.id,'soldier').ok,true);assert.equal(reservedPopulation(s),capacity(s));
 assert.equal(recruit(s,barracks.id,'soldier').ok,false);advance(s,12);assert.equal(population(s),capacity(s));
});
test('villagers travel to a tree, gather visible bundles, and collecting credits exactly once',()=>{
 const s=createGame(),u=s.units[0],tree=s.nodes[0],before=s.resources.wood,start={x:u.x,y:u.y};
 assert.equal(command(s,[u.id],'gather',tree.id),1);advance(s,1);assert.notDeepEqual({x:u.x,y:u.y},start);assert.equal(s.resources.wood,before);
 advance(s,15);assert.ok(s.drops.length);const d=s.drops[0],amount=d.amount;assert.ok(amount>=18);assert.equal(collect(s,d.id),true);assert.equal(s.resources.wood,before+amount);assert.equal(collect(s,d.id),false);
});
test('construction checks footprints, deducts once and increases capacity only when completed',()=>{
 const s=createGame(),cap=capacity(s),wood=s.resources.wood;
 assert.equal(construct(s,'house',12,11).ok,false);assert.equal(s.resources.wood,wood);
 const r=construct(s,'house',13,21);assert.equal(r.ok,true);assert.equal(s.resources.wood,wood-50);assert.equal(capacity(s),cap);advance(s,5.1);assert.equal(capacity(s),cap+4);assert.equal(s.stats.built,1);
});
test('ten-level upgrade system preserves identity, keeps occupancy and applies completed upgrades',()=>{
 const s=createGame(),b=s.buildings[1];s.resources={gold:1e6,wood:1e6,stone:1e6,food:1e6,cash:0};
 for(let level=2;level<=10;level++){assert.equal(upgrade(s,b.id).ok,true);assert.equal(upgrade(s,b.id).ok,false);advance(s,20);assert.equal(b.level,level);assert.equal(b.hp,b.maxHp);}
 assert.equal(upgrade(s,b.id).ok,false);assert.equal(s.stats.upgrades,9);
});
test('pathfinding routes around buildings and cannot cross water or clip diagonally',()=>{
 const s=createGame(),route=pathfind(s,{x:11,y:13},{x:16,y:12});assert.ok(route.length);for(const p of route)assert.equal(blocked(s,p.x,p.y),false);
 assert.equal(pathfind(s,{x:10,y:10},{x:0,y:0}),null);assert.equal(canPlace(s,'house',1,1),false);
});
test('a building can move only to clear ground and cannot move during training',()=>{
 const s=createGame(),b=s.buildings[1];assert.equal(moveBuilding(s,b.id,15,20).ok,true);assert.equal(b.x,15);assert.equal(moveBuilding(s,b.id,12,11).ok,false);
 assert.equal(recruit(s,s.buildings[0].id,'worker').ok,true);assert.equal(moveBuilding(s,s.buildings[0].id,20,3).ok,false);
});
test('orders reject non-owned units and army defeats raiders through actual combat',()=>{
 const s=createGame();s.resources.food=999;s.resources.gold=999;
 for(let i=0;i<3;i++)recruit(s,s.buildings[2].id,'soldier');advance(s,16);
 assert.equal(command(s,[s.units.find(u=>u.faction==='enemy').id],'move',{x:12,y:16}),0);
 for(const enemy of s.units.filter(u=>u.faction==='enemy')){command(s,s.units.filter(u=>u.kind==='soldier'&&u.hp>0).map(u=>u.id),'attack',enemy.id);advance(s,24);}
 assert.equal(s.stats.kills,3);assert.equal(s.victory,true);assert.ok(s.units.some(u=>u.kind==='soldier'&&u.hp>0));
});
test('farm, stone and gold gathering produce their correct resource types',()=>{
 for(const kind of ['farm','stone','gold']){const s=createGame(),target=kind==='farm'?s.buildings.find(b=>b.kind==='farm'):s.nodes.find(n=>n.kind===kind);assert.equal(command(s,[s.units[0].id],'gather',target.id),1);advance(s,30);assert.ok(s.drops.some(d=>d.resource===(kind==='farm'?'food':kind)));}
});
test('save roundtrip retains queues, gathering orders and construction; malformed saves are rejected',()=>{
 const s=createGame();recruit(s,s.buildings[0].id,'worker');command(s,[s.units[0].id],'gather',s.nodes[0].id);construct(s,'house',13,21);advance(s,1);
 const restored=loadGame(saveGame(s));assert.ok(restored);assert.deepEqual(restored.resources,s.resources);assert.equal(restored.units[0].task.target,s.nodes[0].id);advance(restored,12);assert.equal(restored.stats.recruited,1);assert.equal(restored.stats.built,1);assert.ok(restored.drops.length);
 assert.equal(loadGame('{bad'),null);assert.equal(loadGame('{"version":99}'),null);assert.equal(loadGame(saveGame({...s,resources:{...s.resources,wood:-1}})),null);
});
