import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame as createEstablishedGame,recruit,construct,upgrade,command,collect,tick,saveGame,loadGame} from '../src/sim.js';
import {claimSupplies,visitFounder} from '../src/realm.js';
import {progressionInfo,XP_RULES} from '../src/progression.js';
// Established-village regression fixture; new opening is covered separately.
const createGame=()=>createEstablishedGame({established:true});
const advance=(s,t)=>{for(let i=0;i<t*20;i++)tick(s,.05);};
test('training experience is awarded on completion rather than queueing, once per recruit',()=>{
 const s=createGame();recruit(s,s.buildings[0].id,'worker');assert.equal(progressionInfo(s).xp,0);advance(s,3.2);assert.equal(progressionInfo(s).xp,XP_RULES.recruit);advance(s,8);assert.equal(progressionInfo(s).xp,XP_RULES.recruit);
 recruit(s,s.buildings[2].id,'soldier');advance(s,5.2);assert.equal(progressionInfo(s).xp,XP_RULES.recruit+XP_RULES.train);
});
test('actual gathering earns XP while gifts and collecting the same bundle do not add extra XP',()=>{
 const s=createGame();visitFounder(s);claimSupplies(s);assert.equal(progressionInfo(s).xp,0);const n=s.nodes[0],before=n.amount;command(s,[s.units[0].id],'gather',n.id);advance(s,18);const expected=s.stats.treesCut*XP_RULES.gather;assert.ok(expected>0);assert.equal(progressionInfo(s).xp,expected);collect(s,s.drops[0].id);assert.equal(progressionInfo(s).xp,expected);
});
test('completed construction and upgrades reward work once and retain existing population mechanics',()=>{
 const s=createGame();const r=construct(s,'house',13,21);assert.equal(r.ok,true);assert.equal(progressionInfo(s).xp,0);advance(s,5.2);assert.equal(progressionInfo(s).xp,XP_RULES.construct);upgrade(s,r.id);advance(s,8);assert.equal(progressionInfo(s).xp,XP_RULES.construct+XP_RULES.upgrade);advance(s,10);assert.equal(progressionInfo(s).xp,XP_RULES.construct+XP_RULES.upgrade);
});
test('legacy saves migrate without losing village progress and XP survives a new save roundtrip',()=>{
 const s=createGame();delete s.progression;const restored=loadGame(saveGame(s));assert.equal(progressionInfo(restored).xp,0);assert.deepEqual(restored.resources,s.resources);recruit(restored,restored.buildings[0].id,'worker');advance(restored,3.2);const saved=loadGame(saveGame(restored));assert.equal(progressionInfo(saved).xp,XP_RULES.recruit);assert.equal(saved.stats.recruited,1);
});
test('a group move spreads villagers across available destination tiles instead of stacking the first two',()=>{
 const s=createGame(),workers=s.units.filter(u=>u.kind==='worker');assert.equal(command(s,workers.map(u=>u.id),'move',{x:16,y:18}),3);advance(s,12);assert.ok(workers.every(u=>u.path.length===0));assert.equal(new Set(workers.map(u=>u.x+','+u.y)).size,3);
});
