import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,makeUnit,command,tick,entity,collect,upgrade,repair,moveBuilding,saveGame,loadGame,recruit,engageBorderCamp} from '../src/sim.js';
import {ownsTile} from '../src/territory.js';
import {updateTutorial,TUTORIAL_MOVE} from '../src/tutorial.js';
const advance=(s,t)=>{for(let i=0;i<t*20;i++)tick(s,.05);};
test('a worker finishes an entire tree once and walks to another owned tree automatically',()=>{
 const s=createGame(),u=makeUnit(s,'worker',7,11),tree=s.nodes[0],wood=tree.amount;
 command(s,[u.id],'gather',tree.id);advance(s,8);assert.equal(tree.amount,0);assert.equal(s.stats.treesCut,1);assert.ok(s.drops.some(d=>d.source===tree.id&&d.amount===wood));assert.notEqual(u.task?.target,tree.id);assert.equal(u.task?.chain,'tree');assert.equal(ownsTile(s,entity(s,u.task.target).x,entity(s,u.task.target).y),true);
 const drop=s.drops.find(d=>d.source===tree.id),before=s.resources.wood;collect(s,drop.id);assert.equal(s.resources.wood,before+wood);assert.equal(collect(s,drop.id),false);advance(s,10);assert.ok(s.stats.treesCut>=2);
});
test('tree chaining stops when ordered and does not harvest across unowned borders or invent resources',()=>{
 const s=createGame();s.nodes=s.nodes.filter(n=>n.kind!=='tree'||n.x===7&&n.y===10||n.x===26&&n.y===8);const u=makeUnit(s,'worker',7,11),first=s.nodes.find(n=>n.kind==='tree'&&n.x===7);
 command(s,[u.id],'gather',first.id);advance(s,8);assert.equal(u.task,null);assert.equal(s.nodes.find(n=>n.x===26&&n.y===8).amount,180);
 const t={id:'new-tree',kind:'tree',x:9,y:10,amount:108};s.nodes.push(t);command(s,[u.id],'gather',t.id);command(s,[u.id],'stop');advance(s,20);assert.equal(t.amount,108);
});
test('tree chain, tutorial actions and partial tree work survive saving without respawning cleared trees',()=>{
 let s=createGame();updateTutorial(s,[]);assert.equal(updateTutorial(s,[s.buildings[0].id]).id,'recruit');recruit(s,s.buildings[0].id,'worker');advance(s,3.2);const u=s.units.find(u=>u.kind==='worker');assert.equal(updateTutorial(s,[]).id,'select');assert.equal(updateTutorial(s,[u.id]).id,'move');command(s,[u.id],'move',TUTORIAL_MOVE);advance(s,8);assert.equal(updateTutorial(s,[u.id]).id,'tree');
 const tree=s.nodes.find(n=>n.kind==='tree'&&n.x===7&&n.y===10);command(s,[u.id],'gather',tree.id);advance(s,4);s=loadGame(saveGame(s));assert.ok(s.tutorial.moved);advance(s,12);assert.equal(s.nodes.find(n=>n.id===tree.id).amount,0);assert.equal(updateTutorial(s,[]).id,'wood');
});
test('border guards stay on the home map, remain quiet until engaged and reject enemy-building edits',()=>{
 const s=createGame(),camp=s.frontierCamps.find(c=>c.plot==='4,2'),tower=entity(s,camp.structures[0]),soldiers=s.units.filter(u=>u.faction==='player');advance(s,20);assert.ok(soldiers.every(u=>u.hp===u.maxHp));assert.equal(camp.engaged,false);s.resources={gold:9999,wood:9999,food:9999,stone:9999,cash:0};assert.equal(upgrade(s,tower.id).ok,false);assert.equal(moveBuilding(s,tower.id,13,21).ok,false);tower.hp=100;assert.equal(repair(s,tower.id).ok,false);
});
test('defeating a border camp claims its existing plot without scene changes, teleportation or duplicate rewards',()=>{
 const s=createGame(),camp=s.frontierCamps.find(c=>c.plot==='4,2'),worker=makeUnit(s,'worker',7,11);command(s,[worker.id],'gather',s.nodes[0].id);
 for(let i=0;i<4;i++)makeUnit(s,'veteran',21+i*.2,16);const original=s,army=s.units.filter(u=>u.faction==='player'&&u.kind!=='worker').map(u=>u.id);engageBorderCamp(s,camp.plot,army);
 for(let i=0;i<1500&&!camp.resolved;i++){const target=[...camp.defenders,...camp.structures].find(id=>entity(s,id)?.hp>0);if(target&&i%10===0)command(s,army,'attack',target);tick(s,.1);}
 assert.equal(s,original);assert.equal(s.battle,null);assert.equal(camp.resolved,true);assert.equal(s.territory.owned.includes('4,2'),true);assert.ok(s.stats.treesCut>0||worker.progress>0,'home workers keep working during border fights');assert.equal(s.reports.filter(r=>r.id==='border-4,2').length,1);const gold=s.resources.gold;advance(s,10);assert.equal(s.resources.gold,gold);assert.ok(s.units.some(u=>army.includes(u.id)&&u.x>=24));
 const restored=loadGame(saveGame(s));advance(restored,5);assert.equal(restored.resources.gold,gold);assert.equal(restored.territory.conquered.includes('4,2'),true);assert.equal(restored.frontierCamps.filter(c=>c.plot==='4,2').length,1);
});
test('partial border combat and permanent deaths survive reload without resetting the camp',()=>{
 let s=createGame(),camp=s.frontierCamps.find(c=>c.plot==='4,2'),defender=entity(s,camp.defenders[0]);defender.hp=41;const u=s.units.find(u=>u.faction==='player');u.hp=0;u.dead=.5;engageBorderCamp(s,camp.plot,[u.id]);advance(s,1);s=loadGame(saveGame(s));assert.equal(s.units.some(x=>x.id===u.id),false);assert.equal(entity(s,defender.id).hp,41);assert.equal(s.frontierCamps.find(c=>c.plot==='4,2').engaged,true);assert.equal(s.territory.owned.includes('4,2'),false);
});
