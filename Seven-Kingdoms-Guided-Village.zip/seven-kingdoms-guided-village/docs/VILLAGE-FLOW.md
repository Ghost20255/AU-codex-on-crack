# Village flow and asset review milestone — 0.5.0

## Player decisions and fixes

A fresh kingdom keeps two starting soldiers and has no villagers outside. The opening is a guided sequence: select the Town Hall, pay and wait for recruitment, select the worker, move to marked ground, clear a tree, collect wood, build/work a farm, then build housing/Barracks, train and secure the border. The guide advances from actual selections, movement and completed work; it can be hidden and reopened from Controls. Existing quests and their rewards remain.

A tree now takes one six-second work cycle, yields its remaining wood once, disappears visually and stops blocking construction. The worker automatically walks to the next reachable tree on owned land. Stop or another command interrupts the chain. Multiple workers cannot duplicate a tree’s yield. Unowned trees are never harvested automatically. Farm/mine/yard production remains continuous and produces collectible bundles. Save/reload preserves depleted trees and current orders.

Loading a previously saved kingdom now offers **Continue saved kingdom** or **Start fresh guided village**, with a summary of its people/buildings. This explains why an older save already contains workers. A fresh start keeps the previous kingdom as a browser-local backup instead of deleting progress. The choice appears once per browser tab for this update; reload then resumes normally.

## Direct land and local conquest

Click a FOR SALE sign on the home map, choose 4,000 gold or 20 cash, and the neighboring land is immediately owned. No overview grid or separate View on map step is needed. Land in the toolbar simply helps you find the border signs. Cash sales remain unconnected.

Adjacent hostile plots have visible defenders and a tower on the same home map. Click a defender with fighters selected, walk into the camp, or click its CONQUER sign and Send my army. Troops physically march there; they are not teleported or copied into a separate scene. Home workers, recruitment and construction continue while the fight happens. Clearing that camp’s defenders and tower permanently claims the plot, records the result once, and opens the next frontier. Guards remain inactive until the camp is engaged or entered. Casualties remain permanent. Enemy buildings cannot be moved, repaired or upgraded by the player.

Campaign still represents an expedition to another NPC kingdom. It remains separate and pauses home production. Old saved expedition-conquest battles can be completed for compatibility, but the new border-conquest interface uses the home map.

## Uploaded models: what was inspected

All 30 uploaded OBJ models were imported and rendered in Blender 4.3.2 with their MTL files. These contain 4,026 polygon faces in total; the largest individual model has 307 faces. The uploads provide multiple formats of the same objects, not a separate new object for every FBX/Blend/OBJ file.

Watchtower.fbx, Dummy.fbx and Watchtower.blend were also inspected. Each sample has one mesh and no armature or animation actions. In particular, Dummy is a static prop/mannequin, not an animated villager. The supplied materials are gray; the preview uses an assigned wood/stone/blue-roof palette for evaluation. Uploaded originals and materials were preserved unchanged. Blender was run with automatic script execution disabled.

The kit is technically suitable for towers, walls, gateways, doors, bridges and settlement props. For the existing Canvas game, the recommended route is to render consistent orthographic isometric sprites with fixed scale, lighting and ground anchors. Animated RPG characters should be assessed separately for their skeleton and walk/work/attack/death clips. A bridge model alone does not add water-crossing logic; doors/gates also need game collision rules before becoming functional.

The combined user link was separated into:

- https://quaternius.com/packs/medievalvillagemegakit.html
- https://quaternius.com/packs/rpgcharacters.html

Both pages returned HTTP 403 in this environment. No license file accompanied the uploaded models, so the exact pack’s redistribution terms have not been verified. This update keeps the model renders as an evaluation preview; the gameplay download does not incorporate or relabel these third-party models as original MIT game assets. The existing game artwork remains in use.

## Limits

This is still local browser play. Family accounts, shared persistence, offline player defense, notifications, purchases, cross-device saves and a public hosted game are not activated. Sprite replacement using the uploaded models is not claimed as complete. The gameplay changes can be reviewed independently of that artwork decision.
