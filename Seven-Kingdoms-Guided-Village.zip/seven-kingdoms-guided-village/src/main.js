import {createGuideUI} from './guide-ui.js';
import {UNITS,PROMOTION_COST,DRAGON_TRAINING_COST,SHOP_CATEGORIES} from './catalog.js';
import {ownsTile,plotId,plotInfo} from './territory.js';
import {createFrontierUI} from './frontier-ui.js';
import {MISSIONS,claimMissionRewards} from './missions.js';
import {progressionInfo} from './progression.js';
import {BLUEPRINTS} from './realm.js';
import {createRealmUI} from './realm-ui.js';
import {createGame,entity,capacity,population,reservedPopulation,command,recruit,construct,upgrade,upgradeCost,repair,moveBuilding,collect,tick,saveGame,loadGame,BUILDINGS,RULES,canPay,promoteUnit} from './sim.js';
import {Renderer,UNIT_SCALE} from './render.js';
const $=id=>document.getElementById(id),canvas=$('world'),ctx=$('context'),dialog=$('dialog');
const SAVE='seven-kingdoms-frontier-v1',BACKUP=SAVE+'-unreadable-backup';
let storageAvailable=true,restored=false;
function readSave(){try{const raw=localStorage.getItem(SAVE);if(!raw)return null;const game=loadGame(raw);if(!game)localStorage.setItem(BACKUP,raw);return game;}catch{storageAvailable=false;return null;}}
const restoredGame=readSave();export let state=restoredGame||createGame();restored=!!restoredGame;
export const renderer=new Renderer(canvas);
export const ui={selected:new Set(),placement:null,hover:null,hoverName:'',mouse:null,box:null,marker:null,hoverCollect:false,paused:false,landMode:false,guide:null};
let last=performance.now(),updateTimer=0,saveTimer=0,toastTimer=0,drag=null,space=false,contextKey='',lastVictory=state.victory,lastMissionCount=-1,missionKey='',shopCategory='all',shopStateKey='',rosterKey='',lastPlayerLevel=progressionInfo(state).level,lastBorderReport=state.reports?.[0]?.id||null;
const icons={gold:'◈',wood:'▰',food:'❧',stone:'⬟',cash:'✦',townhall:'♜',house:'⌂',barracks:'⚔',farm:'❧',tower:'♖',worker:'♟',soldier:'⚔',raider:'⚔',tree:'♠'};
const resourceNames={gold:'GOLD',wood:'WOOD',food:'FOOD',stone:'STONE',cash:'CASH'};
const costText=cost=>Object.entries(cost).map(([k,v])=>v+' '+k).join(' · ');
const titleCase=t=>t[0].toUpperCase()+t.slice(1);
export const realm=createRealmUI({getState:()=>state,renderer,ui,refresh:()=>{contextKey='';updateUI();},notify,persist});
export const frontier=createFrontierUI({getState:()=>state,ui,renderer,refresh:()=>{contextKey='';rosterKey='';updateUI();},persist,notify,returnAlly:()=>{if(realm.visiting)realm.home();},closeShop:()=>toggleBuild(false)});
export const guide=createGuideUI({getState:()=>state,ui,renderer,select,focusBuilding,openShop:kind=>{shopCategory=kind==='barracks'?'military':'village';toggleBuild(true);},persist});
function activeGame(){return frontier.scene||(realm.visiting?realm.estate:state);}
export function notify(message){$('toast').textContent=message;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),3600);}
function result(r){notify(r.message);if(r.ok)contextKey='';updateUI();return r;}
function persist(){try{localStorage.setItem(SAVE,saveGame(state));$('save-status').textContent='Local kingdom · Progress saved';storageAvailable=true;}catch{storageAvailable=false;$('save-status').textContent='Storage unavailable · Export to keep progress';}}
function selected(){return [...ui.selected].map(id=>entity(activeGame(),id)).filter(Boolean);}
function select(ids){ui.selected=new Set(ids);contextKey='';updateUI();}
function taskName(u){return u.path?.length?'Travelling':u.task?.kind==='gather'?'Gathering':u.task?.kind==='attack'?'In battle':'Ready';}
function progressHTML(b){if(b.remaining)return `<div class="queue"><span style="width:${(1-b.remaining/b.total)*100}%"></span></div><p>${b.upgrading?'Upgrading':'Constructing'} · ${Math.ceil(b.remaining)}s remaining</p>`;if(b.queue.length)return `<div class="queue"><span style="width:${(1-b.queue[0].remaining/b.queue[0].total)*100}%"></span></div><p>${'Training '+(UNITS[b.queue[0].kind]?.name||b.queue[0].kind)} · ${Math.ceil(b.queue[0].remaining)}s · ${b.queue.length} queued</p>`;return '';}
function action(id,title,sub='',primary=false,disabled=false){return `<button class="action${primary?' primary':''}" data-action="${id}" ${disabled?'disabled':''}><strong>${title}</strong>${sub?`<small>${sub}</small>`:''}</button>`;}
function showContext(){
 if(state.battle){
  const chosen=selected()[0],b=state.battle;let title='Your expedition',desc='Select troops or drag a group. Click ground to move; click enemy troops or buildings to attack. Fallen troops stay lost.';
  if(chosen){title=chosen.size?BUILDINGS[chosen.kind].name:UNITS[chosen.kind]?.name||'Fighter';desc=(chosen.faction==='enemy'?'ENEMY · ':'YOUR ARMY · ')+Math.ceil(chosen.hp)+' / '+chosen.maxHp+' HP'+(chosen.size?' · Destroy this target.':' · '+(UNITS[chosen.kind]?.description||''));}
  ctx.innerHTML=`<div class="portrait"></div><div class="context-copy"><span class="eyebrow">${b.kind==='conquest'?'CONQUEST':'NPC RESOURCE RAID'}</span><h2>${title}</h2><p>${desc}</p></div><div class="actions">${action('army','Select army','All surviving fighters',true)}${action('stop','Stop','Defend nearby')}${action('battle-home',b.settled?'Return home':'Retreat',b.settled?'Keep your saved results':'Survivors return; no victory bonus')}</div>`;return;
 }
 if(realm.visiting){realm.context(ctx);paintContextPortrait();return;}
 const items=selected();const k=JSON.stringify({ids:[...ui.selected],placement:ui.placement,queues:state.buildings.map(b=>[b.level,b.queue.length,Math.ceil(b.remaining),b.queue[0]&&Math.ceil(b.queue[0].remaining)]),res:state.resources,pop:reservedPopulation(state),units:items.map(u=>[u.hp,taskName(u)]),drops:state.drops.map(d=>[d.id,d.amount])});if(k===contextKey)return;contextKey=k;
 let detailHTML='',portrait='♜',eyebrow='YOUR STORY STARTS HERE',title='A kingdom of your own',desc=state.units.some(u=>u.kind==='worker')?'Build your economy, train an army and expand the frontier.':'Your two soldiers stand watch. Recruit your first villager at the Town Hall.',actions=action('townhall','Visit Town Hall','Recruit & develop',true)+action('build','Build a home','Grow the village');
 if(ui.placement){portrait=icons[ui.placement.kind];eyebrow=ui.placement.id?'VILLAGE EDITING':'PLAN YOUR VILLAGE';title=(ui.placement.id?'Move ':'Place ')+BUILDINGS[ui.placement.kind].name;desc='Click clear ground to place. Green means available; red means occupied.';actions=action('cancel','Cancel','Esc');}
 else if(items.length){
  const first=items[0];portrait=icons[first.kind]||'◈';
  if(first.faction==='enemy'&&first.camp){const camp=state.frontierCamps.find(c=>c.plot===first.camp);eyebrow='ENEMY BORDER CAMP';title=first.size?BUILDINGS[first.kind].name:'Ashen defender';desc='Defeat the defenders and tower here on your village map to claim plot '+first.camp+'. '+Math.ceil(first.hp)+' / '+first.maxHp+' HP.';actions=action('army','Select your army','Then click an enemy',true);}
  else if(first.size){
   eyebrow='WILLOWMERE · LEVEL '+first.level;title=BUILDINGS[first.kind].name;desc=BUILDINGS[first.kind].description;detailHTML=progressHTML(first);actions='';
   const busy=!!first.remaining;
   if(first.kind==='townhall')actions+=action('recruit','Recruit villager',costText(RULES.workerCost),true,busy||!canPay(state,RULES.workerCost)||reservedPopulation(state)>=capacity(state));
   for(const [kind,d]of Object.entries(UNITS).filter(([kind,d])=>d.building===first.kind&&kind!=='worker'))actions+=action(kind==='soldier'?'train':'train-'+kind,'Train '+d.name,costText(d.cost)+(progressionInfo(state).level<d.level?' · Level '+d.level:''),true,busy||!canPay(state,d.cost)||reservedPopulation(state)>=capacity(state)||progressionInfo(state).level<d.level);
   if(first.kind==='farm'||BUILDINGS[first.kind]?.resource)actions+=action('workers','Select villagers','Then click this farm',true);
   actions+=action('upgrade','Upgrade'+(first.level<10?' → '+(first.level+1):' complete'),first.level<10?costText(upgradeCost(first)):'Maximum level',false,busy||first.level>=10||first.queue.length>0||!canPay(state,upgradeCost(first)));
   actions+=action('move-building','Move','Choose new location',false,busy||first.queue.length>0);
   if(first.hp<first.maxHp)actions+=action('repair','Repair','15 wood · 10 stone');
  }else if(first.faction){
   const workers=items.filter(x=>x.kind==='worker').length,soldiers=items.filter(x=>x.faction==='player'&&x.kind!=='worker').length;
   if(first.faction==='enemy'){eyebrow='ASHEN RAIDERS';title='Frontier raider';desc='These raiders guard the eastern road. Select shieldbearers and click a raider to attack.';actions=action('army','Select your army','March together',true);}
   else{eyebrow=items.length>1?'SELECTED COMPANY':taskName(first).toUpperCase();title=items.length>1?`${items.length} ${workers===items.length?'villagers':soldiers===items.length?'fighters':'units'}`:workers?'Villager':UNITS[first.kind]?.name||'Fighter';desc=workers?'Click a tree, quarry, gold vein, or farm to gather. Click the glowing bundles to collect.':(UNITS[first.kind]?.description||'')+' Click ground to move or a border enemy to attack. Campaign raids take place in other kingdoms.';actions=action('stop','Stop','Hold position')+action(workers?'workers':'army','Select all',workers?'All villagers':'All fighters');if(items.length===1&&['soldier','dragon'].includes(first.kind))actions+=action('promote',first.kind==='dragon'?'Train Cinderwing':'Promote → Dawnguard',costText(first.kind==='dragon'?DRAGON_TRAINING_COST:PROMOTION_COST));}
  }else if(first.resource){eyebrow='READY TO COLLECT';title=titleCase(first.resource)+' bundle';desc='Your villagers have gathered '+first.amount+' '+first.resource+'.';actions=action('collect','Collect','+'+first.amount+' '+first.resource,true);}
  else{eyebrow='NATURAL RESOURCE';title=first.kind==='tree'?'Oldwood grove':first.kind==='gold'?'Gold vein':'Stone outcrop';desc=(first.amount?first.amount+' remaining. ':'Depleted. ')+(first.kind==='tree'?'Select villagers, then click this tree to chop wood.':'Select villagers, then click here to gather.');actions=action('workers','Select villagers','Then assign a job',true);}
 }
 ctx.innerHTML=`<div class="portrait" aria-hidden="true">${portrait}</div><div class="context-copy"><span class="eyebrow">${eyebrow}</span><h2>${title}</h2><div class="context-description"><p>${desc}</p>${detailHTML}</div></div><div class="actions">${actions}</div>${items.length||ui.placement?'<button class="close" data-action="deselect" aria-label="Clear selection">×</button>':''}`;
}
function updateUI(){
 realm.update();frontier.update();const earned=claimMissionRewards(state);if(earned.length){notify('Mission complete: '+earned.at(-1).title+' · +'+earned.reduce((n,m)=>n+m.gold,0)+' gold');persist();}refreshRoster();const xp=progressionInfo(state);$('player-level').textContent=xp.level;$('experience-fill').style.width=(xp.fraction*100)+'%';$('experience-text').textContent=xp.current+' / '+xp.required+' XP';if(xp.level>lastPlayerLevel){notify('Kingdom level '+xp.level+'! Your village is growing.');lastPlayerLevel=xp.level;}
 $('resources').innerHTML=Object.entries(state.resources).map(([k,v])=>`<div class="resource${k==='cash'?' premium':''}" title="${k==='cash'?'Premium cash can buy land instead of gold. Cash sales are not enabled in this prototype.':titleCase(k)}"><span class="icon" style="color:${{gold:'#db9c1d',wood:'#9a642c',food:'#5e9e31',stone:'#7e9290',cash:'#8c6bb4'}[k]}">${icons[k]}</span><div><strong>${Math.floor(v).toLocaleString()}</strong><small>${resourceNames[k]}</small></div></div>`).join('');
 const cap=capacity(state),pop=population(state),reserved=reservedPopulation(state);$('population').textContent=pop+' / '+cap+(reserved>pop?' +'+(reserved-pop)+' queued':'');$('popfill').style.width=Math.min(100,reserved/cap*100)+'%';
 const completed=state.missionRewards.length,visible=MISSIONS.filter(m=>!state.missionRewards.includes(m.id)).slice(0,4);
 $('mission-count').textContent=completed+' / '+MISSIONS.length;const goalsKey=JSON.stringify([completed,visible.map(m=>m.id)]);
 if(goalsKey!==missionKey){missionKey=goalsKey;$('missions').innerHTML=visible.map(m=>`<button class="mission" data-goal="${MISSIONS.indexOf(m)}"><i></i>${m.title}</button>`).join('')||'<p>Chapter complete. Keep expanding your kingdom.</p>';}
 $('quest-note').innerHTML=state.victory&&!state.opening?'<span class="milestone">The eastern road is safe.</span><br>Open Campaign or Land to march beyond home.':'Click a border sign to buy land. Defeat nearby camps here to claim enemy territory.';
 if(!$('build-menu').hidden){const sk=JSON.stringify([shopCategory,state.resources,progressionInfo(state).level,reservedPopulation(state),state.buildings.map(b=>[b.kind,!!b.remaining,b.queue.length])]);if(sk!==shopStateKey){shopStateKey=sk;renderShop();}}
 showContext();paintContextPortrait();guide.update();if(state.reports[0]?.kind==='border'&&lastBorderReport!==state.reports[0].id){lastBorderReport=state.reports[0].id;notify('Frontier secured! Plot '+state.reports[0].land+' is yours.');persist();}
}
function renderShop(){
 $('shop-tabs').innerHTML=SHOP_CATEGORIES.map(([id,name])=>`<button data-shop-tab="${id}" class="${id===shopCategory?'active':''}" aria-pressed="${id===shopCategory}">${name}</button>`).join('');
 const level=progressionInfo(state).level;
 if(shopCategory==='troops'){
  $('building-cards').innerHTML=Object.entries(UNITS).filter(([k,d])=>d.cost).map(([kind,d])=>{const b=state.buildings.find(b=>b.kind===d.building&&!b.remaining&&b.hp>0),locked=level<d.level;return `<article class="building-card"><div class="troop-symbol">${kind==='dragon'?'♨':kind==='archer'?'⌁':kind==='worker'?'♟':'⚔'}</div><strong>${d.name}</strong><small>${d.description}<br>${d.hp} HP · ${d.damage} attack · ${d.range} range<br>${costText(d.cost)}</small><span class="shop-build-label">${locked?'Requires level '+d.level:!b?'Build '+BUILDINGS[d.building].name:d.time+'s · '+b.queue.length+' queued'}</span><button class="action" data-shop-train="${kind}" ${locked||!b||!canPay(state,d.cost)||reservedPopulation(state)>=capacity(state)||b.queue.length>=3?'disabled':''}>Train</button></article>`;}).join('');return;
 }
 const entries=BLUEPRINTS.filter(b=>shopCategory==='all'||b.category===shopCategory);
 $('building-cards').innerHTML=entries.map(b=>{const d=BUILDINGS[b.id],locked=d&&level<(d.unlock||1);return b.available?`<button class="building-card" data-build="${b.id}" ${locked||!canPay(state,d.cost)?'disabled':''}><canvas width="320" height="180" data-shop-art="${b.id}" aria-hidden="true"></canvas><strong>${d.name}</strong><small>${b.description}<br>${costText(d.cost)}</small><span class="shop-build-label">${locked?'Requires kingdom level '+d.unlock:'Build · '+d.time+'s'}</span></button>`:`<article class="building-card locked-building"><canvas width="320" height="180" data-shop-art="${b.id}" aria-hidden="true"></canvas><strong>${b.name}</strong><small>${b.description}</small><span class="shop-build-label">Future chapter · Preview only</span></article>`;}).join('');
 for(const c of $('building-cards').querySelectorAll('[data-shop-art]')){const b=BLUEPRINTS.find(b=>b.id===c.dataset.shopArt);renderer.paintBlueprint(c,b.visual,b.available?1:10);}
}
function toggleBuild(open=$('build-menu').hidden){if(state.battle&&open){notify('Return home before building or training.');return;}if(realm.visiting){if(open)realm.gallery();return;}document.body.classList.toggle('building-open',open);$('build-menu').hidden=!open;$('build-toggle').classList.toggle('active',open);if(open)renderShop();}
function refreshRoster(){
 const units=activeGame().units.filter(u=>u.faction!=='enemy'&&u.hp>0),key=JSON.stringify([realm.visiting,units.map(u=>[u.id,Math.ceil(u.hp),u.task?.kind,ui.selected.has(u.id)])]);if(key===rosterKey)return;rosterKey=key;
 $('unit-roster').innerHTML=units.map(u=>`<button class="unit-card ${ui.selected.has(u.id)?'selected':''}" data-roster="${u.id}" aria-pressed="${ui.selected.has(u.id)}" title="${u.ruler?'Sahir Ibn Raydan':u.royal?'Royal guard':UNITS[u.kind]?.name||'Fighter'} · ${u.royal?'Ally':taskName(u)}"><canvas width="60" height="62" data-unit-art="${u.id}" aria-hidden="true"></canvas><span>${u.ruler?'Sahir':u.royal?'Guard':UNITS[u.kind]?.name||'Fighter'}</span><i class="unit-health"><i style="width:${u.hp/u.maxHp*100}%"></i></i></button>`).join('');
 for(const c of $('unit-roster').querySelectorAll('[data-unit-art]'))renderer.paintUnitPortrait(c,units.find(u=>u.id===c.dataset.unitArt));
}
function paintContextPortrait(){
 const box=ctx.querySelector('.portrait');if(!box)return;let c=box.querySelector('canvas');if(!c){box.textContent='';c=document.createElement('canvas');c.width=100;c.height=100;box.append(c);}
 const chosen=selected()[0];if(chosen?.size)renderer.paintBlueprint(c,chosen.kind,chosen.level||1);else if(chosen?.faction)renderer.paintUnitPortrait(c,chosen);else if(chosen)renderer.paintResourcePortrait(c,chosen);else renderer.paintBlueprint(c,'townhall',1);
}

function handleAction(type){
 if(state.battle){if(type==='army')select(activeGame().units.filter(u=>u.kind!=='worker'&&u.faction==='player'&&u.hp>0).map(u=>u.id));if(type==='stop')command(activeGame(),[...ui.selected],'stop');if(type==='battle-home')frontier.home();return;}
 if(realm.visiting)return;
 const e=selected()[0];
 if(type==='build')toggleBuild();
 if(type==='townhall')focusBuilding('townhall');
 if(type==='recruit'&&e)result(recruit(state,e.id,'worker'));
 if(type==='train'&&e)result(recruit(state,e.id,'soldier'));
 if(type.startsWith('train-')&&e)result(recruit(state,e.id,type.slice(6)));
 if(type==='promote'&&e){result(promoteUnit(state,e.id));persist();}
 if(type==='upgrade'&&e)result(upgrade(state,e.id));
 if(type==='repair'&&e)result(repair(state,e.id));
 if(type==='move-building'&&e){ui.placement={kind:e.kind,id:e.id};toggleBuild(false);contextKey='';updateUI();notify('Click a clear location for your '+BUILDINGS[e.kind].name+'.');}
 if(type==='army'||type==='workers'){const army=type==='army';select(state.units.filter(u=>(army?u.kind!=='worker':u.kind==='worker')&&u.hp>0&&u.faction==='player').map(u=>u.id));}
 if(type==='stop'){command(state,[...ui.selected],'stop');notify('Orders cancelled. Soldiers will still defend nearby allies.');}
 if(type==='collect'&&e){collect(state,e.id);select([]);}
 if(type==='cancel'||type==='deselect'){ui.placement=null;select([]);}
}
function focusBuilding(kind){const b=state.buildings.find(b=>b.kind===kind);if(!b)return;select([b.id]);const p=renderer.screen(b.x+(b.size-1)/2,b.y+(b.size-1)/2);renderer.camera.x+=renderer.w*.55-p.x;renderer.camera.y+=renderer.h*.46-p.y;}
function openGoal(index){
 const m=MISSIONS[index];if(!m)return;const goal={title:m.title,go:()=>{if(m.go==='land'||m.go==='campaign')frontier.open(m.go);else if(m.go==='troops'){shopCategory='troops';toggleBuild(true);}else if(m.go==='build')toggleBuild(true);else if(m.go==='workers')handleAction('workers');else focusBuilding('townhall');}};
 ui.paused=true;dialog.querySelector('.modal-content').innerHTML=`<button class="close" id="goal-close" aria-label="Close goal">×</button><span class="eyebrow">CHAPTER I · A KINGDOM TAKES ROOT</span><h2>${m.title}</h2><p>${m.text}</p><p class="goal-reward">Reward: ${m.gold} gold and 10 XP · Awarded once, in chapter order.</p><button class="action primary" id="goal-follow"><strong>Show me</strong></button>`;dialog.showModal();$('goal-close').onclick=()=>dialog.close();$('goal-follow').onclick=()=>{dialog.close();goal.go();};
}
$('missions').addEventListener('click',e=>{const button=e.target.closest('[data-goal]');if(button)openGoal(Number(button.dataset.goal));});
ctx.addEventListener('click',e=>{const button=e.target.closest('[data-action]');if(button)handleAction(button.dataset.action);});
$('shop-tabs').addEventListener('click',e=>{const tab=e.target.closest('[data-shop-tab]');if(tab){if(tab.dataset.shopTab==='land'){toggleBuild(false);frontier.open('land');return;}shopCategory=tab.dataset.shopTab;renderShop();}});
$('unit-roster').addEventListener('click',e=>{const card=e.target.closest('[data-roster]');if(!card)return;if(realm.visiting){realm.worldClick(entity(realm.estate,card.dataset.roster));return;}if(e.shiftKey){const ids=new Set(ui.selected);if(ids.has(card.dataset.roster))ids.delete(card.dataset.roster);else ids.add(card.dataset.roster);select([...ids]);}else select([card.dataset.roster]);});
$('build-menu').addEventListener('click',e=>{const train=e.target.closest('[data-shop-train]');if(train&&!train.disabled){const kind=train.dataset.shopTrain,b=state.buildings.find(b=>b.kind===UNITS[kind].building&&!b.remaining);result(recruit(state,b?.id,kind));persist();renderShop();return;}const b=e.target.closest('[data-build]');if(b){ui.placement={kind:b.dataset.build};toggleBuild(false);contextKey='';updateUI();notify('Choose a clear site for your '+BUILDINGS[ui.placement.kind].name+'.');}});
$('build-toggle').onclick=()=>toggleBuild();$('build-close').onclick=()=>toggleBuild(false);$('army').onclick=()=>handleAction('army');$('home').onclick=()=>{if(!frontier.home())realm.home();};$('zoom-in').onclick=()=>renderer.zoomAt(1.15);$('zoom-out').onclick=()=>renderer.zoomAt(1/1.15);
function hitTest(x,y){
 const scene=activeGame();
 const screen=(e,offset=0)=>{const p=renderer.screen(e.x,e.y);return {x:p.x,y:p.y-offset*renderer.camera.zoom};};
 for(const d of [...scene.drops].reverse()){const p=screen(d,8);if(Math.hypot(x-p.x,y-p.y)<20*renderer.camera.zoom)return d;}
 const unitHits=scene.units.filter(u=>{if(u.hp<=0)return false;const p=screen(u,16*UNIT_SCALE);return Math.abs(x-p.x)<15*UNIT_SCALE*renderer.camera.zoom&&Math.abs(y-p.y)<24*UNIT_SCALE*renderer.camera.zoom;}).sort((a,b)=>{const p=screen(a,16*UNIT_SCALE),q=screen(b,16*UNIT_SCALE);return Math.hypot(x-p.x,y-p.y)-Math.hypot(x-q.x,y-q.y);});if(unitHits.length){const attacking=!realm.visiting&&selected().some(u=>u.kind!=='worker'&&u.faction==='player'),enemy=attacking&&unitHits.find(u=>u.faction==='enemy');return enemy||unitHits[0];}
 const w=renderer.world(x,y);
 // Full artwork hit targets allow clicking a roof or canopy, as well as the footprint.
 const candidates=[...scene.buildings.filter(b=>b.hp!==0),...scene.nodes.filter(n=>n.amount>0)].sort((a,b)=>(b.x+b.y+(b.size||0))-(a.x+a.y+(a.size||0)));
 for(const e of candidates){if(e.size){const pixel=renderer.hitBuilding(e,x,y),footprint=w.x>=e.x-.45&&w.x<e.x+e.size-.45&&w.y>=e.y-.45&&w.y<e.y+e.size-.45;if(pixel===true||footprint)return e;if(pixel===false)continue;}const p=renderer.screen(e.x+((e.size||1)-1)/2,e.y+((e.size||1)-1)/2),width=(e.size?e.size*31:22)*renderer.camera.zoom,height=(e.size?175:e.kind==='tree'?87:35)*renderer.camera.zoom;if(Math.abs(x-p.x)<width&&y<p.y+15*renderer.camera.zoom&&y>p.y-height)return e;if(e.size&&w.x>=e.x-.45&&w.x<e.x+e.size-.45&&w.y>=e.y-.45&&w.y<e.y+e.size-.45)return e;}
 return null;
}
function clickWorld(e,x,y){
 const w=renderer.world(x,y),hit=hitTest(x,y),ids=[...ui.selected];
 if(state.battle){if(state.battle.settled)return;const scene=activeGame();if(hit?.faction==='enemy'){const n=command(scene,ids,'attack',hit.id);if(!n)select([hit.id]);}else if(hit?.faction==='player'){if(e.shiftKey){const next=new Set(ui.selected);if(next.has(hit.id))next.delete(hit.id);else next.add(hit.id);select([...next]);}else select([hit.id]);}else command(scene,ids,'move',{x:Math.round(w.x),y:Math.round(w.y)});contextKey='';updateUI();return;}
 if(realm.visiting){realm.worldClick(hit);return;}
 const p=plotInfo(state,plotId(w.x,w.y));if(!ui.placement&&(!hit||(!hit.faction&&!hit.size))&&p&&!p.owned&&p.adjacent){const q=renderer.screen(p.x+2.5,p.y+2.5);if(Math.abs(x-q.x)<58*renderer.camera.zoom&&Math.abs(y-q.y)<22*renderer.camera.zoom){frontier.open('land',p.id);return;}}
 if(ui.placement){const placement=ui.placement,px=Math.round(w.x),py=Math.round(w.y);const r=placement.id?moveBuilding(state,placement.id,px,py):construct(state,placement.kind,px,py);result(r);if(r.ok){ui.placement=null;select([r.id||placement.id]);persist();}return;}
 if(hit?.resource){collect(state,hit.id);updateUI();return;}
 if(hit&&hit.faction==='player'&&!hit.size){
  if(e.shiftKey){const next=new Set(ui.selected);if(next.has(hit.id))next.delete(hit.id);else next.add(hit.id);select([...next]);}else select([hit.id]);return;
 }
 if(hit&&hit.faction==='enemy'&&ids.some(id=>entity(state,id)?.faction==='player'&&entity(state,id)?.kind!=='worker')){const n=command(state,ids,'attack',hit.id);if(n)notify(n+' fighter'+(n>1?'s':'')+' advancing.');return;}
 if(hit&&(hit.amount>0||hit.kind==='farm'||BUILDINGS[hit.kind]?.resource)&&ids.some(id=>entity(state,id)?.kind==='worker')){const n=command(state,ids,'gather',hit.id);notify(n?n+' villager'+(n>1?'s':'')+' assigned. Collect the glowing bundles when ready.':'Choose a reachable resource inside your owned land.');contextKey='';updateUI();return;}
 if(hit){select([hit.id]);return;}
 if(ids.some(id=>entity(state,id)?.faction==='player')){const n=command(state,ids,'move',{x:Math.round(w.x),y:Math.round(w.y)});if(n){ui.marker={x:Math.round(w.x),y:Math.round(w.y),life:1};contextKey='';}else notify('That ground is not reachable.');}else select([]);
}
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('pointerdown',e=>{if(e.button>2)return;canvas.focus({preventScroll:true});canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,pan:space||e.button===1||e.button===2,moved:false,pointer:e.pointerId,button:e.button};});
canvas.addEventListener('pointermove',e=>{
 ui.mouse={x:e.clientX,y:e.clientY};ui.hover=renderer.world(e.clientX,e.clientY);
 if(drag){const dx=e.clientX-drag.lastX,dy=e.clientY-drag.lastY;if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>5)drag.moved=true;if(drag.pan){renderer.camera.x+=dx;renderer.camera.y+=dy;canvas.style.cursor='grabbing';}else if(drag.moved){ui.box={x:Math.min(drag.x,e.clientX),y:Math.min(drag.y,e.clientY),w:Math.abs(e.clientX-drag.x),h:Math.abs(e.clientY-drag.y)};}drag.lastX=e.clientX;drag.lastY=e.clientY;return;}
 const hit=hitTest(e.clientX,e.clientY);ui.hoverName=hit?(hit.resource?'Collect '+hit.amount+' '+hit.resource:hit.faction&&!hit.size?hit.faction==='enemy'?'Ashen raider':hit.kind==='worker'?'Villager · '+taskName(hit):'Shieldbearer · '+taskName(hit):hit.size?BUILDINGS[hit.kind].name+' · Level '+hit.level:hit.kind==='tree'?'Oldwood tree':hit.kind==='gold'?'Gold vein':'Stone outcrop'):'';
 if(hit?.resource&&ui.hoverCollect){collect(state,hit.id);updateUI();}
 canvas.style.cursor=ui.placement?'crosshair':hit?.faction==='enemy'&&selected().some(u=>u.kind!=='worker'&&u.faction==='player')?'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'32\' height=\'32\'%3E%3Ctext x=\'1\' y=\'24\' font-size=\'25\'%3E⚔%3C/text%3E%3C/svg%3E") 16 16, crosshair':hit?'pointer':space?'grab':'default';
});
canvas.addEventListener('pointerup',e=>{if(!drag)return;const d=drag;drag=null;if(ui.box){const b=ui.box;ui.box=null;const ids=e.shiftKey?[...ui.selected]:[];for(const u of activeGame().units){if(u.hp<=0||u.faction!=='player')continue;const p=renderer.screen(u.x,u.y);if(p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h+22)ids.push(u.id);}select([...new Set(ids)]);}else if(!d.moved)clickWorld(e,e.clientX,e.clientY);canvas.style.cursor=space?'grab':'default';});
canvas.addEventListener('pointercancel',()=>{drag=null;ui.box=null;});
canvas.addEventListener('wheel',e=>{e.preventDefault();renderer.zoomAt(e.deltaY>0?1/1.1:1.1,e.clientX,e.clientY);},{passive:false});
window.addEventListener('keydown',e=>{if(dialog.open||['INPUT','TEXTAREA'].includes(e.target.tagName))return;if(e.code==='Space'){e.preventDefault();space=true;canvas.style.cursor='grab';}if(e.code==='Escape'){ui.landMode=false;ui.placement=null;toggleBuild(false);select([]);}if(e.code==='KeyB')toggleBuild();if(e.code==='KeyH'){if(!frontier.home())realm.home();}if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD'].includes(e.code)){e.preventDefault();renderer.camera.x+=({ArrowLeft:35,KeyA:35,ArrowRight:-35,KeyD:-35}[e.code]||0);renderer.camera.y+=({ArrowUp:35,KeyW:35,ArrowDown:-35,KeyS:-35}[e.code]||0);}});
window.addEventListener('keyup',e=>{if(e.code==='Space'){space=false;canvas.style.cursor='default';}});window.addEventListener('blur',()=>{space=false;drag=null;ui.box=null;persist();});window.addEventListener('resize',()=>{renderer.resize();});
function openSettings(){
 ui.paused=true;dialog.querySelector('.modal-content').innerHTML=`<button class="close" id="modal-close" aria-label="Close controls">×</button><span class="eyebrow">THE FRONTIER · PLAYABLE FIRST SLICE</span><h2>Your kingdom, your pace.</h2><p>Start at the Town Hall. Recruit villagers, put them to work, and build another cottage. Train shieldbearers at the Barracks, then clear the three raiders on the eastern road.</p><div class="controls"><span><kbd>Click</kbd> Select / give orders</span><span><kbd>Drag</kbd> Select a group</span><span><kbd>Shift + click</kbd> Add to selection</span><span><kbd>Space + drag</kbd> Pan the camera</span><span><kbd>Wheel / + −</kbd> Zoom in or out</span><span><kbd>H</kbd> Home · <kbd>B</kbd> Build</span></div><label><input type="checkbox" id="hover-collect" ${ui.hoverCollect?'checked':''}> Collect resource bundles on hover</label><p>Your village is saved in this browser. No login, payment, or connection to the old game is used. Save data is local to this browser; online family play is a future milestone. The game pauses while this menu is open.</p><button class="action" id="resume-guide">Show guided tutorial</button><button class="action" id="export-save">Export village save</button><button class="action danger" id="reset-save">Start a new village…</button><p style="font-size:10px">Original illustrated buildings and animated Canvas characters. This prototype includes an expanding kingdom, varied troops, resource production and permanent casualties. Land, NPC raids, conquest, ranged troops, promotions and young dragons are playable. Real multiplayer, paid cash, cavalry and mobile siege engines are not connected.</p>`;
 dialog.showModal();$('resume-guide').onclick=()=>{dialog.close();guide.resume();};$('modal-close').onclick=()=>dialog.close();$('hover-collect').onchange=e=>ui.hoverCollect=e.target.checked;
 $('export-save').onclick=()=>{persist();const url=URL.createObjectURL(new Blob([saveGame(state)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='willowmere-village.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('Village exported. Keep this file as a backup.');};
 $('reset-save').onclick=()=>{dialog.querySelector('.modal-content').innerHTML=`<h2>Begin again?</h2><p>Your current village will be kept as a backup in this browser. Export it first if you want a portable copy.</p><button class="action" id="keep-village">Keep my village</button> <button class="action danger" id="confirm-reset">Start new village</button>`;$('keep-village').onclick=()=>{dialog.close();};$('confirm-reset').onclick=()=>{try{localStorage.setItem(SAVE+'-previous-village',saveGame(state));}catch{notify('Backup could not be saved. Export your village before resetting.');return;}beginFreshVillage();};};
}
dialog.addEventListener('close',()=>{ui.paused=false;last=performance.now();});$('settings').onclick=openSettings;$('help').onclick=openSettings;
document.addEventListener('visibilitychange',()=>{last=performance.now();if(document.hidden)persist();});window.addEventListener('pagehide',persist);
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(!ui.paused&&!document.hidden){if(state.battle)frontier.step(dt);else if(realm.visiting)realm.estate.time+=dt;else tick(state,dt);if(ui.marker){ui.marker.life-=dt;if(ui.marker.life<=0)ui.marker=null;}updateTimer+=dt;saveTimer+=dt;if(updateTimer>.2){updateTimer=0;for(const id of ui.selected){const e=entity(activeGame(),id);if(!e||(e.hp!==undefined&&e.hp<=0))ui.selected.delete(id);}updateUI();}if(saveTimer>5){saveTimer=0;persist();}}renderer.draw(activeGame(),ui);requestAnimationFrame(frame);}
window.addEventListener('realm-build',e=>{ui.placement={kind:e.detail};ui.selected.clear();contextKey='';updateUI();notify('Choose clear ground for your '+BUILDINGS[e.detail].name+'.');});
window.addEventListener('game-art-ready',()=>{contextKey='';rosterKey='';updateUI();paintContextPortrait();if(!$('build-menu').hidden)renderShop();});
updateUI();requestAnimationFrame(frame);if(!storageAvailable)$('save-status').textContent='Storage unavailable · Export to keep progress';
if(restored)notify('Welcome back to Willowmere. Your village has been restored.');

function rememberOpening(){try{sessionStorage.setItem('seven-kingdoms-intro-v05','seen');}catch{}}
function beginFreshVillage(){
 if(state.battle)state.battle=null;realm.home();state=createGame();lastPlayerLevel=1;rosterKey='';missionKey='';lastVictory=false;lastMissionCount=-1;lastBorderReport=null;ui.landMode=false;ui.placement=null;select([]);renderer.home();rememberOpening();persist();dialog.close();notify('A fresh beginning: two soldiers stand watch. Select your Town Hall to recruit your first villager.');
}
function showSavedOpening(){
 let seen=false;try{seen=sessionStorage.getItem('seven-kingdoms-intro-v05')==='seen';}catch{}
 if(!restored||seen||state.battle){rememberOpening();return;}
 ui.paused=true;const workers=state.units.filter(u=>u.kind==='worker'&&u.faction==='player'&&u.hp>0).length,fighters=state.units.filter(u=>u.kind!=='worker'&&u.faction==='player'&&u.hp>0).length;
 dialog.querySelector('.modal-content').innerHTML=`<span class="eyebrow">YOUR SAVED KINGDOM</span><h2>Continue or start the tutorial?</h2><p>This browser already has a kingdom with ${workers} villagers, ${fighters} fighters and ${state.buildings.filter(b=>b.faction!=='enemy').length} buildings. Continuing restores that progress; these are not newly spawned people.</p><button class="action primary" id="resume-kingdom">Continue saved kingdom</button><button class="action" id="fresh-kingdom">Start fresh guided village</button><p>A fresh start begins with a Town Hall, two soldiers and no villagers. Your current kingdom is kept as a browser-local backup.</p>`;
 dialog.showModal();$('resume-kingdom').onclick=()=>{rememberOpening();dialog.close();};$('fresh-kingdom').onclick=()=>{try{localStorage.setItem(SAVE+'-previous-village',saveGame(state));}catch{notify('Could not keep the backup. Export your current kingdom before starting fresh.');return;}beginFreshVillage();};
}
showSavedOpening();
