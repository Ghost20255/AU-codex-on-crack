export const TUTORIAL_MOVE={x:11,y:16};
export const TUTORIAL_STEPS=[
 {id:'hall',title:'Select your Town Hall',text:'Click the Town Hall on the map. This is where new villagers are recruited.',target:'townhall',done:s=>s.tutorial.hallSelected},
 {id:'recruit',title:'Recruit your first villager',text:'Choose Recruit villager. Spend 25 food and 15 gold, then wait 3 seconds for the villager to arrive.',target:'recruit',done:s=>s.stats.recruited>0},
 {id:'select',title:'Select your new villager',text:'Click the villager on the map or their portrait in the bottom bar.',target:'worker',done:s=>s.tutorial.workerSelected},
 {id:'move',title:'Move to the marked ground',text:'With the villager selected, click the yellow circle. Wait until they reach it.',target:'move',done:s=>s.tutorial.moved},
 {id:'tree',title:'Clear your first tree',text:'Select your villager, then click the marked tree. After 6 seconds of work, it disappears and the villager moves to another nearby tree.',target:'tree',done:s=>(s.stats.treesCut||0)>0},
 {id:'wood',title:'Collect the wood',text:'Click a glowing wood bundle. Workers continue clearing reachable trees on your owned land until you give another order.',target:'wood',done:s=>s.stats.wood>=36},
 {id:'farm',title:'Build your first farm',text:'Open Build, choose Farm, and place it on clear ground inside your kingdom. Wait for construction to finish.',target:'farm',done:s=>s.buildings.some(b=>b.kind==='farm'&&!b.remaining&&b.hp>0)},
 {id:'food',title:'Put your villager to work on the farm',text:'Select a villager and click your completed farm. Collect the food bundle when it is ready.',target:'food',done:s=>(s.stats.foodCollected||0)>=18},
 {id:'house',title:'Make room for more people',text:'Build a Cottage to increase your population capacity.',target:'house',done:s=>s.buildings.some(b=>b.kind==='house'&&!b.remaining&&b.hp>0)},
 {id:'barracks',title:'Build a Barracks',text:'Open Build and choose Barracks. Place it on clear ground and let construction finish.',target:'barracks',done:s=>s.buildings.some(b=>b.kind==='barracks'&&!b.remaining&&b.hp>0)},
 {id:'soldier',title:'Train a new shieldbearer',text:'Select your Barracks and train a shieldbearer. Your two starting soldiers are already standing watch.',target:'soldier',done:s=>s.stats.trained>0},
 {id:'border',title:'Secure the frontier',text:'Select your army and click an enemy in a nearby border camp, or click its CONQUER sign. Defeat the camp on this same map to claim the land.',target:'border',done:s=>(s.stats.conquests||0)>0}
];
export function updateTutorial(s,ids=[]){
 s.tutorial??={enabled:!!s.opening&&s.time<.1,hallSelected:false,workerSelected:false,moved:false};
 if(!s.tutorial.enabled)return null;
 const chosen=s.units.filter(u=>ids.includes(u.id)&&u.hp>0&&u.faction==='player');
 if(s.buildings.some(b=>b.kind==='townhall'&&ids.includes(b.id)))s.tutorial.hallSelected=true;
 if(chosen.some(u=>u.kind==='worker'))s.tutorial.workerSelected=true;
 if(s.tutorial.workerSelected&&s.units.some(u=>u.kind==='worker'&&u.hp>0&&Math.hypot(u.x-TUTORIAL_MOVE.x,u.y-TUTORIAL_MOVE.y)<.5&&!u.path.length))s.tutorial.moved=true;
 return TUTORIAL_STEPS.find(step=>!step.done(s))||null;
}
