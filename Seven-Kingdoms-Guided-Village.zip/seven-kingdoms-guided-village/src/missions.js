import {awardXP} from './progression.js';
export const MISSIONS=[
 {id:'recruit',title:'Welcome your first villager',text:'Select the Town Hall and recruit a villager. Workers arrive only after recruitment.',gold:25,done:s=>s.stats.recruited>0,go:'townhall'},
 {id:'wood',title:'Collect 36 wood',text:'Select a villager, click a tree, then collect the bundles. Gifts do not count.',gold:25,done:s=>s.stats.wood>=36,go:'workers'},
 {id:'farm',title:'Build your first farm',text:'Open Build, choose Farm and place it on clear ground inside your kingdom. Wait for construction to finish.',gold:30,done:s=>s.buildings.some(b=>b.kind==='farm'&&!b.remaining&&b.hp>0),go:'build'},
 {id:'food',title:'Collect your first farm harvest',text:'Select a villager, click a completed farm and collect the food bundle.',gold:25,done:s=>(s.stats.foodCollected||0)>=18,go:'workers'},
 {id:'house',title:'Make room for your people',text:'Build a Cottage on owned clear ground and wait for completion. Houses increase population capacity.',gold:35,done:s=>s.buildings.filter(b=>b.kind==='house'&&!b.remaining).length>=(s.opening?1:2),go:'build'},
 {id:'barracks',title:'Establish a Barracks',text:'Build a Barracks to train more shieldbearers. All deployed fighters can be lost permanently.',gold:40,done:s=>s.buildings.some(b=>b.kind==='barracks'&&!b.remaining),go:'build'},
 {id:'train',title:'Train a shieldbearer',text:'Choose a ready Barracks or the Train shop tab. Training reserves a population space.',gold:40,done:s=>s.stats.trained>0,go:'troops'},
 {id:'mine',title:'Secure a gold supply',text:'Build a Royal Gold Mine and assign villagers to it. Collect its gold bundles to fund land and troops.',gold:50,done:s=>s.buildings.some(b=>b.kind==='mine'&&!b.remaining),go:'build'},
 {id:'raid',title:'March beyond the village',text:'Open Campaign and raid the Ashen Supply Camp. Defeat its troops, Town Hall and tower, then bring your survivors home.',gold:80,done:s=>(s.stats.raids||0)>0,go:'campaign'},
 {id:'land',title:'Buy your first frontier plot',text:'Click a FOR SALE sign beside your kingdom and pay 4,000 gold or 20 cash. Trees stay in place. Cash sales are not enabled in this prototype.',gold:100,done:s=>(s.stats.landBought||0)>0,go:'land'},
 {id:'conquest',title:'Break an Ashen stronghold',text:'Click an enemy border camp or its CONQUER sign on your home map. Defeat its defenders and tower to permanently claim it; player kingdoms cannot be conquered.',gold:100,done:s=>(s.stats.conquests||0)>0,go:'land'},
 {id:'promotion',title:'Forge a Dawnguard',text:'At kingdom level 3, build a Dawnguard Forge. Select a living shieldbearer and promote them with gold, food and stone.',gold:60,done:s=>(s.stats.promotions||0)>0,go:'build'}
];
export function claimMissionRewards(s){
 s.missionRewards??=[];const claimed=[];
 // Sequential chapters prevent a completed later action skipping the opening.
 for(const m of MISSIONS){if(!m.done(s))break;if(s.missionRewards.includes(m.id))continue;s.missionRewards.push(m.id);s.resources.gold+=m.gold;awardXP(s,'mission',13,14);claimed.push(m);}
 return claimed;
}
