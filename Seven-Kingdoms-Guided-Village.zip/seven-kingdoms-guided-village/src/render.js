import {SIZE,terrain,canPlace,BUILDINGS,RULES} from './sim.js';
import {plotInfo,frontierPlots,ensureTerritory} from './territory.js';
import {UNITS} from './catalog.js';
export const TILE_W=62,TILE_H=31;
export const UNIT_SCALE=1.3;
const SPRITES={townhall:[0,0,520,490],house:[536,0,488,490],barracks:[1032,0,504,490],tower:[60,490,420,534],farm:[486,540,548,484],keep:[1030,475,506,549]};
function buildingSprite(b){const key=b.kind==='townhall'&&b.level>=5?'keep':b.kind,source=SPRITES[key],w=({townhall:key==='keep'?210:188,house:118,barracks:166,tower:105,farm:145}[b.kind])*(b.level>=5&&b.kind!=='townhall'?1.06:1);return {source,w,h:source[3]/source[2]*w,base:b.size*10};}
const hash=(x,y=0)=>{const n=Math.sin(x*127.1+y*311.7)*43758.5453;return n-Math.floor(n);};
export class Renderer{
 constructor(canvas){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.camera={x:0,y:0,zoom:1.05};this.w=0;this.h=0;this.time=0;this.cache=null;this.artReady=false;this.unitArtReady=false;this.atlas=new Image();this.atlas.onload=()=>{const scratch=document.createElement('canvas');scratch.width=this.atlas.naturalWidth;scratch.height=this.atlas.naturalHeight;const c=scratch.getContext('2d',{willReadFrequently:true});c.drawImage(this.atlas,0,0);this.buildingPixels=c.getImageData(0,0,scratch.width,scratch.height).data;this.artReady=true;window.dispatchEvent(new CustomEvent('game-art-ready'));};this.atlas.src=new URL('../assets/village-buildings.png',import.meta.url).href;this.unitAtlas=new Image();this.unitAtlas.onload=()=>{this.readUnitBaselines();this.unitArtReady=true;window.dispatchEvent(new CustomEvent('game-art-ready'));};this.unitAtlas.src=new URL('../assets/village-units.png',import.meta.url).href;this.resize();this.home();}
 resize(){const dpr=Math.min(devicePixelRatio||1,2);this.w=this.canvas.clientWidth;this.h=this.canvas.clientHeight;this.canvas.width=Math.round(this.w*dpr);this.canvas.height=Math.round(this.h*dpr);this.dpr=dpr;}
 home(){this.camera.x=this.w*(this.w<760?.53:.56);this.camera.y=this.h*.46-15*31*this.camera.zoom;}
 iso(x,y){return {x:(x-y)*TILE_W/2,y:(x+y)*TILE_H/2};}
 screen(x,y){const p=this.iso(x,y);return {x:p.x*this.camera.zoom+this.camera.x,y:p.y*this.camera.zoom+this.camera.y};}
 world(x,y){x=(x-this.camera.x)/this.camera.zoom;y=(y-this.camera.y)/this.camera.zoom;return {x:x/TILE_W+y/TILE_H,y:y/TILE_H-x/TILE_W};}
 zoomAt(factor,x=this.w/2,y=this.h/2){const p=this.world(x,y);this.camera.zoom=Math.max(.5,Math.min(1.9,this.camera.zoom*factor));const q=this.iso(p.x,p.y);this.camera.x=x-q.x*this.camera.zoom;this.camera.y=y-q.y*this.camera.zoom;}
 poly(points,fill,stroke=null,width=1){const c=this.ctx;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
 line(points,color,width=1){const c=this.ctx;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.lineJoin='round';c.stroke();}
 ellipse(x,y,rx,ry,color){const c=this.ctx;c.beginPath();c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2);c.fillStyle=color;c.fill();}
 circle(x,y,r,color){this.ellipse(x,y,r,r,color);}
 tile(x,y,color,stroke=null){const p=this.iso(x,y);this.poly([[p.x-31,p.y],[p.x,p.y-15.5],[p.x+31,p.y],[p.x,p.y+15.5]],color,stroke);}
 box(w,d,h,colors=['#c6bb96','#a8a183','#d7caa5']){
  this.poly([[-w,0],[0,d],[0,d-h],[-w,-h]],colors[0],'#384736',1);
  this.poly([[0,d],[w,0],[w,-h],[0,d-h]],colors[1],'#384736',1);
  this.poly([[-w,-h],[0,-d-h],[w,-h],[0,d-h]],colors[2],'#384736',1);
 }
 roof(w,d,h,roofHeight,palette=['#617886','#425c6a','#8d9b9b']){
  this.poly([[-w-4,-h],[0,-roofHeight-h],[w+4,-h],[0,d+5-h]],palette[0],'#314332',1.5);
  this.poly([[0,-roofHeight-h],[w+4,-h],[0,d+5-h]],palette[1]);
  for(let i=1;i<5;i++){const t=i/5;this.line([[-(w+4)*(1-t),-h-roofHeight*t],[0,-h+(d+5)*(1-t)-roofHeight*t],[(w+4)*(1-t),-h-roofHeight*t]],palette[2]+'70',.8);}
  this.line([[-w-4,-h],[0,d+5-h],[w+4,-h]],palette[2],2);
 }
 flag(x,y,color='#cb825b',scale=1){const c=this.ctx;c.save();c.translate(x,y);c.scale(scale,scale);this.line([[0,0],[0,-40]],'#523e2c',2);this.poly([[1,-39],[20,-36+Math.sin(this.time*3+x)*2],[17,-22],[1,-25]],color,'#573e30',.7);this.line([[4,-34],[13,-32],[11,-27]],'#f7e3ae',1.2);this.circle(0,-41,2,'#cfb673');c.restore();}
 window(x,y,scale=1){const c=this.ctx;c.save();c.translate(x,y);c.scale(scale,scale);this.poly([[-4,0],[-4,-8],[0,-12],[4,-8],[4,0]],'#344333','#d6c6a0',1.7);this.line([[0,-10],[0,0]],'#b9a777',1);c.restore();}
 stonework(w,d,h){for(let r=0;r<h/9;r++){const yy=d-r*9-3;this.line([[-w+2,yy-d],[0,yy],[w-2,yy-d]],'#776e5340',1);for(let n=0;n<3;n++){const xx=-w+((n+.5+(r%2)*.4)*w/3);this.line([[xx,yy+xx*d/w],[xx,yy+xx*d/w-7]],'#766f5040',.8);}}}
 building(b,selected){
  if(b.hp===0)return;
  if(!SPRITES[b.kind]){this.systemBuilding(b,selected);return;}
  if(this.illustratedBuilding(b,selected))return;
  const c=this.ctx,p=this.iso(b.x+(b.size-1)/2,b.y+(b.size-1)/2);c.save();c.translate(p.x,p.y);
  const hall=b.kind==='townhall',barracks=b.kind==='barracks',farm=b.kind==='farm',tower=b.kind==='tower',w=hall?62:barracks?58:38,d=hall?31:barracks?29:20,h=hall?61:barracks?43:tower?75:36;
  this.ellipse(5,13,w+14,d+7,'#263a263b');
  if(selected){this.poly([[-w-12,0],[0,-d-9],[w+12,0],[0,d+9]],'#dae6ac15','#e6d893',1.7);}
  if(farm){
   this.poly([[-56,0],[0,-28],[56,0],[0,28]],'#827349','#615d39',2);
   for(let row=0;row<7;row++){const r=-40+row*13;this.line([[r-10,-r*.45-17],[r+9,-r*.45+17]],'#b8a46a',3);for(let n=0;n<6;n++){const x=r-9+n*3.2,y=-r*.45-14+n*5.2;this.line([[x,y],[x-1,y-11-Math.sin(this.time*2+n)*1.2]],'#d6b967',1.7);this.line([[x-1,y-8],[x-4,y-12]],'#edd48b',2);}}
   for(const[x,y]of[[-53,0],[0,-27],[53,0],[0,27]]){this.line([[x,y],[x,y-13]],'#6a5032',3);this.circle(x,y-13,2,'#beaa75');}
   this.line([[-53,-8],[0,19],[53,-8]],'#a88d54',2);c.restore();return;
  }
  if(b.remaining&&b.constructing){
   this.box(w,d,9,['#b1a482','#8c886e','#cec3a0']);
   for(const x of [-w,0,w]){this.line([[x,d-Math.abs(x)*d/w],[x,d-Math.abs(x)*d/w-h]],'#84603b',4);this.line([[x-4,d-Math.abs(x)*d/w-h],[x+4,d-Math.abs(x)*d/w-h]],'#b58c59',3);}
   this.line([[-w,-h],[0,d-h],[w,-h]],'#b8915d',3);this.line([[-w,0],[0,d-h],[w,0]],'#a98453',2);this.roof(w,d,h,23,['#b9a47755','#7d8c7255','#b8b78b']);
   this.circle(-w+10,5,7,'#c2ae7a');this.line([[-w+10,-2],[-w+10,9]],'#79613d',1.5);
  }else{
   const colors=b.level>=5?['#d3c6a0','#a9ad94','#e8dab3']:['#c7bd9b','#9fa58c','#e0d0a6'];
   this.box(w,d,9,['#b4ae93','#90997f','#d4ccb0']);c.translate(0,-8);this.box(w,d,h,colors);this.stonework(w,d,h);
   if(tower){
    this.box(27,14,h+13,['#d5c9a8','#9eaa97','#e1d6b2']);
    this.line([[-28,-h+10],[0,-h+25],[28,-h+10]],'#6e7864',4);
    for(let k=0;k<4;k++){const xx=-26+k*17;this.poly([[xx,-h-2],[xx,-h-17],[xx+9,-h-12],[xx+9,-h+3]],'#ddd2b1','#747b61');}
    this.window(-12,-32,.65);this.window(13,-25,.65);this.flag(0,-h-15,'#c89c4d',.7);
   }else{
    // Timber framing, window recesses and a warm entrance make each silhouette readable.
    this.line([[-w,-h+4],[-w,-2],[0,d-2],[0,d-h+4],[w,-h+4]],'#69583c',3);
    for(const frac of [.3,.7]){const x=-w*frac,y=d*(1-frac);this.line([[x,y-2],[x,y-h+3]],'#8e795044',2);}
    this.window(-w*.65,d*.35-h*.48,.82);this.window(w*.52,d*.48-h*.45,.8);
    this.poly([[-15,d-2],[-15,d-24],[-10,d-29],[-3,d-24],[-3,d-2]],'#4b4d37','#d2bd8b',1.5);
    this.line([[-12,d-3],[-12,d-24]],'#7e714c',1);this.circle(-6,d-13,1,'#e1bc62');
    this.roof(w,d,h,hall?39:barracks?30:29,barracks?['#a36f55','#77523d','#d0a476']:['#708493','#435e6d','#9aabb0']);
    if(hall){
     for(const xx of [-42,42]){c.save();c.translate(xx,-15);this.box(18,9,85,['#d3c8a7','#a4ad96','#ded5b4']);this.stonework(18,9,85);this.roof(19,10,85,30,['#6f8492','#425e6d','#9cabb1']);this.window(-7,-45,.7);this.flag(0,-115,'#c9995c',.73);c.restore();}
     this.line([[-17,-65],[0,-57],[17,-65]],'#d2c8a2',3);this.circle(0,-68,7,'#c5aa68');this.line([[-3,-71],[0,-65],[3,-71]],'#f4e3a3',1.6);
     this.poly([[-20,d+4],[-20,d+12],[2,d+23],[20,d+12],[20,d+4],[0,d+15]],'#b4b496','#6e7b61');this.flag(21,-h+13,'#ce8c57',.75);
    }else if(barracks){
     this.flag(8,-h-28,'#a3654e',1);this.line([[-38,15],[-38,-15]],'#6c5c3c',3);this.line([[-46,0],[-29,-8]],'#d8d4bc',3);this.line([[-44,-10],[-30,3]],'#d8d4bc',3);
     this.poly([[22,18],[22,-8],[34,-14],[44,-7],[44,9],[34,23]],'#9e6948','#d2ab70',2);this.line([[33,-9],[33,18]],'#d8b77b',2);
    }else{
     c.save();c.translate(16,-h-12);this.box(7,4,20,['#b9b59d','#8d9c87','#d2c7a9']);c.restore();
     for(let i=0;i<3;i++){const t=(this.time*.35+i*.33)%1;this.ellipse(16+Math.sin(t*4)*6,-h-36-t*35,3+t*6,3+t*5,`rgba(238,234,205,${.22*(1-t)})`);}
     this.ellipse(-w-3,5,8,4,'#b49a62');this.line([[-w-10,-5],[-w+3,2]],'#799452',4);
    }
   }
   if(b.level>=5){this.flag(-w+6,-h-9,'#c99d45',.7);this.line([[-w,-4],[0,d-4],[w,-4]],'#d4b66d',3);}
   if(b.level>=10){this.circle(0,-h-36,5,'#f4db82');this.line([[-w-8,-h],[-w-8,-h-18]],'#e6d392',3);}
   c.translate(0,8);
   // Pots, barrels, stacked supplies and steps at human scale.
   this.ellipse(w+2,4,7,4,'#72573b');this.poly([[w-5,3],[w-5,-8],[w+9,-8],[w+9,3]],'#9e7b4f','#5f5338');this.ellipse(w+2,-8,7,3,'#ba9963');this.line([[w-5,-4],[w+9,-4]],'#6b694b',1.8);
  }
  if(b.remaining){const progress=1-b.remaining/b.total;this.bar(0,-h-51,60,progress,'#e1c17b');}
  if(b.queue.length){this.bar(0,-h-41,52,1-b.queue[0].remaining/b.queue[0].total,'#afd38b');}
  c.restore();
 }
 illustratedBuilding(b,selected){
  if(!this.artReady||!SPRITES[b.kind])return false;
  const c=this.ctx,p=this.iso(b.x+(b.size-1)/2,b.y+(b.size-1)/2),{source,w,h,base}=buildingSprite(b);
  c.save();c.translate(p.x,p.y);this.ellipse(5,base-5,w*.45,b.size*7,'#3e732c22');
  if(selected)this.poly([[-b.size*31,0],[0,-b.size*15.5],[b.size*31,0],[0,b.size*15.5]],'#fff68b20','#fff4a3',2.2);
  if(b.constructing&&b.remaining)c.globalAlpha=.28+.65*(1-b.remaining/b.total);
  c.drawImage(this.atlas,...source,-w/2,base-h,w,h);c.globalAlpha=1;
  if(b.constructing&&b.remaining){
   for(const x of [-w*.4,w*.4]){this.line([[x,base-10],[x,base-h*.72]],'#9b642e',3);this.line([[x-5,base-h*.72],[x+5,base-h*.72]],'#dba251',3);}
   this.line([[-w*.4,base-h*.6],[w*.4,base-h*.6]],'#d0a05b',3);this.line([[-w*.4,base-10],[w*.4,base-h*.6]],'#bd8d4b',2);
  }
  if(b.kind==='house'&&!b.constructing)for(let i=0;i<3;i++){const t=(this.time*.3+i*.34)%1;this.ellipse(w*.16+Math.sin(t*5)*4,base-h*.89-t*28,2+t*5,2+t*4,`rgba(255,254,235,${.3*(1-t)})`);}
  if(selected){c.fillStyle='#fff4c8';c.strokeStyle='#6c4e22';c.lineWidth=3;c.font='bold 10px Trebuchet MS, sans-serif';c.textAlign='center';c.strokeText('Level '+b.level,0,base+14);c.fillText('Level '+b.level,0,base+14);}
  if(b.level>=5&&b.kind!=='townhall')this.flag(w*.32,base-h*.6,'#318bc6',.55);
  if(b.faction==='enemy'){this.flag(-w*.35,base-h*.72,'#b44737',.65);this.bar(0,base-h-27,60,b.hp/b.maxHp,'#dd7456');}
  if(b.remaining)this.bar(0,base-h-8,64,1-b.remaining/b.total,'#ffd451');
  if(b.queue.length)this.bar(0,base-h-17,58,1-b.queue[0].remaining/b.queue[0].total,'#a2df55');
  c.restore();return true;
 }
 hitBuilding(b,x,y){
  if(!this.artReady||!SPRITES[b.kind])return undefined;const p=this.screen(b.x+(b.size-1)/2,b.y+(b.size-1)/2),{source,w,h,base}=buildingSprite(b),z=this.camera.zoom;
  const localX=(x-p.x)/z+w/2,localY=(y-p.y)/z-base+h;if(localX<0||localX>=w||localY<0||localY>=h)return false;
  const sx=Math.floor(source[0]+localX/w*source[2]),sy=Math.floor(source[1]+localY/h*source[3]);return this.buildingPixels[(sy*this.atlas.naturalWidth+sx)*4+3]>60;
 }
 bar(x,y,w,progress,color){const c=this.ctx;c.fillStyle='#172d28d9';c.fillRect(x-w/2-2,y-2,w+4,7);c.fillStyle='#ffffff18';c.fillRect(x-w/2,y,w,3);c.fillStyle=color;c.fillRect(x-w/2,y,w*Math.max(0,Math.min(1,progress)),3);}
 tree(n,selected){
  const c=this.ctx,p=this.iso(n.x,n.y);c.save();c.translate(p.x,p.y);const variation=hash(n.x,n.y),sz=.8+variation*.35;c.scale(sz,sz);
  this.ellipse(8,3,23,10,'#263d2730');if(n.amount===0){this.ellipse(0,0,7,4,'#8c7151');this.ellipse(0,-5,6,3,'#c5ad76');c.restore();return;}
  if(selected)this.ellipse(0,1,18,8,'#f0d49766');
  this.poly([[-4,1],[-3,-46],[3,-49],[6,0]],'#806044','#4d5433');this.line([[1,-18],[-14,-37]],'#765f3e',3);this.line([[1,-27],[12,-47]],'#765f3e',3);
  const colors=variation>.67?['#5b942e','#80b83d','#b7d95d']:['#328844','#50aa48','#8bcd58'];
  for(const[x,y,r]of[[-13,-48,17],[13,-47,19],[0,-66,21],[-15,-62,14],[15,-65,16],[0,-81,14]]){this.circle(x+1,y+3,r,'#2e703b');this.circle(x,y,r-1,colors[0]);this.circle(x-3,y-5,r*.73,colors[1]);this.circle(x-6,y-8,r*.32,colors[2]);}
  for(let i=0;i<13;i++){const x=(hash(i,n.x)-.5)*34,y=-43-hash(i,n.y)*40;this.line([[x,y],[x+3,y-2]],'#d3d69142',1.5);}
  c.restore();
 }
 rock(n,selected){const c=this.ctx,p=this.iso(n.x,n.y);c.save();c.translate(p.x,p.y);if(n.amount===0){this.ellipse(0,0,9,4,'#8d9478');c.restore();return;}this.ellipse(4,3,24,10,'#263d2735');if(selected)this.ellipse(0,1,25,12,'#e6d69666');this.poly([[-24,0],[-17,-22],[0,-33],[16,-23],[24,0],[0,10]],'#a9aea0','#646f5b',1.5);this.poly([[-24,0],[-17,-22],[0,-15],[0,10]],'#8d978d');this.poly([[0,-33],[16,-23],[0,-15],[-17,-22]],'#c2c6ae');this.line([[0,-15],[16,-23],[24,0]],'#757f70',1);if(n.kind==='gold')for(const[x,y]of[[-10,-13],[8,-10],[12,-21],[-3,-24]]){this.poly([[x-3,y],[x,y-6],[x+5,y-4],[x+2,y+3]],'#e7be63','#ae9554');}c.restore();}
 unit(u,selected){
  if(['archer','pikeman','dragon','veteran'].includes(u.kind)){this.systemUnit(u,selected);return;}
  if(this.illustratedUnit(u,selected))return;
  if(u.hp<=0&&u.dead<=0)return;const c=this.ctx,p=this.iso(u.x,u.y);c.save();c.translate(p.x,p.y);if(u.hp<=0){c.globalAlpha=u.dead/1.2;c.rotate(1.2);this.ellipse(0,0,8,3,'#706d4e');this.line([[0,0],[0,-20]],'#9e8667',7);c.restore();return;}
  c.scale(UNIT_SCALE,UNIT_SCALE);
  const worker=u.kind==='worker',enemy=u.faction==='enemy',moving=u.path.length>0,working=u.task?.kind==='gather'&&!moving,bob=moving?Math.sin(this.time*13+Number(u.id.slice(1)))*1.8:Math.sin(this.time*2)*.4;
  this.ellipse(1,2,9,4,'#24362760');if(selected){this.ellipse(0,1,12,6,'#b2d5aa24');c.strokeStyle='#dfe7b1';c.lineWidth=1.4;c.beginPath();c.ellipse(0,1,12,6,0,0,Math.PI*2);c.stroke();}
  const stride=moving?Math.sin(this.time*13)*4:0;this.line([[-3,-7],[-4+stride,0]],'#5a5840',3);this.line([[3,-7],[4-stride,0]],'#5a5840',3);c.translate(0,bob);
  if(!worker)this.poly([[-5,-23],[-9,-6],[0,-3],[8,-7],[5,-23]],enemy?'#bd5741':u.royal?'#d2a63a':'#318fc3','#384f41',1);
  this.poly([[-5,-22],[-6,-8],[5,-8],[5,-22]],worker?'#65a8d0':enemy?'#b1784f':'#d4e0dd','#4c5d46',.7);
  this.line([[-5,-12],[5,-12]],'#846538',2);this.circle(0,-27,6,'#f1c88c');this.ellipse(-2,-24,3,1.4,'#e9ac79');this.circle(2,-28,.85,'#3e3b2e');this.line([[1,-24],[3,-24]],'#a96643',.7);
  if(worker){this.ellipse(-1,-32,8,2.8,'#d3a644');this.poly([[-4,-32],[-3,-37],[2,-37],[5,-32]],'#f0c85c');this.line([[-5,-32],[5,-32]],'#b57e2e',1.5);}
  else{this.circle(0,-29,5,'#b9c3b9');this.poly([[-5,-28],[5,-28],[4,-24],[2,-24],[2,-28]],'#82918b');this.line([[0,-34],[0,-30]],enemy?'#b37b51':'#d1b878',2);}
  const arm=working?Math.sin(this.time*10)*7:0;this.line([[-5,-20],[-8,-13-arm]],'#d7b88b',2.5);this.line([[5,-20],[8,-13+arm]],'#d7b88b',2.5);
  if(worker){this.line([[8,-13+arm],[15,-26+arm]],'#775d3b',2);this.poly([[10,-24+arm],[16,-29+arm],[21,-26+arm],[15,-21+arm]],'#b7beb0','#60705c',.5);}
  else{const swing=u.attackTimer>.6?Math.sin((u.attackTimer-.6)*8)*9:0;this.line([[8,-14],[12+swing,-33+swing]],'#dce0c8',2.7);this.line([[7,-18],[14,-15]],'#ccae62',2);this.poly([[-10,-21],[-5,-19],[-6,-10],[-10,-7],[-14,-12],[-15,-19]],enemy?'#8e4c3d':'#4f7880','#c5b782',1);this.line([[-10,-18],[-10,-11]],'#d7c78e',1);}
  if(selected||u.hp<u.maxHp)this.bar(0,-43,25,u.hp/u.maxHp,enemy?'#d59777':'#b7d18c');if(working)this.bar(0,-51,27,u.progress/(u.task?.chain==='tree'?RULES.treeTime:RULES.gatherTime),'#e6c778');c.restore();
 }
 readUnitBaselines(){
  const img=this.unitAtlas,canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;const c=canvas.getContext('2d',{willReadFrequently:true});c.drawImage(img,0,0);const data=c.getImageData(0,0,canvas.width,canvas.height).data,cellW=canvas.width/4,cellH=canvas.height/3;this.unitBaselines=[];
  for(let row=0;row<3;row++)for(let col=0;col<4;col++){let bottom=cellH*.9;outer:for(let y=Math.floor((row+1)*cellH)-1;y>=row*cellH;y--){for(let x=Math.floor(col*cellW);x<(col+1)*cellW;x++){if(data[(y*canvas.width+x)*4+3]>65){bottom=y-row*cellH;break outer;}}}this.unitBaselines.push(bottom);}
 }
 illustratedUnit(u,selected){
  if(!this.unitArtReady)return false;if(u.hp<=0&&u.dead<=0)return true;
  const c=this.ctx,p=this.iso(u.x,u.y),moving=u.path.length>0,working=u.task?.kind==='gather'&&!moving,row=u.kind==='worker'?0:u.faction==='enemy'?2:1;
  const frame=working?(Math.floor(this.time*3)%2?3:0):moving?1+Math.floor(this.time*7)%2:u.attackTimer>.55?3:0;
  const cw=this.unitAtlas.naturalWidth/4,ch=this.unitAtlas.naturalHeight/3,scale=55/(ch*.94),baseline=this.unitBaselines[row*4+frame];
  c.save();c.translate(p.x,p.y);this.ellipse(1,2,12,5,'#35683235');
  if(selected){c.strokeStyle='#fff4a5';c.lineWidth=2;c.fillStyle='#fff49530';c.beginPath();c.ellipse(0,1,15,7,0,0,Math.PI*2);c.fill();c.stroke();}
  c.save();if(u.facing<0)c.scale(-1,1);if(u.hp<=0){c.globalAlpha=Math.max(0,u.dead/1.2);c.rotate(1.15);}else if(moving)c.translate(0,Math.sin(this.time*14)*.7);
  c.drawImage(this.unitAtlas,frame*cw,row*ch,cw,ch,-cw*scale/2,-baseline*scale,cw*scale,ch*scale);c.restore();
  if(u.hp>0){if(selected||u.hp<u.maxHp)this.bar(0,-61,30,u.hp/u.maxHp,u.faction==='enemy'?'#db7854':'#9fce49');if(working)this.bar(0,-70,31,u.progress/(u.task?.chain==='tree'?RULES.treeTime:RULES.gatherTime),'#f5ce4f');}
  c.restore();return true;
 }
 paintUnitPortrait(canvas,unit){
  const previous=this.ctx,c=canvas.getContext('2d');this.ctx=c;c.save();c.clearRect(0,0,canvas.width,canvas.height);const g=c.createLinearGradient(0,0,0,canvas.height);g.addColorStop(0,unit.kind==='worker'?'#c9e7ad':'#b6dfe2');g.addColorStop(1,'#83b887');c.fillStyle=g;c.fillRect(0,0,canvas.width,canvas.height);c.translate(canvas.width/2,canvas.height*.91);c.scale(canvas.height/59,canvas.height/59);this.unit({...unit,x:0,y:0,id:'u0',hp:unit.maxHp,maxHp:unit.maxHp,path:[],task:null},false);c.restore();this.ctx=previous;
 }
 paintResourcePortrait(canvas,node){
  const previous=this.ctx,c=canvas.getContext('2d');this.ctx=c;c.save();c.clearRect(0,0,canvas.width,canvas.height);c.fillStyle='#bfdc90';c.fillRect(0,0,canvas.width,canvas.height);c.translate(canvas.width/2,canvas.height*.92);const scale=canvas.height/108;c.scale(scale,scale);if(node.kind==='tree')this.tree({...node,x:0,y:0},false);else if(node.resource)this.drop({...node,x:0,y:0});else this.rock({...node,x:0,y:0},false);c.restore();this.ctx=previous;
 }
 drop(d){const c=this.ctx,p=this.iso(d.x,d.y);c.save();c.translate(p.x,p.y-4+Math.sin(this.time*2)*1.5);this.ellipse(0,4,12,6,'#dcd7832a');if(d.resource==='wood'){for(let i=0;i<3;i++){this.line([[-7+i*2,i*-3],[7+i*2,-6-i*3]],'#826341',5);this.circle(-7+i*2,-i*3,2.4,'#d1b27a');}}else if(d.resource==='food'){this.poly([[-8,1],[-6,-9],[6,-9],[8,1],[0,5]],'#c6a156','#e5c47d');this.line([[-4,-9],[4,-16]],'#c9d083',3);}else this.poly([[-8,0],[-4,-12],[4,-14],[10,-5],[3,4]],d.resource==='gold'?'#e2bd65':'#bec7b5','#6b795c');this.circle(11,-15,2,'#fff1ae');c.font='bold 9px system-ui';c.fillStyle='#fff1bb';c.textAlign='center';c.fillText('+'+d.amount,0,-21);c.restore();}
 paintBlueprint(canvas,kind,level=1){
  const previous=this.ctx,c=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
  this.ctx=c;c.save();c.clearRect(0,0,w,h);const gradient=c.createRadialGradient(w*.5,h*.45,0,w*.5,h*.5,w*.65);gradient.addColorStop(0,'#ecf4c1');gradient.addColorStop(1,'#b6d58a');c.fillStyle=gradient;c.fillRect(0,0,w,h);c.translate(w/2,h*.78);const scale=Math.min(w/225,h/220);c.scale(scale,scale);
  this.poly([[-77,0],[0,-38],[77,0],[0,38]],'#90c66a','#6b9149');
  const size=BUILDINGS[kind].size;this.building({kind,x:-(size-1)/2,y:-(size-1)/2,size,level,remaining:0,queue:[]},false);
  c.restore();this.ctx=previous;
 }
 systemBuilding(b,selected){
  if(b.hp===0)return;const c=this.ctx,p=this.iso(b.x+(b.size-1)/2,b.y+(b.size-1)/2),wall=b.kind==='wall',w=wall?28:48,h=wall?35:b.kind==='ballista'?44:56;
  c.save();c.translate(p.x,p.y);if(b.constructing)c.globalAlpha=.45;
  this.box(w,w/2,h,wall?['#b7bcc0','#7e8c97','#d9d7c9']:['#a89b85','#7b7f76','#d6bc8b']);
  if(!wall)this.flag(w-8,-h+10,b.faction==='enemy'?'#b45242':'#376c91',.7);
  if(b.kind==='ballista'){this.line([[-30,-h-8],[30,-h+6]],'#613d24',7);this.line([[0,-h+15],[0,-h-28]],'#4b4130',5);this.line([[-30,-h-8],[0,-h-28],[30,-h+6]],'#e3d3ac',1.5);}
  const marks={archery:'⌁',forge:'⚒',nest:'♨',mine:'◈',quarry:'⬟',lumber:'▰',wall:'',ballista:''};
  c.textAlign='center';c.font='bold 25px serif';c.fillStyle='#fff2c7';c.fillText(marks[b.kind]||'',0,-h*.45);
  c.font='bold 9px Trebuchet MS';c.lineWidth=3;c.strokeStyle='#384235';c.fillStyle='#fff7d5';const label=BUILDINGS[b.kind]?.name||b.kind;c.strokeText(label,0,wall?15:34);c.fillText(label,0,wall?15:34);
  if(selected)this.poly([[-b.size*31,0],[0,-b.size*15.5],[b.size*31,0],[0,b.size*15.5]],'#fff99f11','#fff5a5',2);
  if(b.remaining)this.bar(0,-h-15,56,1-b.remaining/b.total,'#f6ce5c');
  if(b.queue?.length)this.bar(0,-h-23,56,1-b.queue[0].remaining/b.queue[0].total,'#acd662');
  if(b.hp<b.maxHp)this.bar(0,-h-32,55,b.hp/b.maxHp,b.faction==='enemy'?'#df6f53':'#98cf5a');c.restore();
 }
 systemUnit(u,selected){
  if(u.hp<=0&&u.dead<=0)return;const c=this.ctx,p=this.iso(u.x,u.y),dragon=u.kind==='dragon',moving=u.path.length>0;
  c.save();c.translate(p.x,p.y);if(u.hp<=0){c.globalAlpha=u.dead/1.2;c.rotate(1.2);}if(moving)c.translate(0,Math.sin(this.time*12)*1.5);
  this.ellipse(0,1,dragon?21:13,dragon?9:6,'#28472955');if(selected){c.strokeStyle='#fff5a3';c.lineWidth=2;c.beginPath();c.ellipse(0,1,dragon?24:16,dragon?11:7,0,0,Math.PI*2);c.stroke();}
  if(dragon){const flap=Math.sin(this.time*6)*5;this.poly([[-7,-20],[-36,-45+flap],[-27,-13],[-10,-8]],'#b85b3f','#6e3b27',2);this.poly([[7,-20],[36,-45-flap],[27,-13],[10,-8]],'#d49341','#6e3b27',2);this.ellipse(0,-17,13,18,'#be8139');this.line([[-7,-6],[-12,0]],'#6d4b2a',5);this.line([[7,-6],[12,0]],'#6d4b2a',5);this.circle(5,-36,10,'#ddaa50');this.poly([[0,-43],[0,-53],[7,-44]],'#f0e0a7');this.circle(9,-38,2,'#312f2a');this.line([[-9,-10],[-26,-4]],'#aa7138',6);}
  else{const color=u.kind==='archer'?'#6f698f':u.kind==='veteran'?'#bd9b45':'#557d8b';this.line([[-5,-10],[-7,0]],'#453c32',4);this.line([[5,-10],[7,0]],'#453c32',4);this.poly([[-8,-34],[-10,-9],[8,-9],[8,-34]],color,'#424838',2);this.circle(0,-41,8,'#e6ba83');this.poly([[-8,-44],[-5,-52],[6,-52],[9,-42]],'#b2bcb8','#526261',1.5);
   if(u.kind==='archer'){c.strokeStyle='#bd9c61';c.lineWidth=3;c.beginPath();c.ellipse(13,-28,8,17,0,-Math.PI/2,Math.PI/2);c.stroke();this.line([[13,-45],[13,-11]],'#eee1bd',1);}
   else if(u.kind==='pikeman'){this.line([[12,-7],[12,-61]],'#9a743f',3);this.poly([[8,-60],[12,-71],[17,-60]],'#d0d7cc','#556559');}
   else{this.poly([[-13,-33],[-23,-30],[-22,-16],[-14,-10],[-8,-18]],'#3b7290','#edce70',2);this.line([[12,-15],[18,-46]],'#e4e5cd',4);c.fillStyle='#f4d374';c.font='bold 17px serif';c.fillText('★',-9,-31);}
  }
  if(u.hp>0&&(selected||u.hp<u.maxHp))this.bar(0,dragon?-62:-64,32,u.hp/u.maxHp,u.faction==='enemy'?'#df725a':'#a5cf57');c.restore();
 }
 territoryGround(s){
  const owned=new Set(ensureTerritory(s).owned);
  for(let gx=0;gx<9;gx++)for(let gy=0;gy<9;gy++){
   const id=gx+','+gy;if(owned.has(id))continue;
   const a=this.iso(gx*6-.5,gy*6-.5),b=this.iso(gx*6+5.5,gy*6-.5),d=this.iso(gx*6-.5,gy*6+5.5),e=this.iso(gx*6+5.5,gy*6+5.5);
   this.poly([[a.x,a.y],[b.x,b.y],[e.x,e.y],[d.x,d.y]],'#273f3848');
  }
  for(const p of frontierPlots(s)){
   const a=this.iso(p.x-.5,p.y-.5),b=this.iso(p.x+5.5,p.y-.5),d=this.iso(p.x-.5,p.y+5.5),e=this.iso(p.x+5.5,p.y+5.5);this.line([[a.x,a.y],[b.x,b.y],[e.x,e.y],[d.x,d.y],[a.x,a.y]],p.hostile?'#c88569':'#efd793',1.5);
   const q=this.iso(p.x+2.5,p.y+2.5),c=this.ctx;c.fillStyle=p.hostile?'#773d2de8':'#e9d2a0ee';c.fillRect(q.x-49,q.y-12,98,27);c.textAlign='center';c.font='bold 10px Trebuchet MS';c.fillStyle=p.hostile?'#fff3ca':'#624a28';c.fillText(p.hostile?'⚔ CONQUER':'FOR SALE',q.x,q.y+5);
  }
 }
 estateGround(){
  for(let x=8;x<=20;x++)for(let y=8;y<=22;y++){if(x<10&&y>18)continue;this.tile(x,y,`hsl(61,16%,${55+hash(x,y)*5}%)`,'#75836c30');}
  for(const[x,y]of[[10,8],[11,8],[15,8],[16,8],[8,20],[8,21],[20,10],[20,11],[18,22],[19,22]]){const p=this.iso(x,y);this.ellipse(p.x,p.y,17,7,'#385f3a');for(let i=0;i<5;i++)this.circle(p.x-11+i*5,p.y-4+(i%2)*3,2,i%2?'#d2bd80':'#e2d4b0');}
  const p=this.iso(11,13);this.poly([[p.x-23,p.y],[p.x,p.y-12],[p.x+23,p.y],[p.x,p.y+12]],'#c4c9ae','#6d826f',2);this.ellipse(p.x,p.y-2,14,7,'#79aaa0');this.line([[p.x,p.y-2],[p.x,p.y-25]],'#d4ded130',2);this.circle(p.x,p.y-25,3,'#cce4d2');
 }
 makeTerrain(){
  const old=this.ctx,canvas=document.createElement('canvas');canvas.width=SIZE*62+120;canvas.height=SIZE*31+180;this.ctx=canvas.getContext('2d');const c=this.ctx;c.translate(SIZE*31+60,70);
  for(let sum=0;sum<SIZE*2;sum++)for(let x=0;x<SIZE;x++){const y=sum-x;if(y<0||y>=SIZE)continue;
   const water=terrain(x,y)==='water',v=hash(x,y);this.tile(x,y,water?`hsl(178,42%,${61+v*1.5}%)`:`hsl(96,46%,${57+v*.8}%)`);
   const p=this.iso(x,y);
   if(water){this.line([[p.x-10,p.y+3],[p.x+4,p.y+3]],'#c0dac124',.9);continue;}
   for(let i=0;i<5;i++){const xx=p.x+(hash(x*7+i,y)-.5)*36,yy=p.y+(hash(x,y*6+i)-.5)*16;this.line([[xx,yy],[xx+1,yy-2-hash(i,y)*2]],v>.4?'#ccd39638':'#496b3833',.8);}
   if(v>.87){this.circle(p.x+8,p.y-1,1.3,'#d7cc8270');this.circle(p.x+10,p.y+2,1,'#d9dbad90');}
  }
  // A worn road and stepping stones tie the small settlement together.
  const road=[[9,17],[11,16],[14,16],[16,17],[20,17],[22,16],[24,15]];
  const pts=road.map(p=>{const q=this.iso(...p);return[q.x,q.y];});this.line(pts,'#aeaa784a',40);this.line(pts,'#c2b98785',25);this.line(pts,'#c4be9280',17);
  for(let i=0;i<80;i++){const f=i/(80-1)*(road.length-1),k=Math.min(Math.floor(f),road.length-2),t=f-k,a=this.iso(...road[k]),b=this.iso(...road[k+1]);const x=a.x+(b.x-a.x)*t+(hash(i,5)-.5)*15,y=a.y+(b.y-a.y)*t+(hash(i,8)-.5)*8;this.ellipse(x,y,2.2,1,'#8c8e6755');}
  for(const[x,y]of[[8,18],[19,11],[14,21],[23,17],[10,10],[18,6],[6,21],[22,24]]){const p=this.iso(x,y);for(let i=0;i<6;i++){const xx=p.x+(hash(i,x)-.5)*22,yy=p.y+(hash(i,y)-.5)*10;this.line([[xx,yy],[xx+1,yy-5]],'#627d42',1);this.circle(xx+1,yy-5,1.7,i%2?'#d9d6a0':'#bca07e');}}
  this.ctx=old;this.cache=canvas;
 }
 draw(s,ui){
  this.time=s.time;const c=this.ctx,z=this.camera.zoom;c.setTransform(this.dpr,0,0,this.dpr,0,0);c.clearRect(0,0,this.w,this.h);c.fillStyle='#86cbd0';c.fillRect(0,0,this.w,this.h);
  c.save();c.translate(this.camera.x,this.camera.y);c.scale(z,z);
  if(!this.cache)this.makeTerrain();c.drawImage(this.cache,-SIZE*31-60,-70);
  if(s.scene==='founder')this.estateGround();
  if(s.scene!=='founder'&&s.scene!=='battle')this.territoryGround(s);
  // Small rocks and shore reeds outside the village.
  for(let i=0;i<21;i++){const p=this.iso(2.2+hash(i,4)*1.6,4+i);this.ellipse(p.x,p.y,5,2.7,'#aab39a');}
  const drawables=[...s.nodes.filter(n=>n.kind!=='tree'||n.amount>0).map(n=>({depth:n.x+n.y,draw:()=>n.kind==='tree'?this.tree(n,ui.selected.has(n.id)):this.rock(n,ui.selected.has(n.id))})),...s.buildings.filter(b=>b.hp!==0).map(b=>({depth:b.x+b.y+b.size-1,draw:()=>this.building(b,ui.selected.has(b.id))})),...s.units.map(u=>({depth:u.x+u.y,draw:()=>this.unit(u,ui.selected.has(u.id))})),...s.drops.map(d=>({depth:d.x+d.y+.3,draw:()=>this.drop(d)}))];
  // Raiders' camp: a distinctly different, original silhouette, not a capturable town yet.
  if(!s.opening&&s.scene!=='founder'&&s.scene!=='battle')drawables.push({depth:50,draw:()=>{const p=this.iso(25,25);c.save();c.translate(p.x,p.y);this.ellipse(0,3,46,20,'#665b3a50');this.poly([[-32,0],[0,-49],[34,0],[3,17]],'#9e7652','#615c3e',2);this.poly([[0,-49],[34,0],[3,17]],'#785e44');this.poly([[-3,10],[0,-24],[14,3],[8,13]],'#3b4430');this.flag(32,0,'#9d5b44',.9);c.restore();}});
  if(s.scene==='founder'){
   for(let i=0;i<11;i++){const x=6,y=9+i,p=this.iso(x,y);drawables.push({depth:x+y,draw:()=>{c.save();c.translate(p.x,p.y);this.box(21,10,21,['#b8bca5','#929e8c','#d0d0ad']);for(const a of [-15,0,15])this.line([[a,-21+Math.abs(a)*.2],[a,-29+Math.abs(a)*.2]],'#c8caae',6);c.restore();}});}
   for(const u of s.units.filter(u=>u.ruler)){drawables.push({depth:u.x+u.y+.1,draw:()=>{const p=this.iso(u.x,u.y);this.poly([[p.x-5,p.y-50],[p.x-5,p.y-57],[p.x-2,p.y-54],[p.x,p.y-60],[p.x+2,p.y-54],[p.x+5,p.y-57],[p.x+5,p.y-50]],'#f0cf76','#5c6139',.7);}});}
  }
  drawables.sort((a,b)=>a.depth-b.depth);for(const d of drawables)d.draw();
  if(ui.placement&&ui.hover){const x=Math.round(ui.hover.x),y=Math.round(ui.hover.y),kind=ui.placement.kind,size=BUILDINGS[kind].size,ok=canPlace(s,kind,x,y,ui.placement.id);for(let dx=0;dx<size;dx++)for(let dy=0;dy<size;dy++)this.tile(x+dx,y+dy,ok?'#b9db9780':'#d0796570',ok?'#e5f1be':'#f3b09a');c.globalAlpha=.55;this.building({kind,x,y,size,level:1,remaining:0,queue:[]},false);c.globalAlpha=1;}
  if(ui.guide){const g=ui.guide,p=this.iso(g.x+(g.size?(g.size-1)/2:0),g.y+(g.size?(g.size-1)/2:0)),r=22+Math.sin(this.time*3)*3;c.strokeStyle='#ffe558';c.lineWidth=3;c.beginPath();c.ellipse(p.x,p.y,r,r*.5,0,0,Math.PI*2);c.stroke();c.textAlign='center';c.font='bold 11px Trebuchet MS';c.strokeStyle='#654822';c.lineWidth=4;c.fillStyle='#fff3a4';const label=g.label||'▼';c.strokeText(label,p.x,p.y-(g.size?120:g.kind==='tree'?105:70));c.fillText(label,p.x,p.y-(g.size?120:g.kind==='tree'?105:70));}
  if(ui.marker){const p=this.iso(ui.marker.x,ui.marker.y),r=10+(1-ui.marker.life)*15;c.strokeStyle=`rgba(246,225,155,${ui.marker.life})`;c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y,r,r*.5,0,0,Math.PI*2);c.stroke();}
  for(const e of s.effects){const p=this.iso(e.x,e.y);if(['hit','resource','xp','levelup'].includes(e.kind)){c.fillStyle=e.kind==='hit'?'#fff1df':e.kind==='xp'?'#c5ecff':e.kind==='levelup'?'#ffe368':'#fff2b0';c.font=`bold ${e.kind==='hit'?12:11}px system-ui`;c.textAlign='center';c.strokeStyle='#283e2c';c.lineWidth=3;const y=p.y-35-(1-e.life/(e.kind==='hit'?.7:e.kind==='levelup'?2.5:1.8))*25;c.strokeText(e.text,p.x,y);c.fillText(e.text,p.x,y);}else if(e.kind==='complete'){c.strokeStyle='#f2d289';c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y,45+(1-e.life/.7)*20,20,0,0,Math.PI*2);c.stroke();}else if(e.kind==='spark'){for(let i=0;i<4;i++)this.circle(p.x+Math.sin(i*2)*(1-e.life)*20,p.y-15+Math.cos(i*2)*(1-e.life)*15,1.5,'#e9cd84');}}
  for(let i=0;i<4;i++){const p=this.iso(9+i*3+Math.sin(this.time*.17+i)*.7,18+Math.cos(this.time*.13+i)*1.2);const flutter=2+Math.sin(this.time*10+i)*1.5;this.ellipse(p.x-2,p.y-18,flutter,2,i%2?'#fff3b6':'#f5c377');this.ellipse(p.x+2,p.y-18,flutter,2,i%2?'#fff3b6':'#f5c377');}
  c.restore();
  const vignette=c.createRadialGradient(this.w*.57,this.h*.48,this.h*.2,this.w*.5,this.h*.5,this.w*.7);vignette.addColorStop(0,'#fff4cf00');vignette.addColorStop(1,'#5d963c12');c.fillStyle=vignette;c.fillRect(0,0,this.w,this.h);
  if(ui.box){const b=ui.box;c.fillStyle='#e0e6b51a';c.strokeStyle='#e4dfab';c.lineWidth=1;c.fillRect(b.x,b.y,b.w,b.h);c.strokeRect(b.x,b.y,b.w,b.h);}
  if(ui.hoverName&&!ui.placement&&ui.mouse){c.font='10px system-ui';const text=ui.hoverName,width=c.measureText(text).width+22,x=Math.min(this.w-width-8,ui.mouse.x+15),y=ui.mouse.y+23;c.fillStyle='#18332ee8';c.beginPath();c.roundRect(x,y,width,26,5);c.fill();c.fillStyle='#f0e8c8';c.textAlign='left';c.fillText(text,x+11,y+17);}
 }
}
