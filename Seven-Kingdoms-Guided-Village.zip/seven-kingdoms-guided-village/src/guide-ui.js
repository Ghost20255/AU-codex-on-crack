import {updateTutorial,TUTORIAL_STEPS,TUTORIAL_MOVE} from './tutorial.js';
import {ownsTile} from './territory.js';
export function createGuideUI({getState,ui,renderer,select,focusBuilding,openShop,persist}){
 const box=document.getElementById('tutorial-coach');let key='',current=null;
 function guideTarget(s,step){
  const worker=s.units.find(u=>u.kind==='worker'&&u.faction==='player'&&u.hp>0);
  if(step.target==='move')return {...TUTORIAL_MOVE,label:'MOVE HERE'};
  if(step.target==='townhall'||step.target==='recruit')return s.buildings.find(b=>b.kind==='townhall');
  if(step.target==='worker')return worker;
  if(step.target==='tree'){const active=worker?.task?.kind==='gather'&&s.nodes.find(n=>n.id===worker.task.target&&n.kind==='tree'&&n.amount>0);return active||s.nodes.filter(n=>n.kind==='tree'&&n.amount>0&&ownsTile(s,n.x,n.y)).sort((a,b)=>Math.hypot(a.x-(worker?.x||13),a.y-(worker?.y||15))-Math.hypot(b.x-(worker?.x||13),b.y-(worker?.y||15)))[0];}
  if(step.target==='wood')return s.drops.find(d=>d.resource==='wood');
  if(step.target==='food')return s.drops.find(d=>d.resource==='food')||s.buildings.find(b=>b.kind==='farm');
  if(step.target==='border'){const camp=s.frontierCamps?.find(c=>!c.resolved);return camp&&s.units.find(u=>camp.defenders.includes(u.id)&&u.hp>0);}
  return s.buildings.find(b=>b.kind===(step.target==='soldier'?'barracks':step.target));
 }
 function update(){
  const s=getState();current=updateTutorial(s,[...ui.selected]);const visible=s.tutorial?.enabled&&!s.battle&&!document.body.classList.contains('visiting');box.hidden=!visible;
  ui.guide=visible&&current?guideTarget(s,current):null;if(!visible)return;
  const nextKey=JSON.stringify([current?.id,s.tutorial.enabled]);if(key!==nextKey){key=nextKey;box.innerHTML=current?`<span class="eyebrow">GUIDED START · ${TUTORIAL_STEPS.indexOf(current)+1} / ${TUTORIAL_STEPS.length}</span><h3>${current.title}</h3><p>${current.text}</p><button class="action" id="guide-action">Show me</button><button class="guide-dismiss" id="guide-dismiss">Hide guide</button>`:'<span class="eyebrow">TUTORIAL COMPLETE</span><h3>Your kingdom is underway</h3><p>Keep following the quests. Buy land beside your border and grow your army.</p><button class="guide-dismiss" id="guide-dismiss">Continue playing</button>';}
  document.querySelectorAll('.tutorial-highlight').forEach(e=>e.classList.remove('tutorial-highlight'));
  if(current){const selector={recruit:'[data-action="recruit"]',farm:'[data-build="farm"]',house:'[data-build="house"]',barracks:'[data-build="barracks"]',soldier:'[data-action="train"]'}[current.target];if(selector)document.querySelector(selector)?.classList.add('tutorial-highlight');}
 }
 box.addEventListener('click',e=>{
  if(e.target.closest('#guide-dismiss')){getState().tutorial.enabled=false;ui.guide=null;box.hidden=true;document.querySelectorAll('.tutorial-highlight').forEach(e=>e.classList.remove('tutorial-highlight'));persist();return;}
  if(!e.target.closest('#guide-action')||!current)return;
  const s=getState(),worker=s.units.find(u=>u.kind==='worker'&&u.faction==='player'&&u.hp>0);
  if(['townhall','recruit'].includes(current.target)){focusBuilding('townhall');return;}
  if(['farm','house','barracks'].includes(current.target)){openShop(current.target);return;}
  if(current.target==='soldier'){focusBuilding('barracks');return;}
  if(current.target==='border')select(s.units.filter(u=>u.kind!=='worker'&&u.faction==='player'&&u.hp>0).map(u=>u.id));
  else if(worker)select([worker.id]);
  const target=guideTarget(s,current);if(target){const p=renderer.screen(target.x+(target.size?(target.size-1)/2:0),target.y+(target.size?(target.size-1)/2:0));renderer.camera.x+=renderer.w*.57-p.x;renderer.camera.y+=renderer.h*.46-p.y;}
  persist();
 });
 return {update,resume(){getState().tutorial??={};getState().tutorial.enabled=true;key='';update();persist();}};
}
