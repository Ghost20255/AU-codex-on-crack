import {createGame,makeBuilding,makeUnit,tick} from './sim.js';
import {claimConquest,plotInfo} from './territory.js';

export const RAID={id:'ashen-raid',name:'Ashen Supply Camp',description:'Raid an NPC kingdom for gold. Its land cannot be taken.',gold:120};
export function startBattle(home,{plot=null,unitIds=null}={}){
 if(home.battle)return {ok:false,message:'Finish your current battle first.'};
 const p=plot&&plotInfo(home,plot);
 if(plot&&(!p||p.owned||!p.adjacent||!p.hostile))return {ok:false,message:'Choose an adjacent enemy-controlled plot.'};
 const troops=home.units.filter(u=>u.faction==='player'&&u.kind!=='worker'&&u.hp>0&&(!unitIds||unitIds.includes(u.id)));
 if(!troops.length)return {ok:false,message:'Train at least one fighter before marching.'};
 const scene=createGame();scene.scene='battle';scene.units=[];scene.buildings=[];scene.nodes=[];scene.drops=[];scene.resources={gold:0,wood:0,food:0,stone:0,cash:0};scene.effects=[];scene.progression={xp:0};scene.time=0;scene.nextId=home.nextId+1000;
 const hall=makeBuilding(scene,'townhall',16,10,'enemy');hall.hp=hall.maxHp=260;
 const tower=makeBuilding(scene,'tower',18,15,'enemy');tower.hp=tower.maxHp=p?220:160;
 if(p)makeBuilding(scene,'wall',16,15,'enemy');
 for(const [x,y] of [[16,17],[18,18],...(p?[[20,16]]:[])])makeUnit(scene,'raider',x,y,'enemy');
 const origins=troops.map(u=>({id:u.id,x:u.x,y:u.y,kind:u.kind}));
 troops.forEach((u,i)=>scene.units.push({...structuredClone(u),x:10+i%4,y:18+Math.floor(i/4),home:{x:10+i%4,y:18+Math.floor(i/4)},path:[],task:null,attackTimer:0,progress:0}));
 home.battle={id:'battle-'+home.nextId++,kind:p?'conquest':'raid',plot:plot||null,name:p?p.name+' · '+plot:RAID.name,scene,deployed:troops.map(u=>u.id),origins,settled:false,outcome:null,report:null};
 return {ok:true,message:'Army deployed. Fallen troops are permanently lost.'};
}
export function battleOutcome(b){
 if(!b.scene.units.some(u=>u.faction==='player'&&u.hp>0))return 'defeat';
 if(!b.scene.units.some(u=>u.faction==='enemy'&&u.hp>0)&&!b.scene.buildings.some(x=>x.faction==='enemy'&&x.hp>0&&x.kind!=='wall'))return 'victory';
 if(b.scene.time>=180)return 'timeout';return null;
}
export function finishBattle(home,outcome){
 const b=home.battle;if(!b||b.settled)return b?.report||null;
 // A victory must follow actual combat; UI callers cannot claim a free conquest.
 const actual=battleOutcome(b);if(outcome==='victory'&&actual!=='victory')return null;
 if(!['victory','defeat','timeout','retreat'].includes(outcome))return null;
 const survivors=b.scene.units.filter(u=>u.faction==='player'&&u.hp>0&&b.deployed.includes(u.id));
 const alive=new Set(survivors.map(u=>u.id)),lost=b.deployed.filter(id=>!alive.has(id));
 const restored=survivors.map(u=>{const origin=b.origins.find(o=>o.id===u.id);return {...structuredClone(u),x:origin.x,y:origin.y,home:{x:origin.x,y:origin.y},path:[],task:null,attackTimer:0};});
 home.units=home.units.filter(u=>!b.deployed.includes(u.id)).concat(restored);
 const gold=Math.floor(b.scene.resources.gold)+(outcome==='victory'?(b.kind==='raid'?RAID.gold:90):0);
 home.resources.gold+=gold;home.progression.xp+=Math.floor(b.scene.progression.xp);
 const conquered=outcome==='victory'&&b.kind==='conquest'&&claimConquest(home,b.plot);
 // Complete old saved expeditions without leaving a duplicate home-map garrison.
 if(conquered){const camp=home.frontierCamps?.find(c=>c.plot===b.plot);if(camp){camp.resolved=true;home.units=home.units.filter(u=>!camp.defenders.includes(u.id));home.buildings=home.buildings.filter(x=>!camp.structures.includes(x.id));}}
 home.stats.raids=(home.stats.raids||0)+(outcome==='victory'&&b.kind==='raid'?1:0);
 home.stats.conquests=(home.stats.conquests||0)+(conquered?1:0);
 home.stats.casualties=(home.stats.casualties||0)+lost.length;
 home.nextId=Math.max(home.nextId,b.scene.nextId);
 const report={id:b.id,name:b.name,kind:b.kind,outcome,gold,xp:Math.floor(b.scene.progression.xp),survivors:survivors.length,lost:lost.length,lostUnits:lost.map(id=>({id,kind:home.battle.origins.find(o=>o.id===id)?.kind||'fighter'})),land:conquered?b.plot:null,time:Math.floor(b.scene.time)};
 home.reports.unshift(report);b.settled=true;b.outcome=outcome;b.report=report;return report;
}
export function advanceBattle(home,dt){const b=home.battle;if(!b||b.settled)return null;tick(b.scene,dt);const result=battleOutcome(b);return result?finishBattle(home,result):null;}
export function leaveBattle(home){if(!home.battle)return false;if(!home.battle.settled)finishBattle(home,'retreat');home.battle=null;return true;}
