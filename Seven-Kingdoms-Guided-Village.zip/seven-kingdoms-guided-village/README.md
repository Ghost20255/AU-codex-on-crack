# Seven Kingdoms — The Frontier (0.5.0)

An original browser strategy prototype centered on **build → produce → expand → train → raid/conquer → return**. Seven Kingdoms is a working title. No Social Empires code, art, sound, binaries or services are included.

## Play locally

Extract the project. With Node.js 22 or newer installed, run `npm start` in this folder and open `http://localhost:4173`. On Windows, `start-game.cmd` is a convenience launcher. Runtime has no third-party dependencies; `npm install` is unnecessary for playing. Windows itself has not been tested.

For browser-only access, the frontend can be served by a static web host; it uses relative module/asset paths and no backend API. The included Node server is another hosting option. Hosting does **not** turn this into multiplayer: progress remains in each browser's local storage. Changing origin, browser or device does not transfer progress. Save export is available, but there is not yet a save-import UI.

## A new kingdom

New games begin with **one Town Hall, two shieldbearers, and no villagers outside**. Recruit every worker from the Town Hall. Existing saves retain their people and buildings.

1. Follow the guided opening: select the Town Hall, recruit a villager, select them and move to the yellow circle.
2. Click the marked tree. After one six-second work cycle it disappears, drops its wood once, and the villager automatically moves to another reachable tree on owned land. Collect the bundles; Stop or another order cancels clearing.
3. Follow the guide to build a Farm and collect food, then a Cottage for population and a Barracks for troops.
4. Add a Royal Gold Mine, Stoneworks, Timber Yard or Farm. Select workers and click the production building, then collect its bundles.
5. Follow the sequential goals for one-time gold and XP. Level 2 unlocks ranged training and the Bolt Bastion; level 3 the Dawnguard Forge; level 4 the Cinderwing Roost.
6. Click FOR SALE signs directly to buy land. Defeat nearby enemy camps on this same map to conquer their plots. Campaign is a separate raid into another NPC kingdom.

## Land and combat rules

The world is 54 × 54 tiles, divided into 6 × 6 plots. Nine central plots begin owned. Only owned land can be built on or harvested; movement across the frontier is allowed. Coastal water stays unbuildable. New land keeps its trees and natural resources. No overview grid or separate View on map step is required.

- A peaceful adjacent plot costs **4,000 gold OR 20 cash**, deducted once. Prototype prices are configurable; they are not a claim about exact original-game balancing.
- Cash cannot be bought in this build, and new games start with zero cash. No payment integration or charge exists.
- Enemy-controlled frontier plots cannot be bought. Defeat their visible defenders and tower on the home map to own them permanently. Troops march there and home workers keep working. Click an enemy or use its CONQUER sign.
- NPC raids grant resources and XP, never ownership of the raided kingdom.
- Player-versus-player raids are not implemented. The agreed future rule is resource raiding without taking player-owned land.
- Expedition fighters must be selected before marching into a Campaign raid. Home production pauses during these away raids and ally visits; it continues during home-map border fights.
- In an away raid, defeat defending troops, the Town Hall and Watchtower. Walls can be destroyed but are not mandatory targets. Away raids have a three-minute simulation-time limit. Home-map camps stay engaged until defeated and do not use that expedition timer.
- **Fallen fighters and dragons are permanently lost.** Retreat returns only living troops, with their remaining health and earned gold, without a victory bonus or land. There is no resurrection or recovery timer.
- Results, casualties, survivors and rewards settle once and survive reload, including reloading during an expedition. Reports remain available from Reports.

## Shop and troop development

Economy, Offense, Defense, Legends and Train contain actual working options. Shieldbearers, Dawn Archers, Ember Lancers and young Cinderwings differ in health, damage, speed and range. Watchtowers and Bolt Bastions attack enemies; Stone Bulwarks block movement and can be destroyed.

Build a Dawnguard Forge at level 3, select a living shieldbearer, and promote them into a Dawnguard. Promotion preserves identity and health percentage. A ready Cinderwing Roost enables two paid training ranks for a living whelp. Training raises health and attack; death is still permanent. Whelps currently move along ground paths, rather than flying over obstacles.

Windrider cavalry and mobile siege engines remain clearly labeled, non-buyable previews. New structures and troops use simple Canvas symbols and shapes so the rules can be reviewed before final art.

## Controls, allies and saving

Click to select or command; drag to group-select; Shift-click adds to selection. Scroll or +/− zooms. Space + drag, middle-drag or right-drag pans. H returns home (offers retreat in battle); B opens the shop. Escape cancels placement. Settings pauses the game and provides save export and a confirmed reset with a browser-local backup.

Visit **Sahir Ibn Raydan** in **Areweyn Kingdom** through the neighbor card. This is an authored, read-only ally estate, not a live account. One welcome parcel plus five distinct village milestones can provide limited wood and food. Revisiting does not farm supplies. Existing patronage and saves are preserved. Earned rolls and AI-generated aid are not implemented.

When this update finds an existing save, it offers Continue or Start fresh guided village. The fresh option keeps the previous kingdom as a browser-local backup; it does not erase it. The tutorial can also be reopened from Controls.

Autosave runs every five simulation seconds and on page hide. No offline production, incoming attacks, family accounts, shared economy, cloud saves, live notifications, purchases or public multiplayer are connected.

## Verification and source

Run `npm ci` for the pinned development-only Playwright dependency, then `npm test` for deterministic simulation tests. With the server running and Chromium installed:

- `npm run test:frontier` — new opening, economy, shop, land, expedition, result/reload and responsive browser flows. Advanced scenarios use explicitly prepared kingdoms to avoid waiting for resource accumulation.
- `npm run test:browser` — established-village regression.
- `npm run test:ally` — Areweyn visits, gifts, blueprints and migration.
- `npm run test:storybook` — roster, shop, goals and responsive interface regression.

Tests use separate automation profiles, not personal saves. Set `CHROMIUM_PATH` or `GAME_TEST_URL` as needed. See `docs/VILLAGE-FLOW.md`, `docs/FRONTIER-SYSTEMS.md` and `docs/VALIDATION.md` for scope and results.

Rules live in `src/sim.js`, `catalog.js`, `territory.js`, `campaign.js`, `missions.js` and `progression.js`; Canvas rendering is separate in `render.js`. Multiplayer still requires a server-authoritative simulation, authentication, persistent database, offline-defense scheduling, notifications and multi-client testing. Local prototype validation is not online multiplayer validation.

## Uploaded model evaluation

Thirty uploaded OBJ models were imported and rendered successfully for review. They are light enough to be useful for future isometric sprites. The sampled Dummy FBX has no skeleton or animation. The materials need coloring; the evaluation preview uses an assigned palette. See `docs/VILLAGE-FLOW.md` for the actual inspection and source/license limitations. The gameplay runtime does not yet use these models.

## License

New game code and original project assets use MIT; see LICENSE and assets/README.md. The existing two illustrated atlases were generated for this project. Other terrain, structures, troop placeholders and effects use Canvas. No external media or AI service is called at runtime.
