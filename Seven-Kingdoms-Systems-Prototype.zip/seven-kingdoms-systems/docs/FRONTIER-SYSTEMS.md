# Frontier systems milestone — 0.4.0

## Accepted direction

Prioritize the game systems over final art. A fresh game has only a Town Hall and two starting soldiers; all villagers must be recruited. Old villages are retained. Peaceful land has alternative gold/cash prices; enemy territory requires conquest. Fighters and dragons are permanently lost on death. Future player raids take resources, never player territory. Family members should eventually play through a private hosted browser game.

## Implemented for local play

- Nine owned central plots in a 54 × 54 world; 6 × 6 plot grid, adjacent purchase validation, 4,000-gold/20-cash alternatives, ownership saving, persistent trees and resources, building-footprint and harvesting restrictions. Movement outside owned land is permitted. Water remains unbuildable.
- Gold, wood and stone production buildings alongside food farms; worker orders, bundles and one-time collection. Population and queued training reservations apply across all troop types.
- Sequential missions with one-time gold and XP rewards. Advanced building/training level requirements are enforced in simulation, not only the interface.
- Archers, lancers, promoted Dawnguards and ground-moving dragon whelps; distinct combat statistics, ranged attack, troop/building targets, enemy towers, destructible walls, stronger defensive bastions.
- Shieldbearer promotion preserves identity and wound percentage. Whelps have two training ranks. Training costs resources and requires a completed home building and appropriate kingdom level.
- Separate NPC raid and frontier-conquest battle maps. Choose expedition troops, command them with map selection/movement/attacks, destroy enemy troops and critical buildings, retreat or win, and return with surviving troops. Three-minute simulation limit. Home time pauses during expeditions; worker orders and queues are retained.
- Permanent casualty removal, no resurrection, partial earned loot on retreat/loss, victory bonus, conquest only on victory, once-only settlement, saved reports, active-battle reload, ended-battle reload and safe return.
- Existing creator ally, limited supply gifts, local save/reset/export, selection, camera controls, ten building upgrade levels and old-save migration remain supported. Older saves acquire ownership for existing buildings and connecting plots, rather than losing construction outside the initial frontier.
- Functional shop categories: Economy, Offense, Defense, Legends, Train and Land, plus All. Two future entries (cavalry and mobile siege) remain non-buyable and labeled as previews.

## Explicit limits

There is no family account or online multiplayer backend yet. NPC expeditions are not player attacks. Offline defense, incoming player-attack reports, invitations, assistance from real relatives, cloud saves, cross-device progress and payments require the next online milestone. Cash has a working spending rule but no purchase or earning mechanism in this prototype. Local browser state can be edited by the player; it cannot be trusted as an online economy.

Enemy maps are authored small encounters, not generated seven-kingdom campaigns. There is no large story campaign, cavalry, mobile siege, flying navigation, armor-type counter matrix, randomized rolls, AI-provider service, sound or final new-unit artwork. Surviving units retain wounds; there is no troop-healing mechanic. Production/battle timers pause when the page is hidden, in dialogs, during ally visits or away from home on an expedition.

## Online family milestone

Keep a persistent private group with one kingdom per member, invite-only accounts, validated server commands, database-backed inventory/queues/ownership/army and transactionally settled battle results. Resolve offline-defense battles against stored defenses on the server and notify the defender on login. Attacker and defender casualties must be settled together; retries must not duplicate resources or deaths. Player raiding never transfers player land. Add multi-client concurrency, reconnect, offline-defense and account-isolation tests before calling that milestone playable. Hosting and any payment services need separate deployment configuration; neither is activated by this build.
