# Current milestone: kingdom systems (0.4.0)

Completed validation passed **39 simulation tests and 38 browser scenarios** (11 established-village, 10 Areweyn, 7 interface, 10 new frontier scenarios). Completed browser runs reported no page errors or failed HTTP responses. Desktop, laptop and narrow-screen screenshots were reviewed.

The new browser flow starts from the real opening (Town Hall, two soldiers, zero workers), recruits the first worker, gathers and collects wood, constructs a house/gold mine/Barracks, and trains a soldier. Prepared kingdoms exercise gold/cash purchases, training archers and dragons, promotion, actual map-command raid victory, reward persistence after reload, an active conquest reload and retreat, reports, and laptop/narrow-screen controls. Prepared funds and unlocks are test fixtures, not a claim that a new player starts with those resources. Simulation tests separately fight a conquest through to victory and verify permanent ownership, casualties, wounds, dragon training/loss, guarded spending, producer output, footprint limits, old-save migration and once-only rewards.

Testing found and fixed a melee approach deadlock: fighters could choose a diagonal stopping tile just outside attack range. The regression suite now verifies closing that gap. Existing village scenarios deliberately use an established-village fixture to verify compatibility; they do not describe the changed new-game opening. Test profiles are isolated from personal saves.

See FRONTIER-SYSTEMS.md for this milestone’s rules and online-family limits. Real offline player attacks, purchases, multiplayer, cross-device saves, Windows, Firefox, Safari, physical touch devices and long-term balance have not been validated. This remains a local simulation. Historical milestone results follow.

# Historical milestone: brighter village and familiar interface (0.3.0)

The completed runs passed **21 simulation tests** and **28 browser scenarios**: 11 village, 10 ally visit, and 7 refreshed-interface scenarios. Both illustrated sprite atlases loaded successfully; there were no page or HTTP errors in the completed browser runs. Desktop, laptop and narrow viewport screenshots were reviewed. See `STORYBOOK-UPDATE.md` for the new scope and remaining limits. Historical milestone results follow.

# Historical milestone: Areweyn creator ally (0.2.0)

The updated game passed 16 simulation tests, the 11 original browser scenarios, and 10 new ally browser scenarios. See `AREWEYN-PROTOTYPE.md` for the new scope, supply limits, save compatibility, and the pending roll clarification. The results below describe the original village milestone and remain useful baseline evidence.

# Executed validation

The current slice was run with Node 24.19.0 and headless Chromium on Linux.

- **10 simulation tests passed:** recruitment and resource spending, concurrent population reservations, worker travel/gathering/collection, construction footprints and capacity, all ten upgrade levels, obstacle-aware pathfinding, building movement restrictions, combat ownership/victory, all four earned resource types, and in-progress save roundtrips with malformed-input rejection.
- **11 browser scenarios passed:** initial rendering, recruitment, tree work and collection, construction, upgrade and relocation, Barracks training and drag selection, troop movement and defeating all three raiders, camera controls, paused settings/export, saved-village restoration, and narrow viewport controls.
- Browser monitoring found **no page errors or failed HTTP responses** in the completed run.
- Screenshots were reviewed. A narrow-screen build-palette overlap was fixed, then the simulation and complete browser checks were rerun successfully.
- A stuck recruitment spawn was found by simulation testing and corrected before the completed run.
- `npm ci` succeeded with the frozen lockfile. Runtime uses only Node built-ins and browser APIs.
- The uploaded reference executable's SHA-256 was checked again after development and was unchanged. Neither existing repository acquired tracked changes.

Machine-readable browser results are in `artifacts/browser-results.json`; simulation output is in `artifacts/simulation-results.txt`. Screenshots show the actual running game, not design mockups. Test profiles are separate from personal browser profiles.

## Limits

The Windows convenience launcher has not been run on Windows. Firefox, Safari, actual touchscreen devices, and long-term balance have not been validated. The browser saves locally; there is no cloud account, multiplayer, server-authoritative economy or offline production. Original-game client playback and missing game-data files remain unverified. Conquest, dragons, cavalry, ranged armies and the wider seven-kingdom map are future work, as detailed in the roadmap.
