# Areweyn Kingdom — creator-ally visit prototype (0.2.0)

The user's creator character is **Sahir Ibn Raydan**, ruler of **Areweyn Kingdom**.

## What to try

1. Start the existing game with `npm start` or the included Windows launcher.
2. Click Sahir's neighbor card at the lower left.
3. Explore the developed kingdom; click the keep, other buildings, and guards to inspect them.
4. Collect the welcome parcel: 25 wood and 20 food. The parcel can also be collected on the map.
5. Open Blueprints. Village, Military, and Legends show original illustrations and descriptions. Playable buildings have normal costs and a Build in your village action. Future entries are clearly marked previews and cannot be purchased or unlocked yet.
6. Return home. Complete a distinct village goal to earn another parcel; reopening the visit repeatedly does not create free resources.

Your own village pauses while visiting. Royal buildings and units are an independent authored showcase; visitors cannot recruit, harvest, upgrade, move, or remove them. The home village retains its buildings, army, resources, queues and gathering orders. Reload starts at home, preserving visit/gift metadata and village progress.

## Prototype balancing

There is one welcome parcel plus one for each of five milestones: recruit a villager, personally gather 36 wood, finish a new cottage, train a shieldbearer, and finish an upgrade. Repeating a milestone does not award another parcel. Gifted wood does not count toward the gathering objective. This makes the visit helpful without replacing the village economy. Numbers and milestones are configurable in `src/realm.js`.

## Not yet decided or implemented

The user has not yet clarified whether an earned roll should produce a friendly reinforcement army or an enemy encounter. No roll, randomized army, aid request, AI-provider integration, or cash purchase is implemented in this milestone. Do not present the showcase guards as troops that can be taken home. The ally is single-player game content, not a live creator account or a multiplayer service. Future blueprint cards are concept previews and do not implement those future units/buildings.

## Executed checks

- **16 simulation tests passed**, including the original ten gameplay tests and six visit/reward/isolation/save-compatibility tests.
- **11 original browser scenarios passed** for the complete village-to-combat flow, save restoration, camera/settings and narrow-screen controls.
- **10 new ally browser scenarios passed** for visits, home pausing, limited gifts, read-only inspection, blueprint categories, normal construction from a blueprint, milestone resupply, save restoration and old-save migration, narrow-screen navigation, and laptop-height layout.
- Completed browser runs reported no page or HTTP errors. Screenshots were reviewed. A narrow-screen overlap was found and fixed before the completed ally browser run.

Test reports: `artifacts/simulation-results.txt`, `artifacts/browser-results.json`, and `artifacts/ally-browser-results.json`. Tests use isolated browser profiles and do not erase personal browser saves. Windows, Safari and real touchscreen devices remain unverified. The Windows launcher and Node server are unchanged from the previous slice.

The previous game download remains available separately. Existing original-game uploads were not changed or incorporated into the new game's assets.
