# Brighter village and familiar interface — 0.3.0

User direction: bring both visuals and gameplay closer to the supplied Social Empires recording, starting with the village and interface. The new game retains its own artwork, characters, names and economy.

## What changed

- Original illustrated building sprites and four character poses per villager, shieldbearer and raider; brighter terrain, subtle environmental motion, larger readable units, and visible selection/work/combat feedback.
- Warm framed resource counters, an XP/level indicator, a full-width compact contextual bar, a persistent selectable unit roster, and a horizontal home/neighbor strip.
- Illustrated construction shop with All, Village, Military and Legends categories. Available buildings use normal placement and costs. Future entries are clearly labeled previews and cannot be bought or unlocked in this prototype.
- Clickable goal instructions with shortcuts to the Town Hall, workers, construction shop and Barracks.
- Configurable XP for actual gathering, completed recruitment/training, construction/upgrades and enemy defeats. Gifts, queueing work, moving buildings, and collecting the same bundle do not generate extra XP. Levels currently show progress rather than unlocking additional unimplemented systems.
- Group movement uses distinct formation destinations on clear ground. Attack targeting prioritizes a valid enemy when a selected army and friendly sprites overlap it. Illustrated building hit detection ignores transparent portions of the artwork, making ground commands more predictable.
- Areweyn Kingdom, Sahir Ibn Raydan, limited supply gifts, safe return-home behavior and previous village saves are preserved. Earlier saves receive an XP field without resetting village state.
- Asset/module URLs are relative so the static frontend can be placed beneath a hosting subdirectory. The existing Node server and Windows launcher remain unchanged.

## Validation

The current completed results are retained in artifacts/: simulation-results.txt, browser-results.json, ally-browser-results.json, and storybook-browser-results.json. Screenshots show actual running scenes. The validation report is updated after the final runs.

Browser testing uses isolated profiles and does not erase personal saves. Original Social Empires files, uploaded footage, old game downloads, and the existing repositories' main branches are not modified or copied into the new game's artwork.

## Limits

This is a closer first pass at the village experience, not a complete recreation. Most advanced troop types, territorial expansion/conquest, dragons, full story chapters and real multiplayer remain future work. Roll/aid mechanics are still awaiting clarification from the earlier discussion. Future catalog illustrations are provisional. Windows and real touch devices remain unverified; actual browser interaction tests run in Chromium on Linux at desktop, laptop and narrow viewport sizes. There is no public Codex preview in this session; the tested GitHub ZIP is the delivery route.
