import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,makeUnit,makeBuilding,command,recruit,construct,promoteUnit,canPlace,blocked,pathfind,tick,saveGame,loadGame,collect} from '../src/sim.js';
import {purchaseLand,ensureTerritory,ownsTile,frontierPlots} from '../src/territory.js';
import {startBattle,finishBattle,advanceBattle,leaveBattle} from '../src/campaign.js';
import {claimMissionRewards} from '../src/missions.js';
const advance=(s,t)=>{for(let i=0;i<t*20;i++)tick(s,.05);};
const wealthy=()=>{const s=createGame();s.resources={gold:20000,wood:20000,stone:20000,food:20000,cash:40};s.progression.xp=200;return s;};
function marchToVictory(s,options){
 assert.equal(startBattle(s,options).ok,true);const b=s.battle;
 for(let t=0;t<3500&&!b.settled;t++){
  const troops=b.scene.units.filter(u=>u.faction==='player'&&u.hp>0),enemy=b.scene.units.find(u=>u.faction==='enemy'&&u.hp>0)||b.scene.buildings.find(b=>b.faction==='enemy'&&b.hp>0&&b.kind!=='wall');
  if(enemy&&t%10===0)command(b.scene,troops.map(u=>u.id),'attack',enemy.id);advanceBattle(s,.1);
 }
 return b.report;
}
test('new kingdoms start with only a Town Hall and two soldiers; workers require paid recruitment',()=>{
 const s=createGame();assert.deepEqual(s.buildings.map(b=>b.kind),['townhall']);assert.deepEqual(s.units.map(u=>u.kind),['soldier','soldier']);
 assert.equal(recruit(s,s.buildings[0].id,'worker').ok,true);assert.equal(s.units.some(u=>u.kind==='worker'),false);advance(s,3.2);assert.equal(s.units.filter(u=>u.kind==='worker').length,1);assert.equal(s.stats.recruited,1);
});
test('gold and cash buy adjacent land once, preserve obstacles and survive reloading',()=>{
 for(const currency of ['gold','cash']){const s=wealthy(),before=s.resources[currency],trees=structuredClone(s.nodes);assert.equal(purchaseLand(s,'4,1',currency).ok,true);assert.equal(s.resources[currency],before-(currency==='gold'?4000:20));assert.equal(purchaseLand(s,'4,1',currency).ok,false);assert.deepEqual(s.nodes,trees);assert.equal(ownsTile(loadGame(saveGame(s)),26,8),true);}
});
test('invalid, distant, enemy and unaffordable land purchases never spend resources',()=>{
 const s=createGame(),before=structuredClone(s.resources);for(const [id,currency]of [['4,1','gold'],['4,1','cash'],['4,2','gold'],['8,8','gold'],['bad','gold'],['4,1','wood']])assert.equal(purchaseLand(s,id,currency).ok,false);assert.deepEqual(s.resources,before);
});
test('building footprints and gathering respect purchased boundaries; buying does not clear trees',()=>{
 const s=wealthy();assert.equal(canPlace(s,'house',23,11),false);const worker=makeUnit(s,'worker',22,10),tree=s.nodes.find(n=>n.x===26&&n.y===8);assert.equal(command(s,[worker.id],'gather',tree.id),0);
 purchaseLand(s,'4,1');assert.equal(canPlace(s,'house',24,8),true);assert.equal(command(s,[worker.id],'gather',tree.id),1);assert.equal(canPlace(s,'house',26,8),false);assert.ok(tree.amount>0);
});
test('legacy territory migration preserves old construction and connects it back to home',()=>{
 const s=wealthy();makeBuilding(s,'house',31,31);delete s.territory;delete s.opening;const restored=loadGame(saveGame(s));assert.ok(restored);assert.equal(ownsTile(restored,32,32),true);assert.equal(ownsTile(restored,25,25),true);assert.equal(restored.buildings.at(-1).x,31);
});
test('level gates and training prerequisites apply to real construction and recruitment',()=>{
 const s=createGame();assert.equal(construct(s,'archery',13,21).ok,false);s.progression.xp=30;assert.equal(construct(s,'archery',13,21).ok,true);const b=s.buildings.at(-1);assert.equal(recruit(s,b.id,'archer').ok,false);advance(s,9.2);assert.equal(recruit(s,b.id,'archer').ok,true);advance(s,7.2);assert.ok(s.units.some(u=>u.kind==='archer'));assert.equal(recruit(s,b.id,'dragon').ok,false);
});
test('mine, stoneworks and timber yard produce their actual renewable resources through workers',()=>{
 for(const [kind,resource]of [['mine','gold'],['quarry','stone'],['lumber','wood']]){const s=wealthy(),b=makeBuilding(s,kind,13,21),u=makeUnit(s,'worker',12,21);assert.equal(command(s,[u.id],'gather',b.id),1);advance(s,12);const pile=s.drops.find(d=>d.resource===resource);assert.ok(pile);const before=s.resources[resource];collect(s,pile.id);assert.ok(s.resources[resource]>before);assert.equal(collect(s,pile.id),false);}
});
test('promotion changes the same soldier, costs resources once and preserves wounds',()=>{
 const s=wealthy(),u=s.units[0],id=u.id;u.hp=70;assert.equal(promoteUnit(s,id).ok,false);makeBuilding(s,'forge',13,21);const before=s.resources.gold;assert.equal(promoteUnit(s,id).ok,true);assert.equal(u.id,id);assert.equal(u.kind,'veteran');assert.equal(u.hp,120);assert.equal(s.resources.gold,before-100);assert.equal(promoteUnit(s,id).ok,false);
});
test('dragon training strengthens living whelps only; dead dragons never return',()=>{
 const s=wealthy();makeBuilding(s,'nest',13,21);const u=makeUnit(s,'dragon',13,20);assert.equal(promoteUnit(s,u.id).ok,true);assert.equal(u.maxHp,370);assert.equal(promoteUnit(s,u.id).ok,true);assert.equal(u.maxHp,450);assert.equal(promoteUnit(s,u.id).ok,false);u.hp=0;u.dead=1;advance(s,2);assert.equal(s.units.some(x=>x.id===u.id),false);assert.equal(promoteUnit(s,u.id).ok,false);assert.equal(loadGame(saveGame(s)).units.some(x=>x.id===u.id),false);
});
test('ranged fighters hit at range, and towers target the opposing army',()=>{
 const s=wealthy();s.nodes=[];s.units=[];const archer=makeUnit(s,'archer',12,18),enemy=makeUnit(s,'raider',16,18,'enemy');command(s,[archer.id],'attack',enemy.id);tick(s,.1);assert.equal(enemy.hp,93);assert.equal(archer.x,12);
 const tower=makeBuilding(s,'ballista',20,18,'enemy'),before=archer.hp;archer.x=19;archer.y=18;tick(s,.1);assert.ok(archer.hp<before);assert.equal(tower.hp,tower.maxHp);
});
test('walls block paths until destroyed and troops can attack enemy buildings',()=>{
 const s=wealthy();s.nodes=[];s.units=[];const wall=makeBuilding(s,'wall',13,18,'enemy'),u=makeUnit(s,'veteran',12,18);wall.hp=30;assert.equal(blocked(s,13,18),true);assert.equal(command(s,[u.id],'attack',wall.id),1);tick(s,.1);assert.equal(wall.hp,0);assert.equal(blocked(s,13,18),false);assert.ok(pathfind(s,u,{x:13,y:18}));
});
test('melee troops close the final diagonal gap instead of waiting just outside attack range',()=>{
 const s=wealthy();s.units=[];s.nodes=[];const u=makeUnit(s,'soldier',22,15),enemy=makeUnit(s,'raider',23,14,'enemy');
 assert.equal(command(s,[u.id],'attack',enemy.id),1);advance(s,12);assert.equal(s.units.some(x=>x.id===enemy.id&&x.hp>0),false);assert.ok(u.hp>0);
});
test('battle deployment rejects empty armies, duplicate departures and fake victory',()=>{
 const s=wealthy();assert.equal(startBattle(s,{unitIds:[]}).ok,false);assert.equal(startBattle(s).ok,true);assert.equal(startBattle(s).ok,false);assert.equal(purchaseLand(s,'4,1').ok,false);assert.equal(finishBattle(s,'victory'),null);assert.equal(s.reports.length,0);
});
test('an actual raid defeats units and buildings, returns survivors and awards loot once without taking land',()=>{
 const s=wealthy(),land=[...s.territory.owned],before=s.resources.gold;for(let i=0;i<4;i++)makeUnit(s,'veteran',12+i,18);const report=marchToVictory(s);assert.equal(report.outcome,'victory');assert.ok(report.gold>=120);assert.equal(s.resources.gold,before+report.gold);assert.deepEqual(s.territory.owned,land);const after=s.resources.gold;finishBattle(s,'victory');assert.equal(s.resources.gold,after);assert.equal(s.reports.length,1);assert.equal(s.units.filter(u=>u.faction==='player'&&u.kind!=='worker').length,report.survivors);leaveBattle(s);assert.equal(s.battle,null);
});
test('winning an actual conquest permanently adds just the enemy plot',()=>{
 const s=wealthy();for(let i=0;i<5;i++)makeUnit(s,'veteran',12+i,18);const before=s.territory.owned.length,report=marchToVictory(s,{plot:'4,2'});assert.equal(report.outcome,'victory');assert.equal(report.land,'4,2');assert.equal(s.territory.owned.length,before+1);assert.equal(s.territory.conquered.includes('4,2'),true);assert.equal(startBattle(s,{plot:'4,2'}).ok,false);const restored=loadGame(saveGame(s));assert.equal(restored.territory.owned.includes('4,2'),true);assert.equal(restored.reports.length,1);
});
test('death, retreat and timeout never claim land; casualty settlement and loot cannot be repeated',()=>{
 for(const outcome of ['defeat','retreat','timeout']){const s=wealthy();startBattle(s,{plot:'4,2'});s.battle.scene.units.find(u=>u.faction==='player').hp=0;s.battle.scene.resources.gold=20;const before=s.resources.gold,report=finishBattle(s,outcome);assert.equal(report.lost,1);assert.equal(report.survivors,1);assert.equal(s.units.filter(u=>u.faction==='player').length,1);assert.equal(s.resources.gold,before+20);assert.equal(s.territory.owned.includes('4,2'),false);finishBattle(s,outcome);assert.equal(s.resources.gold,before+20);assert.equal(s.reports.length,1);}
});
test('saving during a battle preserves casualties, deployment and reward settlement across reloads',()=>{
 let s=wealthy();startBattle(s);const lost=s.battle.scene.units.find(u=>u.faction==='player');lost.hp=0;lost.dead=1;const id=lost.id;s=loadGame(saveGame(s));assert.ok(s.battle);assert.equal(s.battle.scene.units.find(u=>u.id===id).hp,0);finishBattle(s,'retreat');const gold=s.resources.gold;s=loadGame(saveGame(s));finishBattle(s,'retreat');assert.equal(s.resources.gold,gold);assert.equal(s.reports.length,1);assert.equal(s.units.some(u=>u.id===id),false);
});
test('sequential mission rewards survive reload and cannot be farmed by revisiting or repeated checks',()=>{
 let s=createGame();s.stats.recruited=1;const before=s.resources.gold;assert.equal(claimMissionRewards(s).length,1);assert.equal(s.resources.gold,before+25);assert.equal(s.progression.xp,10);assert.equal(claimMissionRewards(s).length,0);s=loadGame(saveGame(s));assert.equal(claimMissionRewards(s).length,0);s.stats.wood=36;assert.equal(claimMissionRewards(s).length,1);assert.equal(s.resources.gold,before+50);
});
