// Local prototype prices are balance values, not verified reference-game prices.
export const WORLD_SIZE=54,PLOT_SIZE=6;
export const LAND_RULES={gold:4000,cash:20};
export const plotId=(x,y)=>`${Math.floor(x/PLOT_SIZE)},${Math.floor(y/PLOT_SIZE)}`;
const initial=()=>Array.from({length:9},(_,i)=>`${1+i%3},${1+Math.floor(i/3)}`);
export function ensureTerritory(s){
 if(!s.territory){
  const owned=new Set(initial());
  // Old saves retain every building footprint and its route back to the village.
  for(const b of s.buildings||[])for(let x=b.x;x<b.x+b.size;x++)for(let y=b.y;y<b.y+b.size;y++){
   const gx=Math.floor(x/6),gy=Math.floor(y/6);if(gx<0||gy<0||gx>8||gy>8)continue;
   for(let a=Math.min(2,gx);a<=Math.max(2,gx);a++)for(let c=Math.min(2,gy);c<=Math.max(2,gy);c++)owned.add(`${a},${c}`);
  }
  s.territory={owned:[...owned],conquered:[]};
 }
 return s.territory;
}
export function ownsTile(s,x,y){return s.scene==='battle'||s.scene==='founder'||ensureTerritory(s).owned.includes(plotId(x,y));}
export function plotInfo(s,id){
 const match=/^([0-8]),([0-8])$/.exec(id);if(!match)return null;
 const gx=Number(match[1]),gy=Number(match[2]),t=ensureTerritory(s),owned=t.owned.includes(id);
 const adjacent=[[gx-1,gy],[gx+1,gy],[gx,gy-1],[gx,gy+1]].some(p=>t.owned.includes(p.join(',')));
 const hostile=(gx===4&&gy===2)||(gx===2&&gy===4)||(gx+gy>6&&(gx*3+gy)%4===0);
 return {id,gx,gy,x:gx*6,y:gy*6,size:6,owned,adjacent,hostile,name:hostile?'Ashen stronghold':(gx+gy)%2?'Oldwood frontier':'Open borderland'};
}
export function frontierPlots(s){
 const plots=[];for(let gx=0;gx<9;gx++)for(let gy=0;gy<9;gy++){const p=plotInfo(s,`${gx},${gy}`);if(!p.owned&&p.adjacent)plots.push(p);}return plots;
}
export function purchaseLand(s,id,currency='gold'){
 const p=plotInfo(s,id);if(s.battle)return {ok:false,message:'Return home before expanding.'};
 if(!p||p.owned||!p.adjacent)return {ok:false,message:'Choose an unowned plot touching your kingdom.'};
 if(p.hostile)return {ok:false,message:'Defeat this stronghold to claim its land.'};
 const cost=LAND_RULES[currency];if(!cost||!Number.isFinite(s.resources[currency])||s.resources[currency]<cost)return {ok:false,message:'Not enough '+currency+'.'};
 s.resources[currency]-=cost;ensureTerritory(s).owned.push(id);s.stats.landBought=(s.stats.landBought||0)+1;
 return {ok:true,message:'Land purchased. Trees remain until your villagers clear them.'};
}
export function claimConquest(s,id){const p=plotInfo(s,id);if(!p||p.owned||!p.adjacent||!p.hostile)return false;const t=ensureTerritory(s);t.owned.push(id);t.conquered.push(id);return true;}
