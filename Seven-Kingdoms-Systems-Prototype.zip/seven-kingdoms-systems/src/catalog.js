export const UNITS={
 worker:{name:'Villager',hp:70,damage:0,range:0,speed:1.8,cost:{food:25,gold:15},time:3,building:'townhall',level:1,description:'Gather wood, stone, gold and food.'},
 soldier:{name:'Shieldbearer',hp:140,damage:23,range:1.35,speed:2.25,cost:{food:30,gold:35},time:5,building:'barracks',level:1,description:'Dependable close-combat infantry.'},
 archer:{name:'Dawn Archer',hp:85,damage:17,range:5,speed:2.5,cost:{wood:25,food:35,gold:50},time:7,building:'archery',level:2,description:'Ranged support. Keep shieldbearers between archers and enemies.'},
 pikeman:{name:'Ember Lancer',hp:190,damage:31,range:1.9,speed:1.9,cost:{food:45,stone:20,gold:70},time:8,building:'barracks',level:2,description:'A sturdy spear fighter with a longer melee reach.'},
 veteran:{name:'Dawnguard',hp:240,damage:39,range:1.5,speed:2.35,level:3,description:'A promoted shieldbearer. Same soldier, stronger armor and attack.'},
 dragon:{name:'Cinderwing Whelp',hp:290,damage:43,range:4,speed:2.7,cost:{food:140,gold:220,stone:40},time:16,building:'nest',level:4,description:'A young ground-bound dragon with ranged fire. Death is permanent.'},
 raider:{name:'Ashen Raider',hp:110,damage:12,range:1.35,speed:2.25,level:1,description:'An enemy fighter.'}
};
export const PROMOTION_COST={gold:100,food:50,stone:30};
export const DRAGON_TRAINING_COST={gold:140,food:100};
export const SHOP_CATEGORIES=[['all','All'],['village','Economy'],['military','Offense'],['defense','Defense'],['legend','Legends'],['troops','Train'],['land','Land']];
