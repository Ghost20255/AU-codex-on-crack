import {frontierPlots,plotInfo,ensureTerritory,purchaseLand,LAND_RULES} from './territory.js';
import {RAID,startBattle,advanceBattle,finishBattle,leaveBattle} from './campaign.js';
import {UNITS} from './catalog.js';
const $=id=>document.getElementById(id);
const escape=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function createFrontierUI({getState,ui,renderer,refresh,persist,notify,returnAlly,closeShop}){
 let tab='land',chosen=null,lastReport=null,cameraBefore=null;
 const dialog=$('dialog'),content=()=>dialog.querySelector('.modal-content');
 function open(mode='land',id=null){if(getState().battle&&!getState().battle.settled&&mode!=='retreat'){notify('Finish the battle or retreat before opening kingdom menus.');return;}
  tab=mode;if(id)chosen=id;closeShop();ui.paused=true;dialog.classList.add('frontier-dialog');render();if(!dialog.open)dialog.showModal();
 }
 function render(){
  const s=getState();let body='';
  if(tab==='land'){
   chosen=chosen||frontierPlots(s).find(p=>!p.hostile)?.id;const selected=plotInfo(s,chosen||'4,1'),owned=ensureTerritory(s).owned;
   const grid=[];for(let gy=0;gy<9;gy++)for(let gx=0;gx<9;gx++){const p=plotInfo(s,`${gx},${gy}`);grid.push(`<button class="land-cell ${p.owned?'owned':p.hostile?'hostile':'unowned'} ${p.id===chosen?'chosen':''}" data-plot="${p.id}" ${!p.owned&&!p.adjacent?'disabled':''} title="Plot ${p.id}: ${p.owned?'owned':p.hostile?'enemy stronghold':p.adjacent?'purchasable':'expand toward this plot'}" aria-label="Plot ${p.id} ${p.owned?'owned':p.hostile?'enemy':p.adjacent?'purchasable':'distant'}">${p.owned?'⚑':p.hostile?'⚔':'▧'}</button>`);}
   body=`<h2>From village to kingdom</h2><p>${owned.length} plots owned · Plots cover 6 × 6 tiles. Trees stay in place; coastal water stays unbuildable.</p><div class="land-layout"><div><div class="land-grid">${grid.join('')}</div><p class="legend">⚑ Owned · ▧ Gold or cash · ⚔ Enemy territory</p></div><section class="plot-detail"><span class="eyebrow">PLOT ${escape(chosen||'')}</span><h3>${escape(selected.name)}</h3><p>${selected.owned?'This land belongs to your kingdom.':selected.hostile?'Defeat the Ashen defenders to permanently claim this plot.':selected.adjacent?'Buy this neighboring land, then clear trees and build on it.':'Expand toward this plot first.'}</p><p><strong>${Math.floor(s.resources.gold).toLocaleString()} gold · ${s.resources.cash} cash available</strong></p>${!selected.owned&&selected.adjacent?(selected.hostile?'<button class="action primary" data-frontier="conquer">Prepare conquest</button>':`<button class="action primary" data-buy-land="gold" ${s.resources.gold<LAND_RULES.gold?'disabled':''}>Buy · 4,000 gold</button><button class="action" data-buy-land="cash" ${s.resources.cash<LAND_RULES.cash?'disabled':''}>Buy · 20 cash</button>`):''}<button class="action" data-frontier="view-plot">View on the map</button><p class="small-note">Cash purchases are not connected in this prototype. No payment is charged. Gold is earned by gathering, production, missions and raids.</p></section></div>`;
  }else if(tab==='campaign'||tab==='conquest'){
   const troops=s.units.filter(u=>u.faction==='player'&&u.kind!=='worker'&&u.hp>0);
   body=`<h2>${tab==='conquest'?'Claim the Ashen frontier':RAID.name}</h2><p>${tab==='conquest'?'Victory adds plot '+escape(chosen)+' to your kingdom.':RAID.description} Defeat all defending troops, the Town Hall and the Watchtower. Retreat or return when finished.</p><p class="battle-warning">Fallen troops and dragons are permanently lost. Survivors return with their remaining health.</p><h3>Choose your expedition</h3><div class="deployment">${troops.map(u=>`<label><input type="checkbox" data-deploy="${u.id}" checked> ${UNITS[u.kind].name} · ${Math.ceil(u.hp)} / ${u.maxHp} HP</label>`).join('')||'<p>No fighters ready. Train an army at home first.</p>'}</div><button class="action primary" data-frontier="march" ${!troops.length?'disabled':''}>March to battle</button><p class="small-note">NPC battle · Three-minute limit · No player territory is at risk. Family accounts and offline player raids require the online milestone.</p>`;
  }else if(tab==='retreat')body='<h2>Retreat from battle?</h2><p>Living troops return with remaining health. Fallen troops stay lost. You keep gold earned so far, but receive no victory bonus or land.</p><button class="action danger" data-frontier="retreat">Retreat and return home</button><button class="action" data-frontier="close">Keep fighting</button>';
  else if(tab==='result')body=reportHTML(s.battle.report)+'<button class="action primary" data-frontier="return">Return to my kingdom</button>';
  else body=`<h2>Battle reports</h2><p>Reports are saved with this browser’s kingdom. These are your NPC expeditions; online defense notifications are not connected yet.</p>${s.reports.length?s.reports.map(reportHTML).join('<hr>'):'<p>No battles recorded. Train an army and open Campaign to begin.</p>'}`;
  content().innerHTML=`<button class="close" data-frontier="close" aria-label="Close kingdom panel">×</button><span class="eyebrow">SEVEN KINGDOMS · THE FRONTIER</span>${body}`;
 }
 function reportHTML(r){return `<article class="battle-report"><h2>${r.outcome==='victory'?'Victory':r.outcome==='retreat'?'Retreated':r.outcome==='timeout'?'Time expired':'Defeat'}</h2><h3>${escape(r.name)}</h3><div class="report-numbers"><span><b>${r.survivors}</b> survivors</span><span><b>${r.lost}</b> permanently lost</span><span><b>+${r.gold}</b> gold</span><span><b>+${r.xp}</b> XP</span></div>${r.land?'<p>Plot '+escape(r.land)+' is now part of your kingdom.</p>':''}<p>Rewards and survivors have been saved. Defeated troops cannot be revived.</p></article>`;}
 function home(){const b=getState().battle;if(!b)return false;if(!b.settled){open('retreat');return true;}dialog.close();leaveBattle(getState());Object.assign(renderer.camera,cameraBefore||{});ui.selected.clear();ui.placement=null;document.body.classList.remove('in-battle');refresh();persist();return true;}
 function step(dt){const report=advanceBattle(getState(),dt);if(report){persist();notify('Battle ended. '+report.lost+' troops permanently lost.');open('result');}update();}
 function update(){const b=getState().battle;$('battle-banner').hidden=!b;document.body.classList.toggle('in-battle',!!b);$('neighbor-founder').disabled=!!b;$('build-toggle').disabled=!!b;
  if(b){const alive=b.scene.units.filter(u=>u.faction==='player'&&u.hp>0).length,targets=b.scene.units.filter(u=>u.faction==='enemy'&&u.hp>0).length+b.scene.buildings.filter(e=>e.faction==='enemy'&&e.hp>0&&e.kind!=='wall').length;const text=`${b.name} · ${alive} troops · ${targets} targets · ${Math.max(0,180-Math.floor(b.scene.time))}s`;
   if($('battle-banner').textContent!==text)$('battle-banner').textContent=text;
  }else if(!document.body.classList.contains('visiting'))$('build-toggle').disabled=false;
  if(b?.settled&&lastReport!==b.id){lastReport=b.id;if(!dialog.open)open('result');}
 }
 document.addEventListener('click',e=>{
  const plot=e.target.closest('[data-plot]');if(plot){chosen=plot.dataset.plot;render();}
  const buy=e.target.closest('[data-buy-land]');if(buy&&!buy.disabled){const r=purchaseLand(getState(),chosen,buy.dataset.buyLand);notify(r.message);persist();refresh();render();}
  const button=e.target.closest('[data-frontier]');if(!button)return;const a=button.dataset.frontier;
  if(a==='close')dialog.close();if(a==='conquer')open('conquest');
  if(a==='view-plot'){const p=plotInfo(getState(),chosen);dialog.close();const q=renderer.screen(p.x+2.5,p.y+2.5);renderer.camera.x+=renderer.w*.57-q.x;renderer.camera.y+=renderer.h*.45-q.y;ui.selected.clear();notify('Click the frontier sign or open Land to expand here.');}
  if(a==='march'){
   const unitIds=[...content().querySelectorAll('[data-deploy]:checked')].map(x=>x.dataset.deploy),r=startBattle(getState(),{plot:tab==='conquest'?chosen:null,unitIds});notify(r.message);
   if(r.ok){returnAlly();dialog.close();cameraBefore={...renderer.camera};renderer.home();ui.selected=new Set(unitIds);ui.placement=null;lastReport=null;refresh();persist();}
  }
  if(a==='retreat'){finishBattle(getState(),'retreat');home();}if(a==='return')home();
 });
 for(const [id,mode]of [['land-toggle','land'],['campaign-toggle','campaign'],['reports-toggle','reports']])$(id).onclick=()=>{if(getState().battle){notify('Return home to open this menu.');return;}returnAlly();open(mode);};
 $('dialog').addEventListener('close',()=>dialog.classList.remove('frontier-dialog'));
 $('neighbor-home').addEventListener('click',e=>{if(getState().battle){e.stopImmediatePropagation();home();}},true);
 return {open,home,step,update,get scene(){return getState().battle?.scene||null;}};
}
