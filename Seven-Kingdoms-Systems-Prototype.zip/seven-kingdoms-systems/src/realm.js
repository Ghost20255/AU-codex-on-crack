// The creator's authored showcase kingdom. All visits and rewards run locally.
export const FOUNDER={ruler:'Sahir Ibn Raydan',kingdom:'Areweyn Kingdom',motto:'Build a home worth standing beside.',banner:'The first ally',description:'An old kingdom that remembers what it means to start with nothing.'};
export const PATRON_RULES={supplies:{wood:25,food:20},maxSupplies:6};
export const VILLAGE_MILESTONES=[
 {id:'recruit',label:'Welcome a villager',done:s=>s.stats.recruited>0},
 {id:'gather',label:'Gather 36 wood yourself',done:s=>s.stats.wood>=36},
 {id:'home',label:'Complete a new cottage',done:s=>s.stats.built>0&&s.buildings.filter(b=>b.kind==='house'&&!b.remaining).length>1},
 {id:'army',label:'Train a shieldbearer',done:s=>s.stats.trained>0},
 {id:'upgrade',label:'Finish an upgrade',done:s=>s.stats.upgrades>0}
];
export function ensurePatronage(s){
 if(!s.patronage||typeof s.patronage!=='object')s.patronage={visited:false,suppliesClaimed:0};
 if(typeof s.patronage.visited!=='boolean')s.patronage.visited=false;
 if(!Number.isInteger(s.patronage.suppliesClaimed)||s.patronage.suppliesClaimed<0||s.patronage.suppliesClaimed>PATRON_RULES.maxSupplies)s.patronage.suppliesClaimed=0;
 return s.patronage;
}
export function supplyAllowance(s){return Math.min(PATRON_RULES.maxSupplies,1+VILLAGE_MILESTONES.filter(m=>m.done(s)).length);}
export function supplyParcels(s){return Math.max(0,supplyAllowance(s)-ensurePatronage(s).suppliesClaimed);}
export function visitFounder(s){ensurePatronage(s).visited=true;return {ok:true,message:'Welcome to '+FOUNDER.kingdom+'.'};}
export function claimSupplies(s){
 const p=ensurePatronage(s);
 if(!p.visited)return {ok:false,message:'Visit your ally to collect a supply parcel.'};
 if(supplyParcels(s)<1)return {ok:false,message:'Complete another village goal to earn a new supply parcel.'};
 for(const[k,n]of Object.entries(PATRON_RULES.supplies))s.resources[k]+=n;
 p.suppliesClaimed++;return {ok:true,message:'Supply parcel collected: 25 wood and 20 food. Your own villagers keep the kingdom growing.'};
}
export function createFounderEstate(definitions){
 const buildings=[],units=[];let id=1;
 function add(kind,x,y,level=10,label=null){const d=definitions[kind];buildings.push({id:'estate-b'+id++,kind,x,y,size:d.size,level,hp:d.health*(1+(level-1)*.2),maxHp:d.health*(1+(level-1)*.2),remaining:0,total:0,queue:[],cooldown:0,label});}
 add('townhall',12,10,10,'Sahir’s Keep');
 add('tower',8,10,10);add('tower',17,10,10);add('tower',8,17,8);add('tower',19,16,8);
 add('house',10,15,5);add('house',13,17,5);add('house',7,14,10);add('house',17,18,5);
 add('barracks',17,13,10,'Royal Barracks');add('farm',10,20,5);add('farm',13,21,5);
 const points=[[13,14],[14,14],[15,14],[17,17],[18,17],[19,18],[11,17],[12,18]];
 for(const[x,y]of points)units.push({id:'estate-u'+id++,kind:'soldier',x,y,faction:'ally',hp:240,maxHp:240,path:[],task:null,progress:0,attackTimer:0,home:{x,y},dead:0,royal:true});
 units.push({id:'founder-ruler',kind:'soldier',x:14,y:15,faction:'ally',hp:1000,maxHp:1000,path:[],task:null,progress:0,attackTimer:0,home:{x:14,y:15},dead:0,royal:true,ruler:true});
 const trees=[[5,7],[6,8],[9,5],[13,5],[18,5],[22,8],[23,12],[23,19],[20,23],[17,25],[8,23],[5,18],[6,13]];
 return {scene:'founder',time:0,buildings,units,nodes:trees.map(([x,y],i)=>({id:'estate-tree'+i,kind:'tree',x,y,amount:108})),drops:[],effects:[]};
}
export const BLUEPRINTS=[
 {id:'house',name:'Cottage',category:'village',visual:'house',description:'Housing increases population capacity.',available:true},
 {id:'farm',name:'Farm',category:'village',visual:'farm',description:'Assign villagers to gather renewable food.',available:true},
 {id:'mine',name:'Royal Gold Mine',category:'village',visual:'mine',description:'Renewable gold for land and armies.',available:true},
 {id:'quarry',name:'Stoneworks',category:'village',visual:'quarry',description:'Renewable building stone.',available:true},
 {id:'lumber',name:'Timber Yard',category:'village',visual:'lumber',description:'Renewable timber production.',available:true},
 {id:'barracks',name:'Barracks',category:'military',visual:'barracks',description:'Train shieldbearers and Ember Lancers.',available:true},
 {id:'archery',name:'Archery Range',category:'military',visual:'archery',description:'Train ranged Dawn Archers. Requires level 2.',available:true},
 {id:'forge',name:'Dawnguard Forge',category:'military',visual:'forge',description:'Promote shieldbearers into Dawnguards at level 3.',available:true},
 {id:'tower',name:'Watchtower',category:'defense',visual:'tower',description:'A defensive tower that fires at nearby enemies.',available:true},
 {id:'ballista',name:'Bolt Bastion',category:'defense',visual:'ballista',description:'Long-range, powerful defensive bolts. Level 2.',available:true},
 {id:'wall',name:'Stone Bulwark',category:'defense',visual:'wall',description:'Blocks movement; enemies can destroy it. Leave a route through.',available:true},
 {id:'nest',name:'Cinderwing Roost',category:'legend',visual:'nest',description:'Train and strengthen young dragons at level 4. Losses are permanent.',available:true},
 {id:'stables',name:'Windrider Stables',category:'military',visual:'house',description:'Mounted scouts are planned for a later chapter.',chapter:'The Open Road'},
 {id:'siege',name:'Siege Workshop',category:'military',visual:'barracks',description:'Mobile siege engines are planned for a later chapter.',chapter:'Beyond the Gates'}
];
