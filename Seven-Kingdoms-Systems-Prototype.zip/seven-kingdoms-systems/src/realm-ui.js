import {FOUNDER,BLUEPRINTS,PATRON_RULES,VILLAGE_MILESTONES,createFounderEstate,ensurePatronage,visitFounder,claimSupplies,supplyParcels} from './realm.js';
import {BUILDINGS} from './sim.js';
const $=id=>document.getElementById(id);
const escape=text=>String(text).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function createRealmUI({getState,renderer,ui,refresh,notify,persist}){
 let visiting=false,estate=null,cameraBefore=null,category='village',updateKey='',lastContext='';
 const location=document.querySelector('.location'),originalLocation=location.innerHTML;
 function showResult(r){notify(r.message);refresh();persist();return r;}
 function visit(){
  if(visiting)return;lastContext='';visitFounder(getState());visiting=true;estate=createFounderEstate(BUILDINGS);cameraBefore={...renderer.camera};renderer.camera.zoom=.85;renderer.home();ui.selected.clear();ui.placement=null;ui.hoverName='';ui.box=null;
  $('build-menu').hidden=true;document.body.classList.remove('building-open');document.body.classList.add('visiting');$('build-toggle').classList.remove('active');$('build-toggle').disabled=true;$('army').disabled=true;
  $('player-panel').hidden=true;$('ally-panel').hidden=false;location.innerHTML='<span class="location-line"></span>'+escape(FOUNDER.kingdom.toUpperCase())+'<span class="location-line"></span><small>A welcome beyond the frontier · Ally visit</small>';
  $('home').title='Return to your village';refresh();persist();notify('Your village pauses while you visit. Inspect the keep, meet your ally, and browse the blueprints.');
 }
 function home(){if(!visiting){renderer.home();return;}visiting=false;estate=null;lastContext='';Object.assign(renderer.camera,cameraBefore);ui.selected.clear();ui.hoverName='';document.body.classList.remove('visiting');$('build-toggle').disabled=false;$('army').disabled=false;$('player-panel').hidden=false;$('ally-panel').hidden=true;location.innerHTML=originalLocation;$('home').title='Return home (H)';refresh();persist();}
 function supplies(){if(!visiting)return {ok:false,message:'Visit your ally first.'};return showResult(claimSupplies(getState()));}
 function update(){
  const s=getState(),p=ensurePatronage(s),parcels=supplyParcels(s),goals=VILLAGE_MILESTONES.filter(m=>m.done(s)).length;
  const key=JSON.stringify([visiting,p.visited,parcels,goals]);if(key===updateKey)return;updateKey=key;
  $('neighbor-creator-name').textContent=FOUNDER.ruler;$('neighbor-creator-state').textContent=p.visited?'YOUR FIRST ALLY':'VISIT A POWERFUL ALLY';
  $('neighbor-home').classList.toggle('selected',!visiting);$('neighbor-founder').classList.toggle('selected',visiting);
  $('ally-panel').innerHTML=`<div class="eyebrow"><span class="live-dot"></span> ${escape(FOUNDER.banner.toUpperCase())}</div><div class="founder-crest" aria-hidden="true">♛</div><h2>${escape(FOUNDER.ruler)}</h2><div class="kingdom-sub">${escape(FOUNDER.kingdom)}</div><p class="founder-quote">“${escape(FOUNDER.motto)}”</p><div class="kingdom-rule"></div><div class="ally-relation"><span>Relationship</span><strong>Welcomed</strong></div><p class="ally-copy">A strong ally can open a door. Your people build what comes after.</p><button class="action primary ally-wide" data-realm-action="supplies" ${parcels<1?'disabled':''}><strong>${parcels?'Collect a supply parcel':'No parcels ready'}</strong><small>25 wood · 20 food${parcels?' · '+parcels+' ready':''}</small></button><p class="parcel-rule">One welcome parcel. Complete village goals to earn more. Visiting again does not create supplies.</p><button class="action ally-wide" data-realm-action="blueprints"><strong>Explore the blueprints</strong><small>See what your kingdom could become</small></button><button class="action ally-wide" data-realm-action="home"><strong>Return to Willowmere</strong><small>${goals} / 5 village goals complete</small></button>`;
  if(estate)estate.drops=parcels?[{id:'founder-supplies',x:16,y:20,resource:'wood',amount:PATRON_RULES.supplies.wood}]:[];
 }
 function context(container){
  const key=JSON.stringify([[...ui.selected],supplyParcels(getState())]);if(key===lastContext)return;lastContext=key;
  const chosen=estate&&[...estate.buildings,...estate.units,...estate.nodes].find(e=>ui.selected.has(e.id));
  let title=FOUNDER.kingdom,eyebrow='THE CREATOR’S KINGDOM',description='“Accept a little help. Build something that is yours.” Visit the keep or explore the blueprints. Your village is safe.',portrait='♛';
  if(chosen?.size){title=chosen.label||BUILDINGS[chosen.kind].name;eyebrow='ALLY BUILDING · LEVEL '+chosen.level;description=BUILDINGS[chosen.kind].description+' This belongs to your ally. You can inspect it, but it cannot be moved, upgraded or taken home.';portrait='♜';}
  else if(chosen?.faction){title=chosen.ruler?FOUNDER.ruler:'Royal shieldbearer';eyebrow=chosen.ruler?'YOUR FIRST ALLY':'THE CREATOR’S GUARD';description=chosen.ruler?'“Accept a little help, then build something that is yours. One day, another village may look to you.”':'Experienced guards defend this kingdom. They remain here when you return home.';portrait=chosen.ruler?'♛':'⚔';}
  else if(chosen){title='The royal gardens';eyebrow='A KINGDOM TO EXPLORE';description='The grounds belong to your ally. Your villagers gather resources in Willowmere.';portrait='❧';}
  container.innerHTML=`<div class="portrait royal-portrait" aria-hidden="true">${portrait}</div><div class="context-copy"><span class="eyebrow">${escape(eyebrow)}</span><h2>${escape(title)}</h2><p>${escape(description)}</p></div><div class="actions"><button class="action primary" data-realm-action="supplies" ${supplyParcels(getState())?'':'disabled'}><strong>Collect supplies</strong><small>25 wood · 20 food</small></button><button class="action" data-realm-action="blueprints"><strong>Blueprints</strong><small>Build your own future</small></button><button class="action" data-realm-action="home"><strong>Return home</strong><small>Willowmere</small></button></div>`;
 }
 function gallery(){
  const dialog=$('dialog');ui.paused=true;
  const existing=dialog.open;if(!existing)dialog.showModal();dialog.classList.add('blueprint-dialog');
  dialog.querySelector('.modal-content').innerHTML=`<button class="close" data-realm-action="close-gallery" aria-label="Close blueprints">×</button><span class="eyebrow">FROM A SMALL VILLAGE TO SOMETHING GREATER</span><h2>A glimpse of your future</h2><p class="gallery-intro">Your ally’s collection shows what lies ahead. Start with what your village needs today.</p><nav class="blueprint-tabs" aria-label="Blueprint categories">${[['village','Village'],['military','Military'],['legend','Legends']].map(([id,name])=>`<button data-blueprint-tab="${id}" class="${category===id?'active':''}" aria-pressed="${category===id}">${name}</button>`).join('')}</nav><div class="blueprint-grid">${BLUEPRINTS.filter(b=>b.category===category).map(b=>`<article class="blueprint-card ${b.available?'':'future-blueprint'}"><canvas width="280" height="220" data-blueprint-art="${b.id}" role="img" aria-label="${escape(b.name)} concept illustration"></canvas><div class="blueprint-card-copy"><span class="blueprint-tag">${b.available?'PLAYABLE NOW':'FUTURE CHAPTER · PREVIEW'}</span><h3>${escape(b.name)}</h3><p>${escape(b.description)}</p>${b.available?`<span class="blueprint-cost">${Object.entries(BUILDINGS[b.id].cost).map(([k,n])=>n+' '+k).join(' · ')}</span><button class="action" data-blueprint-build="${b.id}"><strong>Build in your village</strong></button>`:`<div class="chapter-lock">◇ ${escape(b.chapter)}</div><small>Preview only. Not yet unlockable in this prototype.</small>`}</div></article>`).join('')}</div><p class="blueprint-footnote">Buildings and future chapters use original concept illustrations. No cash purchases or paid rolls.</p>`;
  for(const canvas of dialog.querySelectorAll('[data-blueprint-art]')){canvas.width=400;canvas.height=220;const b=BLUEPRINTS.find(b=>b.id===canvas.dataset.blueprintArt);renderer.paintBlueprint(canvas,b.visual,b.available?1:10);}
  dialog.scrollTop=0;
 }
 function worldClick(hit){if(!visiting)return;if(hit?.id==='founder-supplies'){supplies();return;}ui.selected.clear();if(hit)ui.selected.add(hit.id);refresh();}
 function handle(e){
  const button=e.target.closest('[data-realm-action]');if(button&&!button.disabled){const action=button.dataset.realmAction;if(action==='visit')visit();if(action==='home')home();if(action==='supplies')supplies();if(action==='blueprints')gallery();if(action==='close-gallery')$('dialog').close();}
  const tab=e.target.closest('[data-blueprint-tab]');if(tab){category=tab.dataset.blueprintTab;gallery();}
  const build=e.target.closest('[data-blueprint-build]');if(build){const kind=build.dataset.blueprintBuild;$('dialog').close();home();window.dispatchEvent(new CustomEvent('realm-build',{detail:kind}));}
 }
 document.addEventListener('click',handle);$('neighbor-founder').onclick=visit;$('neighbor-home').onclick=home;$('dialog').addEventListener('close',()=>{$('dialog').classList.remove('blueprint-dialog');});
 return {get visiting(){return visiting;},get estate(){return estate;},visit,home,update,context,worldClick,gallery};
}
