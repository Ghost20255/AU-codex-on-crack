# Original game artwork

- `village-buildings.png`: six original illustrated buildings, generated for this project. Layout: town hall, cottage, barracks, watchtower, farm, royal keep. Source image is retained separately under /workspace/generated_images; this is an unmodified copy.
- `village-units.png`: twelve original character poses, generated for this project. Four poses per row: villager, shieldbearer, raider. The original transparent atlas is used directly. Feet alignment is measured at runtime so walking poses do not jump between rows.

These images were generated with the image-generation tool for the new Seven Kingdoms project. They are not extracted from Social Empires or a third-party sprite pack. The project distributes these original assets under its MIT license. Future blueprint cards use provisional concept illustrations; those future buildings and units are not yet implemented.

The renderer selects atlas regions with Canvas drawImage; it does not modify the source images. Both files are served locally with the rest of the game and need no API key, external service or network connection once hosted/downloaded. The current runtime retains procedural fallback rendering if an image cannot load, but browser validation checks that both actual illustrated atlases load successfully.
